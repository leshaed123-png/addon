"""Loopback-only local RU speech sidecar for PB City. Never stores recordings; CPU models loaded on demand."""
import argparse,os,json,wave,io,threading,hmac,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from functools import lru_cache
os.environ.setdefault('OMP_NUM_THREADS','2');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
from piper import PiperVoice,SynthesisConfig
from vosk import Model,KaldiRecognizer,SetLogLevel
SetLogLevel(-1)
class Speech:
 def __init__(self,root):
  self.root=Path(root);self.asr=None;self.tts=None;self.name='';self.lock=threading.Lock();self.voices=[n for n in ['dmitri','irina','ruslan','denis'] if (self.root/f'ru_RU-{n}-medium.onnx').is_file()];assert self.voices,'Run setup.py first.'
 def speak(self,text,num):
  name=self.voices[num%len(self.voices)]
  with self.lock:
   if self.name!=name:self.tts=None;self.tts=PiperVoice.load(self.root/f'ru_RU-{name}-medium.onnx');self.name=name
   stream=io.BytesIO()
   with wave.open(stream,'wb') as out:self.tts.synthesize_wav(text,out,syn_config=SynthesisConfig(length_scale=1.0))
   return stream.getvalue()
 def transcribe(self,raw):
  with wave.open(io.BytesIO(raw),'rb') as wf:
   rate=wf.getframerate();frames=wf.getnframes()
   if wf.getnchannels()!=1 or wf.getsampwidth()!=2 or rate not in (16000,48000) or frames>rate*9:raise ValueError('Expected PCM16 mono, 16/48 kHz, up to 9 s')
   data=wf.readframes(frames)
  if rate==48000:
   a=np.frombuffer(data,dtype='<i2');data=a[:len(a)//3*3].reshape(-1,3).mean(axis=1).astype('<i2').tobytes()
  with self.lock:
   if self.asr is None:self.asr=Model(str(self.root/'vosk-model-small-ru-0.22'))
   rec=KaldiRecognizer(self.asr,16000);words=[]
   for i in range(0,len(data),8192):
    if rec.AcceptWaveform(data[i:i+8192]):words.append(json.loads(rec.Result())['text'])
   words.append(json.loads(rec.FinalResult())['text']);return ' '.join(s for s in words if s).strip()
def serve(root,port):
 speech=Speech(root);limit=threading.BoundedSemaphore(3);token=os.environ.get('PBCITY_VOICE_KEY','')
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*args):pass # transcripts and request payloads never logged
  def send(self,code,kind,data):self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def do_GET(self):self.send(200 if self.path=='/health' else 404,'application/json',json.dumps({'voices':speech.voices,'language':'ru'} if self.path=='/health' else {}).encode())
  def do_POST(self):
   if self.path not in ('/tts','/stt'):return self.send(404,'text/plain',b'Not found')
   if token and not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+token):return self.send(401,'text/plain',b'Unauthorized')
   if not limit.acquire(False):return self.send(429,'text/plain',b'Busy')
   try:
    self.connection.settimeout(15);n=int(self.headers.get('Content-Length','0'));cap=900000 if self.path=='/stt' else 8192
    if not 0<n<=cap:return self.send(413,'text/plain',b'Invalid size')
    raw=self.rfile.read(n)
    if self.path=='/stt':return self.send(200,'application/json; charset=utf-8',json.dumps({'text':speech.transcribe(raw)},ensure_ascii=False).encode())
    j=json.loads(raw);text=j['text'].strip()
    if not 0<len(text)<=480 or j.get('lang','ru')!='ru':raise ValueError('Invalid text')
    self.send(200,'audio/wav',speech.speak(text,int(j.get('voice',0))))
   except (ValueError,KeyError,wave.Error,EOFError,TypeError):self.send(400,'text/plain',b'Invalid payload')
   except (BrokenPipeError,ConnectionResetError):pass
   except Exception:self.send(500,'text/plain',b'Local speech model error')
   finally:limit.release()
 print(f'PB City: http://127.0.0.1:{port}/health — {len(speech.voices)} RU voices',flush=True);ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--models',type=Path,default=Path(__file__).resolve().parent/'models');p.add_argument('--port',type=int,default=8765);a=p.parse_args();serve(a.models,a.port)
