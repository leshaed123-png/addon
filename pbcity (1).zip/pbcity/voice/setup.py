"""Download optional local speech models from their publishers. No weights or third-party mod JAR are bundled."""
import argparse,hashlib,pathlib,urllib.request,zipfile,shutil
ROOT=pathlib.Path(__file__).resolve().parent
REV='613b6e5ad36ddca4e70e171957291483dc244d9f'
MODELS={'dmitri':'9ed9941bac7373f2ec1be36627e0e71a349a59ca5522d4363fd50701db05193a','irina':'8ff38212d23da300bbe3705c645e6e5b9475f0bfde01558eb17813e22acaaaaa','ruslan':'72a5f88e0b20928064eb45d88e1daa21f8af62d18613580d32cbb4aed48dcf7f','denis':'879bc365cb14d1380e3f5ed6044162ccf54c99f6161871569b7f830aec3ce841'}
MOD_URL='https://cdn.modrinth.com/data/9eGKb6K1/versions/S11m0QIb/voicechat-forge-1.20.1-2.6.22.jar';MOD_SHA='23c8b3a593fe506af8d8e0edc0afb45349777d5cdea41ffc3fa99afc2e3b9bc7770bb9951f674017ea5b3c23e111b0c6031ebd61820c9a0b5191e3992d9c8798'
def digest(path,algo):
 h=hashlib.new(algo)
 with path.open('rb') as f:
  for s in iter(lambda:f.read(256*1024),b''):h.update(s)
 return h.hexdigest()
def fetch(url,path,expected='',algo='sha256'):
 path.parent.mkdir(parents=True,exist_ok=True)
 if path.exists() and (not expected or digest(path,algo)==expected):return
 print('Download:',path.name,flush=True);tmp=path.with_suffix(path.suffix+'.part')
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PBCity-Kontur/0.2'}),timeout=90) as r,tmp.open('wb') as f:shutil.copyfileobj(r,f)
 if expected and digest(tmp,algo)!=expected:tmp.unlink();raise ValueError('Checksum mismatch: '+path.name)
 tmp.replace(path)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--models',type=pathlib.Path,default=ROOT/'models');ap.add_argument('--voices',nargs='+',choices=list(MODELS),default=list(MODELS));ap.add_argument('--voicechat-only',action='store_true',help='download the pinned official Forge mod to downloads/ and exit');a=ap.parse_args();root=a.models.resolve()
 if a.voicechat_only:
  fetch(MOD_URL,ROOT/'downloads'/MOD_URL.rsplit('/',1)[1],MOD_SHA,'sha512');print('Copy the jar from downloads/ to mods/ on client and server.');raise SystemExit
 asr='vosk-model-small-ru-0.22';arc=root/(asr+'.zip')
 if not (root/asr/'am/final.mdl').is_file():
  fetch('https://alphacephei.com/vosk/models/'+asr+'.zip',arc)
  with zipfile.ZipFile(arc) as z:
   for info in z.infolist():
    dest=(root/info.filename).resolve();assert root in dest.parents and info.filename.startswith(asr+'/')
   z.extractall(root)
  arc.unlink()
 for name in a.voices:
  fn=f'ru_RU-{name}-medium.onnx';url=f'https://huggingface.co/rhasspy/piper-voices/resolve/{REV}/ru/ru_RU/{name}/medium/'
  for filename,checksum in [(fn,MODELS[name]),(fn+'.json',''),('MODEL_CARD','')]:fetch(url+filename,root/(filename if filename!='MODEL_CARD' else name+'-MODEL_CARD.txt'),checksum)
 print('Ready:',root)
