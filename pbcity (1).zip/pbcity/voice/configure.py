"""Set only the four voice fields, preserving other PB City options. Run while the game/server is stopped."""
from pathlib import Path
import sys,re,shutil
if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit('Usage: python configure.py "path to the game or server directory"')
 root=Path(sys.argv[1]).expanduser().resolve()
 if not root.is_dir() or not (root/'mods').is_dir():raise SystemExit('No mods/ in the selected game directory.')
 path=root/'config/pbcity-common.toml';path.parent.mkdir(exist_ok=True);s=path.read_text(encoding='utf8') if path.exists() else '';found=re.search(r'^\[voice\][^\n]*\n(.*?)(?=^\[|\Z)',s,flags=re.M|re.S);body=found.group(1) if found else ''
 if path.exists() and not path.with_suffix('.before-kontur-voice.toml').exists():shutil.copy2(path,path.with_suffix('.before-kontur-voice.toml'))
 for key,val in {'sttUrl':'"http://127.0.0.1:8765/stt"','ttsUrl':'"http://127.0.0.1:8765/tts"','voiceCount':'4'}.items():
  pat=r'(?m)^[ \t]*'+key+r'[ \t]*=[^\n]*';line='\t'+key+' = '+val
  body=re.sub(pat,line,body) if re.search(pat,body) else body.rstrip()+'\n'+line+'\n'
 s=(s[:found.start(1)]+body.rstrip()+'\n\n'+s[found.end(1):]) if found else s.rstrip()+'\n\n[voice]\n'+body.strip('\n')+'\n';path.write_text(s,encoding='utf-8');print('Updated',path,'; existing serviceKey preserved. Restart the game/server.')
