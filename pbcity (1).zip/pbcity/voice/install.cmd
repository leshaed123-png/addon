@echo off
cd /d "%~dp0"
py -3 -m venv .venv || goto fail
.venv\Scripts\python.exe -m pip install -r requirements.txt || goto fail
.venv\Scripts\python.exe setup.py || goto fail
.venv\Scripts\python.exe setup.py --voicechat-only || goto fail
echo Models ready. See README-RU.md for the Forge config and mods folder.
pause
exit /b 0
:fail
echo Setup failed. Read the error above.
pause
exit /b 1
