# Проверка релиза 0.2.0

SHA-256 проверенного production JAR: `f40a92189f9201caf8d817ab6f065a9a63cf88cf1d4fe8eebde1356f55f1e2ed`.

Minecraft Java 1.20.1, Forge 47.3.0, Java 17.0.21, Point Blank 2.2.0, GeckoLib 4.8.6, Simple Voice Chat 1.20.1-2.6.22. Проверен reobf JAR в реальном графическом клиенте (Xvfb, программный OpenGL) с интегрированным сервером. QA-мод загружен отдельно и в релиз не включён.

## Интеграционные проверки: 26/26

- playable district placement: Квартал 07 открыт. Выдача — у типографии; переулок, площадь и участок отмечены в мире.
- existing building is not overwritten
- non-operator grant command denied
- operator credit in cents
- operator unlimited
- unlimited restores balance
- chilli noodles cost exact catalogue price
- real edible inventory item
- physical Ledger serial
- order accepted with persisted nonce
- second active order rejected
- Ledger address stored in order thread
- unowned address rejected
- remote pickup rejected
- nearby pickup validated
- bound parcel delivered
- portrait matches spawned recipient
- missing Ledger keeps job and parcel
- handoff closes job
- reward on the original physical Ledger only
- repeated handoff cannot pay twice
- fixture sleeping at night
- actual night skip triggered dawn arrest
- server teleported player to configured jail
- operator pardon releases sentence
- incident opens a persistent police case

## Остальные проверки

- F7, отдельный портретный телефон, покупка, заявка через GUI, назначение места и реквизитов через переписку; скриншоты реальных устройств и карты.
- Simple Voice Chat обнаружил и инициализировал плагин PB City.
- Локальные HTTP-ручки /health, /tts, /stt проверены с четырьмя реальными русскими Piper-моделями (dmitri, irina, ruslan, denis) и Vosk small ru 0.22. Тестовая фраза прошла через WAV в формате игры; распознавание может ошибаться в словах. Микрофон конкретного игрока, его сеть, сторонний LLM и развёртывание на выделенном сервере не тестировались.
- Повторная настройка configure.py сохранила соседние секции TOML и serviceKey.
- Все JSON прочитаны; статическая проверка обнаружила 21 OBJ-модель (20 товаров + опечатанная посылка) и 49 соответствующих пар скин/портрет.
