"""Generate original product meshes, print sleeves and matching catalogue stills. Python + NumPy + Pillow."""
from pathlib import Path
import math, json, random, re
from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageOps
import numpy as np
R=Path(__file__).resolve().parents[1]/'src/main/resources/assets/pbcity'; D=R/'models/item/mesh'; T=R/'textures/item/print'; G=R/'textures/kontur/products'
for p in (D,T,G):p.mkdir(parents=True,exist_ok=True)
font=lambda size,bold=False: ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',size)
A=np.array
normalize=lambda p:p/max(1e-9,np.linalg.norm(p))
white='#f2e9cf';ink='#233437';teal='#227a72';red='#d9593c';silver='#a8b4b1';black='#283333'
class Mesh:
 def __init__(s):s.fs=[]
 def face(s,pts,col,uv=None,norm=None):
  p=A(pts,dtype=float);n=normalize(np.cross(p[1]-p[0],p[2]-p[0]));s.fs.append((p,col,A((uv or [(0,1),(1,1),(1,0),(0,0)])[:len(p)]),A(norm) if norm is not None else np.tile(n,(len(p),1))))
 def box(s,x,y,z,w,h,d,c,front=None):
  a,b,k=x-w/2,y-h/2,z-d/2; X,Y,Z=x+w/2,y+h/2,z+d/2
  for ps,col in [([(a,b,Z),(X,b,Z),(X,Y,Z),(a,Y,Z)],front or c), ([(X,b,k),(a,b,k),(a,Y,k),(X,Y,k)],c), ([(X,b,Z),(X,b,k),(X,Y,k),(X,Y,Z)],c), ([(a,b,k),(a,b,Z),(a,Y,Z),(a,Y,k)],c), ([(a,Y,Z),(X,Y,Z),(X,Y,k),(a,Y,k)],c), ([(a,b,k),(X,b,k),(X,b,Z),(a,b,Z)],c)]:s.face(ps,col)
 def lathe(s,cx,cz,levels,cols,n=40,sx=1,sz=1):
  # Each consecutive ring is smoothly shaded around its circumference; hard edges between profile segments.
  for j,((y0,r0),(y1,r1)) in enumerate(zip(levels,levels[1:])):
   c=cols[j%len(cols)]
   for i in range(n):
    a=i*2*math.pi/n-math.pi;b=(i+1)*2*math.pi/n-math.pi
    def v(t,y,r):return [cx+sx*r*math.sin(t),y,cz+sz*r*math.cos(t)]
    def normal(t):return normalize(A([(y1-y0)*math.sin(t)/sx,r0-r1,(y1-y0)*math.cos(t)/sz]))
    s.face([v(a,y0,r0),v(b,y0,r0),v(b,y1,r1),v(a,y1,r1)],c,[(i/n,1),((i+1)/n,1),((i+1)/n,0),(i/n,0)], [normal(a),normal(b),normal(b),normal(a)])
 def blob(s,x,y,z,rx,ry,rz,c):
  lev=[(y-ry*math.cos(i*math.pi/8),max(.002,math.sin(i*math.pi/8))) for i in range(9)];s.lathe(x,z,lev,[c],20,rx,rz)
 def rod(s,a,b,r,c,n=10):
  a,b=A(a),A(b);axis=normalize(b-a);u=normalize(np.cross(axis,[0,1,0] if abs(axis[1])<.9 else [1,0,0]));v=np.cross(axis,u)
  for i in range(n):
   def rv(k):return r*(math.cos(2*math.pi*k/n)*u+math.sin(2*math.pi*k/n)*v)
   h,g=rv(i),rv(i+1);s.face([a+h,a+g,b+g,b+h],c);s.face([b,b+h,b+g],c);s.face([a,a+g,a+h],c)
 def rounded(s,x,y,z,w,h,d,r,c): # flat rounded plan, extruded in Y
  pts=[]
  for ax,az,start in [(1,1,0),(1,-1,90),(-1,-1,180),(-1,1,270)]:
   for i in range(6):
    a=math.radians(start+90*i/5);pts.append((x+ax*(w/2-r)+r*math.sin(a),z+az*(d/2-r)+r*math.cos(a)))
  for i,(a,b) in enumerate(pts):
   X,Z=pts[(i+1)%len(pts)];Y=y+h/2;B=y-h/2
   s.face([(a,B,b),(X,B,Z),(X,Y,Z),(a,Y,b)],c);s.face([(x,Y,z),(a,Y,b),(X,Y,Z)],c);s.face([(x,B,z),(X,B,Z),(a,B,b)],c)
 def export(s,id):
  verts={};uvs={};ns={};groups={}
  def idx(store,v):
   v=tuple(round(float(t),5) for t in v);return store.setdefault(v,len(store)+1)
  for p,c,uv,n in s.fs:
   q=[]
   for point,coord,norm in zip(p,uv,n):q.append('%s/%s/%s'%(idx(verts,point/16),idx(uvs,coord),idx(ns,norm)))
   groups.setdefault(c,[]).append('f '+' '.join(q))
  lines=['# Kontur Studio / product geometry','mtllib '+id+'.mtl','o '+id];mat=[]
  for label,store in [('v',verts),('vt',uvs),('vn',ns)]:lines.extend(label+' '+' '.join(f'{v:g}' for v in key) for key in store)
  for j,(c,faces) in enumerate(groups.items()):
   mat.extend(['newmtl m%d'%j,'Kd '+' '.join(str(round(int(c[i:i+2],16)/255,5)) for i in (1,3,5)) if c[0]=='#' else 'Kd 1 1 1','map_Kd pbcity:item/'+('matte' if c[0]=='#' else 'print/'+id)]);lines+=['usemtl m%d'%j]+faces
  (D/(id+'.obj')).write_text('\n'.join(lines)+'\n');(D/(id+'.mtl')).write_text('\n'.join(mat)+'\n');name='ledger_body' if id=='ledger' else id
  data={'parent':'minecraft:item/handheld','loader':'forge:obj','model':'pbcity:models/item/mesh/'+id+'.obj','automatic_culling':False,'flip_v':False,'emissive_ambient':False,'textures':{'particle':'pbcity:item/matte','layer0':'pbcity:item/matte'},'display':{'gui':{'rotation':[25,210,0],'translation':[0,0,0],'scale':[.92,.92,.92]},'ground':{'scale':[.45,.45,.45]},'fixed':{'rotation':[0,180,0],'scale':[.8,.8,.8]},'thirdperson_righthand':{'rotation':[72,0,0],'translation':[0,3,1],'scale':[.5,.5,.5]},'firstperson_righthand':{'rotation':[0,-22,0],'translation':[1.2,2,-1],'scale':[.65,.65,.65]}}}
  (R/f'models/item/{name}.json').write_text(json.dumps(data,separators=(',',':')))
 def render(s,id,wrap,bg,dark=False):
  W,H=426,240;im=np.zeros((H,W,3),dtype=float);base=A(bytes.fromhex(bg[1:]).hex() and list(bytes.fromhex(bg[1:])),dtype=float);Y,X=np.mgrid[:H,:W];im[:]=base;im+=((H/2-Y)/H*9)[...,None];im-=np.exp(-((X-W*.5)**2/(W*.17)**2+(Y-H*.84)**2/(H*.055)**2))[...,None]*(14 if dark else 36)
  buf=np.full((H,W),-1e6);eye=normalize(A([.48,.38,1.]));right=normalize(np.cross([0,1,0],eye));up=np.cross(eye,right);rot=A([right,-up,eye]);coords=np.concatenate([p for p,*_ in s.fs])@rot.T;mi=coords.min(0);ma=coords.max(0);scale=min(W*.79/max(1,ma[0]-mi[0]),H*.81/max(1,ma[1]-mi[1]));center=(mi+ma)*.5;tex=np.array(wrap.convert('RGB'));light=normalize(A([-.55,.87,.9]));
  for p,c,uv,norm in s.fs:
   if np.dot(np.cross(p[1]-p[0],p[2]-p[0]),eye)<=0:continue
   pp=(p@rot.T-center)*scale+[W*.5,H*.49,0]
   for triple in ([0,1,2],[0,2,3]) if len(p)==4 else ([0,1,2],):
    t=pp[triple];x0,y0=np.maximum(np.floor(t[:,:2].min(0)).astype(int),0);x1,y1=np.minimum(np.ceil(t[:,:2].max(0)).astype(int)+1,[W,H]);
    if x1<=x0 or y1<=y0:continue
    yy,xx=np.mgrid[y0:y1,x0:x1];xx=xx+.5;yy=yy+.5;a,b,e=t;den=(b[1]-e[1])*(a[0]-e[0])+(e[0]-b[0])*(a[1]-e[1]);
    if abs(den)<1e-8:continue
    w1=((b[1]-e[1])*(xx-e[0])+(e[0]-b[0])*(yy-e[1]))/den;w2=((e[1]-a[1])*(xx-e[0])+(a[0]-e[0])*(yy-e[1]))/den;w3=1-w1-w2;z=w1*a[2]+w2*b[2]+w3*e[2];v=buf[y0:y1,x0:x1];mask=(w1>=-.0001)&(w2>=-.0001)&(w3>=-.0001)&(z>v);v[mask]=z[mask];ws=np.stack([w1[mask],w2[mask],w3[mask]],axis=1);ns=ws@norm[triple];shade=.68+.41*np.maximum(0,np.sum(ns*light,axis=1));
    if c[0]=='#':rgb=A(list(bytes.fromhex(c[1:])))
    else:q=ws@uv[triple];rgb=tex[np.clip((q[:,1]*(tex.shape[0]-1)).astype(int),0,tex.shape[0]-1),np.clip((q[:,0]*(tex.shape[1]-1)).astype(int),0,tex.shape[1]-1)]
    im[y0:y1,x0:x1][mask]=rgb*shade[:,None]
  Image.fromarray(np.uint8(np.clip(im,0,255))).resize((320,180),Image.Resampling.LANCZOS).save(G/(id+'.png'),optimize=True)

def sleeve(id,brand,clr,accent,tag):
 im=Image.new('RGB',(512,128),clr);d=ImageDraw.Draw(im);fg=white
 d.rectangle((0,0,511,5),fill=accent);d.rectangle((0,111,511,127),fill=accent);d.text((24,12),'K / DISTRICT SUPPLY',font=font(11,True),fill=fg);d.text((24,38),tag,font=font(27,True),fill=fg);d.text((25,82),'07  —  EDITION',font=font(12),fill=fg)
 d.text((252,19),brand,anchor='mt',font=font(40,True),fill=fg);d.text((253,74),tag,anchor='mt',font=font(16,True),fill=fg);d.line((189,99,317,99),fill=fg,width=2)
 for i in range(25):d.rectangle((415+i*2,20,415+i*2+(i%2),82-(i%3==0)*4),fill=fg)
 d.text((402,85),'K 0009',font=font(12),fill=fg);im.save(T/(id+'.png'));return im

def make(id):
 m=Mesh();fl=id.split('_')[-1]; colors={'chicken':('#c2762a','#e8ae4b','КУРИЦА'),'chili':('#b74232','#f2a04e','ЧИЛИ'),'miso':('#4c7955','#9bad66','МИСО'),'beef':('#79464d','#d3896b','ГОВЯДИНА')};bg='#e7e6d7';wrap=None
 if id.startswith('ramen'):
  c,a,t=colors[fl];wrap=sleeve(id,'ПАР',c,a,t);m.lathe(8,8,[(2,.001),(2,3.3),(2.4,3.5),(3.6,3.8),(10,5.1),(10.25,5.4),(10.7,5.46),(10.9,5.25),(10.9,.001)],[white,white,c,'print',white,white,white,'#e8c379']);
  for i in range(18):
   ang=i*2.39;x=8+math.cos(ang)*math.sqrt(i/18)*4;z=8+math.sin(ang)*math.sqrt(i/18)*4;m.blob(x,10.94,z,.53,.12,.28,['#77914e','#d89547','#e7c68d'][i%3]);
  m.rod([5,11.2,4],[13.6,12.9,12.4],.16,'#c18a54');m.rod([5.6,11.2,3.7],[14.2,12.9,12.1],.16,'#e3b47b')
 elif id in ('coffee','matcha','soda','berry','pudding'):
  c,a,brand,tag={'coffee':('#915838','#c89165','ТАКТ','FLAT WHITE'),'matcha':('#5d8061','#adc18a','ТАКТ','MATCHA'),'soda':('#b26131','#eea455','ZEST','MANDARIN'),'berry':('#87405a','#d98b95','МОРС','ЯГОДЫ'),'pudding':('#ba8c51','#ddbc7a','КРЕМ','КАРАМЕЛЬ')}[id];wrap=sleeve(id,brand,c,a,tag)
  if id in ('soda','berry'):
   m.lathe(8,8,[(1,.002),(1,2.9),(1.4,3.2),(2,3.55),(11.5,3.55),(12.2,3.1),(12.6,3.12),(12.8,3.25),(13,3.05),(12.9,.002)],[silver,silver,c,'print',c,silver,silver,silver,'#c6c8b9']);m.lathe(8,8.3,[(12.91,.8),(13.2,.85),(13.2,.47),(12.91,.45)],[silver,white,silver],24,.65,1.4)
  else:
   t=9 if id=='pudding' else 14;m.lathe(8,8,[(1,.01),(1,3),(1.3,3.25),(3.2,3.45),(t-2,4.5),(t-1.8,4.7),(t-1.45,4.65),(t-1.4,4.38),(t-.65,4),(t-.55,3.55),(t-.56,.01)],[white,white,white,'print',ink,ink,ink,ink,ink,'#414943']);m.box(8,t-.5,10.8,2,.12,.56,'#1d2426')
 elif id in ('bento','sushi','mochi','sealed_parcel'):
  m.rounded(8,3.1,8,13.2,2.5,9.2,1,black if id!='sealed_parcel' else '#ae8153');m.rounded(8,4.35,8,12.8,.4,9,.92,'#c18e67' if id=='sealed_parcel' else '#bb9b72');
  if id=='sealed_parcel':m.box(8,4.65,8,2,.24,9.2,white);m.box(8,3.2,12.65,2,2.7,.12,white);m.box(10.8,4.65,7,3,.12,2,red)
  if id=='sushi':
   for x in [4.15,8,11.85]:
    for z in [5.9,10.1]:m.lathe(x,z,[(4.5,.02),(4.5,1.59),(6.5,1.7),(6.54,1.44),(6.55,.58),(6.57,.02)],[ink,'#303b32',ink,white,'#dd815d'],24)
  if id=='mochi':
   for i,c in enumerate(['#ddb3ad','#b8c691','#dccca5']):m.blob(4.4+i*3.65,5.6,8,1.78,1.63,2,c);m.blob(4.4+i*3.65,7.1,8,.45,.35,.5,'#bb7479')
  if id=='bento':
   m.rounded(5.3,5.1,8,6.1,1.4,7.4,.85,'#e2d9b9');m.box(8.65,4.9,8,.35,1.6,8,ink)
   for j in range(6):m.blob(10+j%2*2,5.2,5.8+j//2*2.2,1,.82,1.15,['#b9804a','#a0a967','#c69256'][j%3]);
   for j in range(14):m.blob(3.0+(j*7%13)*.33,5.82,5.4+(j*3%11)*.45,.2,.11,.1,ink)
 elif id in ('eink','tablet','pager','recorder','cassette','camera','ledger','headset'):
  bg='#c3d2c9' if id in ('tablet','camera','eink','headset') else '#354542';wrap=sleeve(id,'K/09','#423e39','#cc8463','FIELD');
  if id in ('eink','tablet'):
   m.rounded(8,5,8,13.6,.75,9.4,.8,silver);m.rounded(8,5.42,8,13.4,.3,9.25,.7,ink);m.rounded(8,5.6,8,12.4,.15,8.4,.55,'#d3d4b9' if id=='eink' else '#286c69');m.box(5.1,5.72,6.1,5.4,.07,2.6,'#9eb7a1');m.box(10.6,5.72,6.1,4.7,.07,2.6,red);m.box(8,5.72,9.4,10.8,.07,2.1,'#bfc3a8');m.box(8,5.77,9.4,8,.04,.25,teal)
  if id in ('pager','recorder','ledger'):
   w,h,d=(9.8,7,3.3) if id=='pager' else (6.4,13.6,2.6);z=8;bottom=(16-h)/2; m.box(8,8,z,w,h,d,'#46514e');m.box(8,bottom+h*.81,z+d/2+.08,w*.78,h*.27,.17,'#102a2a' if id=='ledger' else '#91a99a');
   for j in range(3):m.box(8-w*.26+j*w*.26,bottom+h*.43,z+d/2+.13,w*.16,.72,.25,red if j==2 else silver)
   for j in range(6):m.box(8,bottom+h*.14+j*.25,z+d/2+.12,w*.55,.105,.09,'#1f2c2d')
   if id=='recorder':
    for x in (6.6,9.4):m.lathe(x,8,[(14,.75),(15.36,.85),(15.7,.6),(15.76,.01)],[silver,ink,silver],20)
  if id=='cassette':
   m.box(8,7.4,8,13.4,8.1,1.9,'#3b4744');m.box(8,8.5,9.02,11.4,4.3,.18,white,'print');m.box(8,7.7,9.16,6.15,1.2,.08,ink)
   for x in (4.3,11.7):m.rod([x,7.7,9.08],[x,7.7,9.34],1.03,silver,22);m.rod([x,7.7,9.32],[x,7.7,9.36],.57,ink,14)
  if id=='camera':
   m.rounded(8,6.9,8,12.6,6,4.5,.9,ink);m.rounded(8,10.2,8,12.9,1.2,4.6,.9,silver);m.rod([7.4,7.4,9.9],[7.4,7.4,12.1],2.9,'#72817c',40);m.rod([7.4,7.4,12.0],[7.4,7.4,12.8],2.5,black,40);m.rod([7.4,7.4,12.7],[7.4,7.4,12.85],1.9,'#4b817d',40);m.box(3.7,9.9,10.37,2,1,.32,'#e3dfc8');m.lathe(12,8,[(10.7,.85),(11.3,.85),(11.4,.01)],[ink,silver],20)
  if id=='headset':
   for j in range(18):
    a=j*math.pi/18;b=(j+1)*math.pi/18;m.rod([8+4.8*math.cos(a),7+5.8*math.sin(a),8],[8+4.8*math.cos(b),7+5.8*math.sin(b),8],.65,teal,12)
   for x in [3.25,12.75]:m.blob(x,6.5,8,1.5,2.8,2.25,ink);m.blob(x+(-.8 if x<8 else .8),6.5,8,.78,2.25,1.8,silver)
 if wrap is None:wrap=sleeve(id,'К/07',teal,'#b38a58','STUDIO')
 m.export(id);m.render(id,wrap,bg);return len(m.fs)
if __name__=='__main__':
 Image.new('RGB',(16,16),'white').save(R/'textures/item/matte.png');ids='ramen_chicken ramen_chili ramen_miso ramen_beef coffee matcha soda berry bento sushi mochi pudding eink headset camera tablet ledger pager cassette recorder sealed_parcel'.split();print({id:make(id) for id in ids})
