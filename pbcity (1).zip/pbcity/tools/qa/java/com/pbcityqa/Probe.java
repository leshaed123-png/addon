package com.pbcityqa;

import com.pbcity.district.*;
import com.pbcity.econ.PlayerFunds;
import com.pbcity.item.ModItems;
import com.pbcity.net.*;
import com.pbcity.npc.*;
import com.pbcity.police.*;
import java.util.UUID;
import net.minecraft.core.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod("konturqa")
@Mod.EventBusSubscriber(modid = "konturqa")
public final class Probe {
  static int age;
  static boolean failed;
  static String addr;
  static long bank;
  static UUID nonce;
  static BlockPos cell;
  static ItemStack removed;

  static void ok(boolean yes, String step) {
    if (!yes) throw new AssertionError(step);
    com.mojang.logging.LogUtils.getLogger().info("KONTUR_QA PASS {}", step);
  }

  static void op(ServerPlayer p, String s, String arg, long v) {
    District.handle(p, new DistrictRequest(s, arg, v));
  }

  static void tp(ServerPlayer p, BlockPos v) {
    p.teleportTo(p.serverLevel(), v.getX() + .5, v.getY(), v.getZ() + .5, 0, 0);
  }

  @SubscribeEvent
  public static void tick(TickEvent.ServerTickEvent e) {
    var server = e.getServer();
    if (!Boolean.getBoolean("pbcity.qa")
        || server.isDedicatedServer()
        || !server.getWorldData().getLevelName().equals("KonturQA")
        || e.phase != TickEvent.Phase.END
        || server.getPlayerList().getPlayers().isEmpty()
        || failed) return;
    var p = server.getPlayerList().getPlayers().get(0);
    if (!p.getGameProfile().getName().equals("KonturQA")) return;
    age++;
    var t = PlayerFunds.tag(p);
    try {
      switch (age) {
        case 25 -> {
          String r = Quarter.place(p);
          ok(r.contains("Квартал 07 открыт"), "playable district placement: " + r);
          String again = Quarter.place(p);
          ok(again.contains("занята"), "existing building is not overwritten");
          long before = PlayerFunds.bank(p);
          try {
            server
                .getCommands()
                .getDispatcher()
                .execute(
                    "pbcity admin money " + p.getGameProfile().getName() + " 999",
                    p.createCommandSourceStack().withPermission(0));
          } catch (com.mojang.brigadier.exceptions.CommandSyntaxException denied) {
          }
          ok(PlayerFunds.bank(p) == before, "non-operator grant command denied");
        }
        case 35 -> {
          bank = PlayerFunds.bank(p);
          op(p, "adminBank", p.getUUID().toString(), 100);
          ok(PlayerFunds.bank(p) == bank + 100, "operator credit in cents");
          op(p, "infOn", p.getUUID().toString(), 0);
          ok(
              PlayerFunds.unlimited(p) && PlayerFunds.bank(p) >= PlayerFunds.INF,
              "operator unlimited");
          op(p, "infOff", p.getUUID().toString(), 0);
          ok(PlayerFunds.bank(p) == bank + 100, "unlimited restores balance");
        }
        case 40 -> {
          bank = PlayerFunds.bank(p);
          op(p, "buy", "", 1);
          ok(PlayerFunds.bank(p) == bank - 195, "chilli noodles cost exact catalogue price");
          ok(
              p.getInventory().items.stream()
                  .anyMatch(
                      s -> s.isEdible() && s.getItem().getDescriptionId().endsWith("ramen_chili")),
              "real edible inventory item");
          op(p, "buy", "", 16);
          addr = Wallets.address(p, 4);
          ok(addr.startsWith("PB.LG."), "physical Ledger serial");
        }
        case 45 -> {
          op(p, "order", "alley", 1);
          var j = Deliveries.job(p);
          ok(j.hasUUID("nonce"), "order accepted with persisted nonce");
          nonce = j.getUUID("nonce");
          op(p, "order", "square", 2);
          ok(Deliveries.job(p).getUUID("nonce").equals(nonce), "second active order rejected");
          op(p, "send", "Ledger", 0);
          ok(j.getString("address").equals(addr), "Ledger address stored in order thread");
          op(p, "route", "PB.LG.invalid", 0);
          ok(j.getString("address").equals(addr), "unowned address rejected");
          op(p, "pick", "", 0);
          ok(j.getInt("phase") == 1, "remote pickup rejected");
          tp(p, BlockPos.of(j.getLong("pickup")));
        }
        case 55 -> {
          op(p, "pick", "", 0);
          var j = Deliveries.job(p);
          ok(j.getInt("phase") == 2, "nearby pickup validated");
          ok(
              p.getInventory().items.stream()
                  .anyMatch(
                      s ->
                          s.is(ModItems.SEALED.get())
                              && s.getOrCreateTag().getUUID("dispatch").equals(nonce)),
              "bound parcel delivered");
        }
        case 258 -> {
          var j = Deliveries.job(p);
          var n = (CityNpc) p.serverLevel().getEntity(j.getUUID("recipient"));
          ok(n != null && n.appearance() == j.getInt("skin"), "portrait matches spawned recipient");
          tp(p, ((net.minecraft.world.entity.Entity) n).blockPosition());
          for (int i = 0; i < p.getInventory().getContainerSize(); i++)
            if (p.getInventory().getItem(i).is(ModItems.LEDGER.get())) {
              removed = p.getInventory().removeItemNoUpdate(i);
              break;
            }
          Deliveries.interact(p, n);
          ok(!Deliveries.job(p).isEmpty(), "missing Ledger keeps job and parcel");
          p.getInventory().add(removed);
          Deliveries.interact(p, n);
          ok(Deliveries.job(p).isEmpty() && t.getInt("districtDone") == 1, "handoff closes job");
          var lg =
              p.getInventory().items.stream()
                  .filter(s -> s.is(ModItems.LEDGER.get()))
                  .findFirst()
                  .orElseThrow();
          double bit = lg.getOrCreateTag().getDouble("bit");
          ok(bit > 0 && t.getDouble("bit") == 0, "reward on the original physical Ledger only");
          Deliveries.interact(p, n);
          ok(lg.getOrCreateTag().getDouble("bit") == bit, "repeated handoff cannot pay twice");
        }
        case 270 -> {
          cell = PoliceData.get(server).jailOrSpawn(server);
          PlayerFunds.addDirty(p, 200);
          var sl = p.serverLevel();
          sl.setDayTime(16000);
          var foot = p.blockPosition();
          var bed = Blocks.RED_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.EAST);
          sl.setBlockAndUpdate(foot, bed);
          sl.setBlockAndUpdate(foot.east(), bed.setValue(BedBlock.PART, BedPart.HEAD));
          p.startSleeping(foot.east());
          sl.updateSleepingPlayerList();
          ok(p.isSleeping(), "fixture sleeping at night");
        }
        case 510 -> {
          ok(Police.jailed(p), "actual night skip triggered dawn arrest");
          ok(p.blockPosition().distSqr(cell) < 6, "server teleported player to configured jail");
          Police.pardon(p);
          ok(!Police.jailed(p), "operator pardon releases sentence");
          var civilians =
              p.serverLevel().getEntitiesOfClass(CityNpc.class, p.getBoundingBox().inflate(80));
          if (civilians.size() >= 2) {
            var first = civilians.get(0);
            var second = civilians.get(1);
            tp(
                p,
                new BlockPos(
                    (int) ((net.minecraft.world.entity.Entity) first).getX(),
                    ((net.minecraft.world.entity.Entity) first).blockPosition().getY(),
                    (int) ((net.minecraft.world.entity.Entity) first).getZ()));
            ((net.minecraft.world.entity.Entity) second)
                .teleportTo(p.getX() + 1, p.getY(), p.getZ() + 1);
            Police.crime(p, first, "проверка свидетельства");
            ok(Police.wanted(p), "incident opens a persistent police case");
            Police.pardon(p);
          }
          tp(p, p.serverLevel().getSharedSpawnPos());
          District.send(p, "", "");
          com.mojang.logging.LogUtils.getLogger().info("KONTUR_QA COMPLETE");
        }
        default -> {}
      }
    } catch (Throwable err) {
      failed = true;
      com.mojang.logging.LogUtils.getLogger().error("KONTUR_QA FAILED at tick " + age, err);
    }
  }
}
