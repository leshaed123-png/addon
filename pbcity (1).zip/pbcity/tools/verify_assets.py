from pathlib import Path
import json,re,zipfile
root=Path(__file__).resolve().parents[1];a=root/'src/main/resources/assets/pbcity';raw=(root/'src/main/java/com/pbcity/district/Stock.java').read_text();ids=re.findall(r'new Product\(\s*"([a-z_0-9]+)"',raw);assert len(ids)==len(set(ids))==20
for f in (root/'src/main/resources').rglob('*'):
 if f.suffix in ('.json','.mcmeta'):json.loads(f.read_text())
for name in ids+['sealed_parcel']:
 m=json.loads((a/'models/item'/('ledger_body.json' if name=='ledger' else name+'.json')).read_text());obj=a/m['model'].split(':')[1];txt=obj.read_text();assert (obj.parent/(name+'.mtl')).is_file() and txt.count('\nf ')>=60;assert (a/'textures/kontur/products'/(name+'.png')).is_file();assert (a/'textures/item/print'/(name+'.png')).is_file()
for i in range(49):assert (a/f'textures/kontur/faces/{i:02d}.png').is_file() and (a/f'textures/entity/npc/skin_{i:02d}.png').is_file()
assert (root/'src/main/resources/data/pbcity/structures/kontur_quarter.nbt').is_file()
print('OK: 20 registered catalogue records + bound parcel, 21 actual OBJ meshes, 49 matching skins/portraits; all JSON resources parse.')
