"""Original playable microdistrict (46×36), exported as a real Java structure template; requires nbtlib only to regenerate."""
from pathlib import Path
import nbtlib as n,json,random
from nbtlib import Compound as C, List as L, Int as I, String as S, Byte as B
rng=random.Random(701);blocks={};pal=[];indices={}
def put(x,y,z,id,tag=None,**props):
 assert 0<=x<46 and 0<=z<36 and 0<=y<16,(x,y,z)
 key=(id,tuple(sorted(props.items())))
 if key not in indices:
  t=C({'Name':S(id if ':' in id else 'minecraft:'+id)});
  if props:t['Properties']=C({k:S(v) for k,v in props.items()})
  indices[key]=len(pal);pal.append(t)
 blocks[x,y,z]=(indices[key],tag)
def fill(a,b,id,**props):
 for x in range(a[0],b[0]+1):
  for y in range(a[1],b[1]+1):
   for z in range(a[2],b[2]+1):put(x,y,z,id,**props)
def door(x,z,face):
 for h,half in enumerate(['lower','upper']):put(x,1+h,z,'birch_door',facing=face,hinge='left',half=half,open='false',powered='false')
def sign(x,y,z,face,*s):
 msg=list(s)+['']*(4-len(s));txt=C({'messages':L[S]([S(json.dumps({'text':t},ensure_ascii=False)) for t in msg]),'color':S('black'),'has_glowing_text':B(0)});put(x,y,z,'birch_wall_sign',C({'id':S('minecraft:sign'),'front_text':txt,'back_text':C({'messages':L[S]([S('""')]*4),'color':S('black'),'has_glowing_text':B(0)}),'is_waxed':B(1)}),facing=face)
for x in range(46):
 for z in range(36):
  road=x in range(19,26) or z in range(18,22);id=('gray_concrete' if road else ('smooth_stone' if (x+z)%6 else 'polished_andesite'))
  if road and ((x==22 and z%7 in [1,2,3] and z not in range(16,24)) or (z==20 and x%8 in (2,3,4) and x not in range(17,28))):id='light_gray_concrete'
  if x in range(19,26,2) and z in (16,23):id='quartz_block'
  put(x,0,z,id)
def build(x0,z0,x1,z1,floors,wall,band,doorx,front=True):
 roof=1+floors*4;fz=z1 if front else z0
 for y in range(1,roof):
  for x in range(x0,x1+1):
   for z in range(z0,z1+1):
    shell=x in (x0,x1) or z in (z0,z1)
    if y%4==0:put(x,y,z,band if shell else 'smooth_sandstone');continue
    if not shell:continue
    edge=(x in (x0,x1) and z in (z0,z1));window=not edge and y%4 in (2,3) and ((x not in (x0,x1) and (x-x0)%4 in (1,2)) or (z not in (z0,z1) and (z-z0)%4 in (1,2)))
    put(x,y,z,'light_gray_stained_glass' if window else wall)
 fill((x0,roof,z0),(x1,roof,z1),'smooth_stone');fill((x0+1,roof+1,z0+1),(x0+4,roof+1,z0+3),'iron_block');put(x0+2,roof+2,z0+2,'daylight_detector');fill((x1-2,roof+1,z0+2),(x1-1,roof+1,z0+4),'copper_block');
 door(doorx,fz,'south' if front else 'north');fill((x0+1,0,z0+1),(x1-1,0,z1-1),'polished_diorite');
 for x in range(x0+2,x1-1,5):
  for z in range(z0+2,z1-1,5):put(x,4,z,'sea_lantern');
 for x in range(x0+1,x1):put(x,3,fz+(1 if front else -1),band if (x-x0)%3 else 'smooth_quartz_slab',**({'type':'top'} if (x-x0)%3==0 else {}))
 return fz
build(4,2,16,13,2,'smooth_sandstone','cut_copper',10);sign(10,4,14,'south','К  /  07','ТИПОГРАФИЯ','Выдача','09 — 22');fill((6,1,5),(12,1,5),'oak_planks');put(10,2,5,'lectern',facing='south');put(6,1,10,'barrel',facing='up');put(7,1,10,'cartography_table');put(14,1,4,'bookshelf');put(14,2,4,'bookshelf');put(9,0,15,'orange_terracotta');
build(29,2,43,13,3,'light_gray_concrete','dark_prismarine',35);sign(35,4,14,'south','STUDIO','РАДИО 09','ЭФИР','07.10');fill((32,1,5),(39,1,5),'spruce_planks');put(34,2,5,'note_block');put(36,2,5,'jukebox');put(42,1,7,'bookshelf');put(42,2,7,'bookshelf');put(29,1,15,'pbcity:atm',facing='south');put(29,0,15,'polished_andesite');
build(4,25,16,34,2,'white_terracotta','weathered_cut_copper',10,False);sign(10,4,24,'north','ЛИНИЯ 07','КАФЕ «ПАР»','& комнаты','Кофе • лапша');put(8,1,30,'red_bed',part='foot',facing='east');put(9,1,30,'red_bed',part='head',facing='east');put(6,1,32,'smoker',facing='north');put(7,1,32,'barrel',facing='up');fill((11,1,31),(14,1,31),'oak_planks');put(12,2,31,'flower_pot');put(14,1,27,'bookshelf');
build(29,25,43,34,1,'polished_andesite','cyan_terracotta',33,False);sign(34,4,24,'north','ПЕРВОМАЙСК','УЧАСТОК 07','Дежурная часть','24 / 7');fill((36,1,26),(36,3,33),'iron_bars');put(36,1,29,'iron_door',facing='west',half='lower');put(36,2,29,'iron_door',facing='west',half='upper');fill((37,1,31),(40,1,31),'smooth_stone_slab',type='bottom');put(31,1,29,'lectern',facing='north');
for x,z in [(3,15),(16,16),(27,8),(27,23),(44,22),(2,24)]:
 fill((x,1,z),(x,4,z),'polished_deepslate_wall');put(x,5,z,'sea_lantern');put(x,6,z,'smooth_stone_slab',type='bottom')
for x,z in [(1,3),(18,3),(27,33),(1,32),(44,5),(43,16)]:
 put(x,0,z,'grass_block');fill((x,1,z),(x,3,z),'oak_log',axis='y')
 for dx in (-1,0,1):
  for dz in (-1,0,1):
   if abs(dx)+abs(dz)<2 or rng.random()>.4:put(x+dx,4,z+dz,'azalea_leaves',persistent='true',distance='1')
 put(x,5,z,'azalea_leaves',persistent='true',distance='1')
for x,z in [(11,16),(37,16),(13,23)]:
 for k in range(3):put(x+k,1,z,'spruce_stairs',facing='north',half='bottom',shape='straight')
# A tiny covered tram stop by the west edge; all mission points are unobstructed at standing height.
for x in (2,6):fill((x,1,16),(x,3,16),'iron_bars')
fill((1,4,15),(7,4,16),'weathered_cut_copper_slab',type='bottom');put(2,0,9,'green_terracotta');put(32,0,17,'green_terracotta');
out=L[C]([])
for (x,y,z),(state,be) in sorted(blocks.items(),key=lambda t:(t[0][1],t[0][2],t[0][0])):
 t=C({'pos':L[I]([I(x),I(y),I(z)]),'state':I(state)});
 if be:t['nbt']=be
 out.append(t)
f=R=Path(__file__).resolve().parents[1]/'src/main/resources/data/pbcity/structures/kontur_quarter.nbt';f.parent.mkdir(parents=True,exist_ok=True);n.File({'DataVersion':I(3465),'size':L[I]([I(46),I(16),I(36)]),'palette':L[C](pal),'blocks':out,'entities':L[C]([])},gzipped=True).save(f);print(len(blocks),'blocks;',len(pal),'states')
