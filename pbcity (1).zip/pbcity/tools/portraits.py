"""Add printed-fabric detail and painted faces at 4× UV resolution, then photograph the exact same UV regions."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,cv2,random,math
R=Path(__file__).resolve().parents[1]/'src/main/resources/assets/pbcity';S=4;V=np.array
F=lambda x:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',x)
def tint(rgb,k,offset=0):return tuple(int(v) for v in np.clip(np.array(rgb[:3])*k+offset,0,255))
for i in range(49):
 rng=random.Random(1130+i);idx=i%8;src=R/f'textures/entity/npc/skin_{i:02d}.png';base=Image.open(src).convert('RGBA').resize((64,64),Image.Resampling.NEAREST);skin=base.getpixel((12,13))[:3];hair=base.getpixel((9,1))[:3];coat=base.getpixel((21,24))[:3];acc=base.getpixel((16,32))[:3];is_cap=idx in (0,3) or i==48;im=base.resize((256,256),Image.Resampling.NEAREST);d=ImageDraw.Draw(im)
 def box(x,y,w,h,color):d.rectangle((int(x*S),int(y*S),max(int(x*S),int((x+w)*S)-1),max(int(y*S),int((y+h)*S)-1)),fill=color)
 def path(points,color,width=.25):d.line([(round(x*S),round(y*S)) for x,y in points],fill=color,width=max(1,round(width*S)))
 # Paint full front face with individually varied brow, nose and lip shapes; the eye positions remain readable in world.
 box(8,8,8,8,skin);box(8,8,8,1.4,hair);box(8,9.2,1,.8,hair);box(15.2,9.2,.8,1.6,hair)
 for side in (0,1):
  x=9.0+side*3.8;rise=(i%3-1)*.24;w=1.8+((i+side)%2)*.22;eye=tuple([(92,116,114),(112,83,58),(81,87,68)][i%3]);path([(x-.05,10.65+rise),(x+.65,10.35),(x+w,10.5-rise)],tint(hair,.85),.4);box(x,11.1,w,.7,(231,221,201));box(x+.55+side*.17,11.05,.75,.85,eye);box(x+.76+side*.17,11.12,.35,.65,tint(eye,.58));box(x+.65+side*.17,11.05,.25,.25,(234,232,212));path([(x,11.05),(x+w,11.1)],tint(skin,.64),.21)
 for x,z in [(8.65,12.55),(14.35,12.55)]:box(x,z,1.1,.53,tint(skin,.96));
 path([(11.75,11.75),(11.4,12.9),(12.4,13.1)],tint(skin,.81),.32);box(11.7,12.65,.7,.3,tint(skin,1.07));mx=10.9+(i%2)*.25;path([(mx,14.1),(mx+.6,13.9),(mx+1.4,14.0),(mx+2.2,13.95+(i%3-1)*.2)],tint(skin,.66),.3);box(mx+.5,14.34,1.1,.26,tint(skin,1.05));
 if idx in (1,4):
  for k in range(38):
   x=rng.uniform(8.4,15.7);y=rng.uniform(13.3,15.8)
   if y>14.65 or x<9.5 or x>14.3:box(x,y,.28,.24,tint(hair,1.25,10))
 for q in range(24):
  x=8+(q%8);y=8+.1+rng.random()*.9;path([(x+.25,y),(x+.07,y+1.0+rng.random()*.5)],tint(hair,rng.uniform(.9,1.28),4),.3)
 if idx in (2,7):
  for x in (8.5,12.7):
   path([(x,10.8),(x+2.8,10.8),(x+2.6,12.25),(x+.3,12.25),(x,10.8)],(62,64,56),.31)
  path([(11.3,11.05),(12.6,11.05)],(62,64,56),.25);path([(15.4,10.8),(16,10.6)],(62,64,56),.4)
 # Higher-resolution fabric seams, zips, pocket flaps & coat fasteners.
 for x in (20.5,27.3):path([(x,21.9),(x+.1,24),(x+.35,29.7)],tint(coat,.79),.22)
 for yy in [23.9,25.6,27.3,29.0]:box(23.15,yy,.38,.38,tint(acc,.96))
 path([(20.5,20.1),(22.5,22.4),(23.5,21.6)],tint(coat,1.3),.4);path([(27.55,20.1),(25.4,22.5),(24.1,21.7)],tint(coat,.7),.44);box(24.9,25.2,2.4,.34,acc);box(26.6,26,.4,.35,tint(acc,.83))
 if i==48:box(20.6,23.4,1.2,1.25,(217,180,102));box(25.1,23.2,1.7,.6,(204,191,147))
 for k in range(19):
  x=rng.randrange(82,110);y=rng.randrange(95,120);dc=im.getpixel((x,y));d.point((x,y),fill=tint(dc,rng.uniform(.96,1.08)))
 im.save(src,optimize=True)
 # Orthographic portrait with layered head texture and the same accessory family as ResidentModel.
 W,H=192,224;yy,xx=np.mgrid[:H,:W];t=np.maximum(0,1-np.sqrt(((xx-62)/210)**2+((yy-62)/220)**2));c0=V(tint(coat,.64));c1=V(tint(coat,1,46));pic=np.uint8(c0[None,None,:]*(1-t[:,:,None])+c1[None,None,:]*t[:,:,None]);I=np.array(im);U=lambda a:tuple(i*4 for i in a)
 def part(u,v,w,h,z,x,y,ww,hh,deep,hat=False):
  dh=deep*.55;slope=.075;front=(u+z,v+z,u+z+w,v+z+h);top=(u+z,v,u+z+w,v+z);side=(u+w+z,v+z,u+w+z*2,v+z+h)
  def quad(rect,pts,m,off=None):
   x0,y0,x1,y1=U(rect);tx=I[y0:y1,x0:x1,:].copy();
   if hat:
    lap=I[y0:y1,x0+32*S:x1+32*S];alpha=lap[:,:,3:]/255.;tx[:,:,:3]=tx[:,:,:3]*(1-alpha)+lap[:,:,:3]*alpha
   pts=V(pts,dtype='float32');hh0,ww0=tx.shape[:2];srcpts=V([[0,0],[ww0-1,0],[ww0-1,hh0-1],[0,hh0-1]],'float32');a=cv2.getPerspectiveTransform(srcpts,pts);b=cv2.warpPerspective(tx[:,:,:3],a,(W,H),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE);mask=np.zeros((H,W),'uint8');cv2.fillConvexPoly(mask,np.round(pts).astype('int32'),255);pic[mask>0]=np.clip(b[mask>0]*m,0,255)
  v0=(x,y);v1=(x+ww,y+ww*slope);v2=(v1[0]+deep,v1[1]-dh);v3=(x+deep,y-dh);quad(side,[v1,v2,(v2[0],v2[1]+hh),(v1[0],v1[1]+hh)],.76);quad(top,[v3,v2,v1,v0],1.09);quad(front,[v0,v1,(v1[0],v1[1]+hh),(x,y+hh)],1.02)
 part(40,16,4,12,4,12,130,30,96,12);part(16,16,8,12,4,43,135,78,98,26);part(32,48,4,12,4,121,141,30,92,16);part(0,0,8,8,8,41,49,83,82,34,True);pi=Image.fromarray(pic);pd=ImageDraw.Draw(pi)
 if is_cap:pd.polygon([(38,62),(119,68),(111,73),(27,68)],fill=tint(coat,.82));pd.line([(27,67),(111,72)],fill=tint(coat,1.1),width=2)
 if idx in (2,7):pd.polygon([(150,67),(160,65),(162,89),(152,95),(147,89)],fill=tint(coat,.64));pd.line([(151,86),(159,82)],fill=acc,width=2)
 pd.text((8,8),'K / ID',font=F(9),fill=(225,229,207));pd.text((W-8,8),f'{i:03}',anchor='ra',font=F(9),fill=(224,231,212));pd.line((8,24,27,24),fill=(184,202,185));pi.save(R/f'textures/kontur/faces/{i:02d}.png',optimize=True)
