package com.pbcity.econ;

import java.util.List;

/** Legal marketplace: groceries and snacks delivered to your inventory. Prices in euro cents. */
public final class Grocery {
    public record Entry(String ns, String id, String label, String blurb, long cents, int count) {}

    private static Entry mc(String id, String label, String blurb, long cents, int count) {
        return new Entry("minecraft", id, label, blurb, cents, count);
    }

    public static final List<Entry> CATALOG = List.of(
            mc("mushroom_stew", "Доширак: курица", "Лапша быстрого приготовления", 150, 1),
            mc("rabbit_stew", "Доширак: говядина", "Лапша со вкусом говядины", 170, 1),
            mc("bread", "Хлеб «Бородинский»", "Свежая буханка", 120, 2),
            mc("cooked_beef", "Стейк с гарниром", "Готовое блюдо", 650, 1),
            mc("cooked_chicken", "Курица гриль", "Тёплая, в пакете", 480, 1),
            mc("baked_potato", "Картошка фри", "Большая порция", 250, 2),
            mc("pumpkin_pie", "Пирог с вишней", "Из пекарни", 300, 1),
            mc("cookie", "Печенье «Юбилейное»", "Набор 8 шт", 200, 8),
            mc("apple", "Яблоки", "Антоновка, 3 шт", 180, 3),
            mc("carrot", "Морковь свежая", "Пучок", 90, 3),
            mc("milk_bucket", "Молоко 3.2%", "Литр", 140, 1),
            mc("honey_bottle", "Энергетик", "Банка 0.5 л", 220, 1),
            mc("golden_carrot", "Фруктовый набор", "Витамины, подарочный", 800, 1),
            mc("cake", "Торт «Наполеон»", "Целый, на праздник", 1_500, 1));

    private Grocery() {}
}
