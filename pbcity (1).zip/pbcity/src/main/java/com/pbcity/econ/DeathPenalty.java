package com.pbcity.econ;

import com.pbcity.PBCity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Dying costs 30% of your cash and 20% of the BIT on your phone. Coins on a Ledger are not touched. */
@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DeathPenalty {
    private DeathPenalty() {}

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        CompoundTag t = PlayerFunds.tag(p);
        long cash = t.getLong("cash");
        long lost = cash * 3 / 10;
        double bit = t.getDouble("bit");
        double lostBit = bit * 0.2;
        if (lost <= 0 && lostBit <= 0) return;
        t.putLong("cash", cash - lost);
        t.putDouble("bit", bit - lostBit);
        p.sendSystemMessage(Component.literal("Ты потерял " + PlayerFunds.fmt(lost) + " наличными и "
                + String.format("%.5f", lostBit) + " BIT с телефона. Ledger не пострадал."));
    }
}
