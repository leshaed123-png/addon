package com.pbcity.econ;

/** Simulated BIT price in euro: a pure function of game time, so server and client agree without packets. */
public final class BitMarket {
    private BitMarket() {}

    public static double price(long gameTime) {
        double t = gameTime / 20.0;
        return 40000.0 * (1.0 + 0.25 * Math.sin(t / 300.0) + 0.12 * Math.sin(t / 71.0 + 1.0)
                + 0.05 * Math.sin(t / 17.0 + 2.0));
    }
}
