package com.pbcity.econ;

import com.pbcity.item.GoodsItem;
import com.pbcity.item.ModItems;
import com.pbcity.item.PackageItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

/** DarkNet catalogue (40 entries: Point Blank guns and ammo, plus gear) and resale values. Prices in euro cents. */
public final class Shop {
    public record Entry(String ns, String id, String label, long cents, int count) {}

    private static Entry pb(String id, String label, long cents, int count) { return new Entry("pointblank", id, label, cents, count); }
    private static Entry mc(String id, String label, long cents, int count) { return new Entry("minecraft", id, label, cents, count); }

    public static final List<Entry> CATALOG = List.of(
            pb("glock17", "Glock-17", 60_000, 1), pb("m9", "M9", 55_000, 1), pb("usp45", "USP .45", 70_000, 1),
            pb("m1911a1", "M1911A1", 75_000, 1), pb("deserteagle", "Desert Eagle", 150_000, 1),
            pb("mp5", "MP5", 220_000, 1), pb("mp7", "MP7", 260_000, 1), pb("ump45", "UMP-45", 240_000, 1),
            pb("vector", "Vector", 300_000, 1), pb("p90", "P90", 320_000, 1),
            pb("ak47", "AK-47", 450_000, 1), pb("ak74", "AK-74", 430_000, 1), pb("m4a1", "M4A1", 480_000, 1),
            pb("hk416", "HK416", 560_000, 1), pb("g36c", "G36C", 520_000, 1), pb("aug", "AUG", 580_000, 1),
            pb("m870", "M870", 300_000, 1), pb("spas12", "SPAS-12", 380_000, 1), pb("m590", "M590", 280_000, 1),
            pb("l96a1", "L96A1", 900_000, 1), pb("mk14ebr", "Mk14 EBR", 800_000, 1), pb("wa2000", "WA2000", 1_100_000, 1),
            pb("ammo9mm", "9mm x30", 4_000, 30), pb("ammo45acp", ".45 ACP x30", 5_000, 30),
            pb("ammo556", "5.56mm x30", 6_000, 30), pb("ammo545", "5.45mm x30", 6_000, 30),
            pb("ammo762", "7.62mm x30", 7_000, 30), pb("ammo338lapua", ".338 Lapua x30", 12_000, 30),
            mc("iron_chestplate", "Бронежилет", 120_000, 1), mc("iron_helmet", "Тактический шлем", 60_000, 1),
            mc("iron_leggings", "Боевые штаны", 80_000, 1), mc("iron_boots", "Берцы", 50_000, 1),
            mc("golden_apple", "Аптечка x3", 30_000, 3), mc("honey_bottle", "Энергетик x4", 8_000, 4),
            mc("spyglass", "Бинокль", 25_000, 1), mc("tripwire_hook", "Набор отмычек x4", 12_000, 4),
            mc("iron_axe", "Монтировка", 15_000, 1), mc("lead", "Верёвка x3", 6_000, 3),
            mc("name_tag", "Левая симка", 5_000, 1), mc("paper", "Поддельные документы", 20_000, 1),
            new Entry("pbcity", "ledger", "Ledger (холодный кошелёк)", 15_000, 1));

    private Shop() {}

    /** What a bot buyer would pay at most for this stack (cents); 0 = not tradable. */
    public static long resaleValue(ItemStack s) {
        if (s.isEmpty()) return 0;
        if (s.getItem() instanceof PackageItem && s.hasTag())
            return (long) s.getTag().getInt("units") * s.getTag().getInt("quality") * 50L * s.getCount();
        if (s.getItem() instanceof GoodsItem && s.hasTag()) {
            double f = s.is(ModItems.COCAINE.get()) ? 1.6 : s.is(ModItems.CRYSTALS.get()) ? 1.3
                    : s.is(ModItems.MEPHEDRONE.get()) ? 1.0 : 0.6;
            return Math.round(s.getTag().getInt("units") * s.getTag().getInt("quality") * 50L * f * s.getCount());
        }
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (key == null || !key.getNamespace().equals("pointblank")) return 0;
        for (Entry e : CATALOG)
            if (e.ns.equals("pointblank") && e.id.equals(key.getPath()))
                return Math.round(e.cents * 0.6 / e.count * s.getCount());
        return 0;
    }
}
