package com.pbcity.econ;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

import java.util.Locale;

/** Cash and bank balance in euro cents, stored in the player's persisted NBT (survives death). */
public final class PlayerFunds {
    private PlayerFunds() {}

    public static CompoundTag tag(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(Player.PERSISTED_NBT_TAG)) root.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag pers = root.getCompound(Player.PERSISTED_NBT_TAG);
        if (!pers.contains("pbcity")) {
            CompoundTag t = new CompoundTag();
            t.putLong("cash", 50_000L);   // EUR 500.00 starting cash
            t.putLong("bank", 150_000L);  // EUR 1,500.00 starting bank balance
            pers.put("pbcity", t);
        }
        return pers.getCompound("pbcity");
    }

    public static long cash(Player p) { return tag(p).getLong("cash"); }
    public static long bank(Player p) { return tag(p).getLong("bank"); }
    /** Operators can switch a player to an unlimited balance (EUR 1,000,000,000 floor). */
    public static final long INF = 100_000_000_000L;
    public static boolean unlimited(Player p) { return tag(p).getBoolean("inf"); }
    public static void toggleUnlimited(Player p,boolean on){
        var t=tag(p);if(on==unlimited(p))return;
        if(on){t.putLong("preCash",cash(p));t.putLong("preBank",bank(p));t.putBoolean("inf",true);setCash(p,cash(p));setBank(p,bank(p));}
        else{t.putBoolean("inf",false);if(t.contains("preCash")){setCash(p,t.getLong("preCash"));setBank(p,t.getLong("preBank"));t.remove("preCash");t.remove("preBank");}}
    }
    public static void setCash(Player p, long v) { tag(p).putLong("cash", unlimited(p) ? Math.max(v, INF) : Math.min(900_000_000_000_000L,Math.max(0, v))); }
    public static void setBank(Player p, long v) { tag(p).putLong("bank", unlimited(p) ? Math.max(v, INF) : Math.min(900_000_000_000_000L,Math.max(0, v))); }

    /** Dirty cash = money from deals and robberies that has not been laundered through a crypto wallet. */
    public static long dirty(Player p) { return Math.min(tag(p).getLong("dirty"), cash(p)); }
    public static void addDirty(Player p, long c) { if (c > 0) tag(p).putLong("dirty", tag(p).getLong("dirty") + c); }
    public static void cleanDirty(Player p, long c) { tag(p).putLong("dirty", Math.max(0, tag(p).getLong("dirty") - c)); }
    /** Dirty money that was put into a bank account: traceable, triggers a raid. */
    public static long traced(Player p) { return tag(p).getLong("traced"); }
    public static void addTraced(Player p, long c) { if (c > 0) tag(p).putLong("traced", tag(p).getLong("traced") + c); }
    public static void clearTraced(Player p) { tag(p).putLong("traced", 0); }

    public static String fmt(long cents) {
        return String.format(Locale.ROOT, "€%,.2f", cents / 100.0);
    }
}
