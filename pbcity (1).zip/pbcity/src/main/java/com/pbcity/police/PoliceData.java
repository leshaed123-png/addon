package com.pbcity.police;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** World-wide police settings: where the jail is. */
public class PoliceData extends SavedData {
  public BlockPos jail;

  public static PoliceData get(MinecraftServer s) {
    return s.overworld()
        .getDataStorage()
        .computeIfAbsent(PoliceData::load, PoliceData::new, "pbcity_police");
  }

  public static PoliceData load(CompoundTag t) {
    PoliceData d = new PoliceData();
    if (t.contains("jail")) d.jail = BlockPos.of(t.getLong("jail"));
    return d;
  }

  @Override
  public CompoundTag save(CompoundTag t) {
    if (jail != null) t.putLong("jail", jail.asLong());
    return t;
  }

  public BlockPos jailOrSpawn(MinecraftServer s) {
    return jail != null ? jail : s.overworld().getSharedSpawnPos();
  }
}
