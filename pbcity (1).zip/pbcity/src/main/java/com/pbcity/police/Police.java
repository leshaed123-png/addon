package com.pbcity.police;

import com.pbcity.config.PBConfig;
import com.pbcity.district.District;
import com.pbcity.econ.PlayerFunds;
import com.pbcity.npc.*;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.SleepFinishedTimeEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Cases, dawn visits and sentences belong to this player in this save, not to static process maps.
 */
@Mod.EventBusSubscriber(modid = "pbcity")
public final class Police {
  static long now(ServerPlayer p) {
    return p.getServer().overworld().getGameTime();
  }

  public static boolean wanted(ServerPlayer p) {
    return PlayerFunds.tag(p).getLong("caseDue") > 0;
  }

  public static boolean jailed(ServerPlayer p) {
    return PlayerFunds.tag(p).getLong("jailUntil") > now(p);
  }

  public static String status(ServerPlayer p) {
    var t = PlayerFunds.tag(p);
    return jailed(p)
        ? "В участке · " + (t.getLong("jailUntil") - now(p) + 19) / 20 + " с"
        : t.getLong("raidDue") > 0
            ? "Наряд у двери"
            : wanted(p) ? "Поступило заявление" : "Нет открытых дел";
  }

  public static void pardon(ServerPlayer p) {
    var t = PlayerFunds.tag(p);
    boolean release = jailed(p);
    for (String k : new String[] {"caseDue", "caseName", "raidDue", "jailUntil"}) t.remove(k);
    PlayerFunds.clearTraced(p);
    if (release) release(p);
  }

  public static void crime(ServerPlayer p, CityNpc victim, String why) {
    if (wanted(p) || jailed(p)) return;
    var sl = p.serverLevel();
    boolean witness =
        !sl.getEntitiesOfClass(
                CityNpc.class,
                victim.getBoundingBox().inflate(24),
                n -> n != victim && n.isAlive() && n.hasLineOfSight(p))
            .isEmpty();
    if (!witness && !victim.isAlive()) return;
    var t = PlayerFunds.tag(p);
    t.putLong("caseDue", now(p) + PBConfig.WANTED_SECONDS.get() * 20L);
    t.putString("caseName", why);
    District.notice(
        p,
        "Полиция",
        (witness ? "Поступило заявление свидетеля: " : "Потерпевший сообщил: ") + why);
  }

  @SubscribeEvent
  public static void assault(net.minecraftforge.event.entity.living.LivingHurtEvent e) {
    if (e.getAmount() >= 4
        && e.getEntity() instanceof CityNpc n
        && e.getSource().getEntity() instanceof ServerPlayer p) crime(p, n, "нападение на жителя");
  }

  @SubscribeEvent
  public static void death(LivingDeathEvent e) {
    if (e.getEntity() instanceof CityNpc n && e.getSource().getEntity() instanceof ServerPlayer p)
      crime(p, n, "нападение на жителя");
  }

  @SubscribeEvent
  public static void rob(PlayerInteractEvent.EntityInteract e) {
    if (e.getLevel().isClientSide()
        || e.getHand() != InteractionHand.MAIN_HAND
        || !(e.getEntity() instanceof ServerPlayer p)
        || !p.isShiftKeyDown()
        || !(e.getTarget() instanceof CityNpc n)
        || n.getRole() != CityNpc.Role.CIVILIAN
        || n.appearance() == 48
        || n.getPersistentData().hasUUID("districtOwner")) return;
    var key = ForgeRegistries.ITEMS.getKey(p.getMainHandItem().getItem());
    if (key == null || !key.getNamespace().equals("pointblank")) return;
    e.setCanceled(true);
    e.setCancellationResult(InteractionResult.SUCCESS);
    if (jailed(p) || n.getPersistentData().getBoolean("robbed")) {
      p.displayClientMessage(Component.literal("Здесь больше нечего взять."), true);
      return;
    }
    n.getPersistentData().putBoolean("robbed", true);
    long amount = 2000 + p.getRandom().nextInt(14000);
    PlayerFunds.setCash(p, PlayerFunds.cash(p) + amount);
    PlayerFunds.addDirty(p, amount);
    District.notice(p, "Наличные", "Получено без квитанции: " + PlayerFunds.fmt(amount));
    crime(p, n, "ограбление");
  }

  @SubscribeEvent
  public static void dawn(SleepFinishedTimeEvent e) {
    if (!(e.getLevel() instanceof ServerLevel sl) || e.getNewTime() <= sl.getDayTime()) return;
    for (var p : sl.players())
      if (p.isSleeping() && !jailed(p) && (PlayerFunds.dirty(p) > 0 || PlayerFunds.traced(p) > 0)) {
        PlayerFunds.tag(p).putLong("raidDue", now(p) + 100);
        sl.playSound(
            null,
            p.blockPosition(),
            SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR,
            SoundSource.BLOCKS,
            .55f,
            1.1f);
        officer(p);
        District.notice(
            p, "Полиция", "Стук в дверь. Утренний наряд: проверка неподтверждённых выплат.");
      }
  }

  private static void officer(ServerPlayer p) {
    var l = p.serverLevel();
    var n = ModEntities.CITY_NPC.get().create(l);
    if (n == null) return;
    var pos = p.blockPosition();
    for (var d : net.minecraft.core.Direction.Plane.HORIZONTAL) {
      var v = pos.relative(d, 2);
      if (l.isEmptyBlock(v) && l.isEmptyBlock(v.above()) && l.getBlockState(v.below()).isSolid()) {
        pos = v;
        break;
      }
    }
    n.init(CityNpc.Role.CIVILIAN, l.getRandom());
    n.setAppearance(48);
    n.setCustomName(Component.literal("Дежурный инспектор"));
    n.moveTo(pos.getX() + .5, pos.getY(), pos.getZ() + .5, 0, 0);
    n.getPersistentData().putLong("guestUntil", now(p) + 240);
    n.setPersistenceRequired();
    l.addFreshEntity(n);
    n.getLookControl().setLookAt(p);
  }

  @SubscribeEvent
  public static void tick(TickEvent.ServerTickEvent e) {
    if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 10 != 0) return;
    for (var p : e.getServer().getPlayerList().getPlayers()) {
      var t = PlayerFunds.tag(p);
      long now = now(p),
          j = t.getLong("jailUntil"),
          raid = t.getLong("raidDue"),
          report = t.getLong("caseDue");
      if (j > 0) {
        if (j <= now) {
          t.remove("jailUntil");
          release(p);
          District.notice(p, "Участок", "Срок закончился. Ты свободен.");
        } else {
          var v = PoliceData.get(p.getServer()).jailOrSpawn(p.getServer());
          if (p.level() != p.getServer().overworld() || p.blockPosition().distSqr(v) > 25)
            teleport(p, v);
        }
        continue;
      }
      if (raid > 0 && raid <= now) {
        arrest(p, "Утренняя проверка");
        continue;
      }
      if (report > 0 && report <= now) {
        officer(p);
        arrest(p, t.getString("caseName"));
      }
    }
  }

  private static void teleport(ServerPlayer p, BlockPos v) {
    p.teleportTo(p.getServer().overworld(), v.getX() + .5, v.getY(), v.getZ() + .5, p.getYRot(), 0);
  }

  private static void release(ServerPlayer p) {
    var ow = p.getServer().overworld();
    teleport(p, ow.getSharedSpawnPos());
  }

  public static void arrest(ServerPlayer p, String why) {
    var t = PlayerFunds.tag(p);
    long d = PlayerFunds.dirty(p);
    PlayerFunds.cleanDirty(p, t.getLong("dirty"));
    PlayerFunds.setCash(p, PlayerFunds.cash(p) - d);
    PlayerFunds.clearTraced(p);
    long fine = PlayerFunds.unlimited(p) ? 0 : PlayerFunds.bank(p) / 10;
    PlayerFunds.setBank(p, PlayerFunds.bank(p) - fine);
    t.remove("raidDue");
    t.remove("caseDue");
    int secs = PBConfig.JAIL_SECONDS.get();
    t.putLong("jailUntil", now(p) + secs * 20L);
    teleport(p, PoliceData.get(p.getServer()).jailOrSpawn(p.getServer()));
    District.notice(
        p, "Участок", why + " · штраф " + PlayerFunds.fmt(fine) + " · срок " + secs + " с");
  }

  private Police() {}
}
