package com.pbcity.mixin;

import com.pbcity.ballistics.Ballistics;
import com.pbcity.ballistics.BallisticsGuard;
import com.pbcity.ballistics.WindManager;
import com.pbcity.config.PBConfig;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * Point Blank's HitScan.getNearestObjectInCrosshair(entity, start, dir, f, maxDist, p1, p2, list) casts ONE straight
 * ray. We replace it by a chain of short rays along a simulated bullet path (gravity + quadratic drag + wind).
 * Blocks (with Point Blank's pass-through rules) still come from the ORIGINAL method per segment. Entities are
 * scanned here per segment, because the original only searches the area next to the shooter, which made every
 * segment after the first miss all entities.
 */
@Mixin(targets = "com.vicmatskiv.pointblank.util.HitScan", remap = false)
public abstract class HitScanMixin {

    @Shadow
    public static HitResult getNearestObjectInCrosshair(LivingEntity e, Vec3 start, Vec3 dir, float f, double max,
                                                        Predicate<?> a, Predicate<?> b, List<?> l) {
        throw new AssertionError();
    }

    @Inject(
        method = "getNearestObjectInCrosshair(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;FDLjava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/List;)Lnet/minecraft/world/phys/HitResult;",
        at = @At("HEAD"), cancellable = true, remap = false)
    private static void pbcity$ballistic(LivingEntity shooter, Vec3 start, Vec3 dir, float f, double max,
                                         Predicate<?> a, Predicate<?> b, List<?> l,
                                         CallbackInfoReturnable<HitResult> cir) {
        if (BallisticsGuard.active() || shooter == null || !PBConfig.ENABLED.get()) return;
        BallisticsGuard.enter();
        try {
            Vec3 wind = WindManager.wind(shooter.level());
            List<Vec3> pts = Ballistics.trajectory(start, dir, max, wind,
                    PBConfig.MUZZLE_VELOCITY.get(), PBConfig.DRAG_K.get());
            HitResult last = null;
            for (int i = 0; i + 1 < pts.size(); i++) {
                Vec3 p0 = pts.get(i);
                Vec3 d = pts.get(i + 1).subtract(p0);
                double len = d.length();
                if (len < 1e-6) continue;
                HitResult r = getNearestObjectInCrosshair(shooter, p0, d.scale(1.0 / len), f, len, a, b, l);
                last = r;

                Entity bestE = null;
                Vec3 bestV = null;
                double bestT = Double.MAX_VALUE;
                AABB box = new AABB(p0, pts.get(i + 1)).inflate(1.3);
                for (Entity e : shooter.level().getEntities(shooter, box)) {
                    if (e.isSpectator() || !e.isPickable() || !e.isAlive()) continue;
                    Optional<Vec3> c = e.getBoundingBox().inflate(0.3).clip(p0, pts.get(i + 1));
                    if (c.isPresent()) {
                        double t = p0.distanceTo(c.get());
                        if (t < bestT) { bestT = t; bestE = e; bestV = c.get(); }
                    }
                }
                double blockT = Double.MAX_VALUE;
                if (r instanceof BlockHitResult bh && bh.getType() != HitResult.Type.MISS) {
                    blockT = p0.distanceTo(bh.getLocation());
                } else if (r instanceof EntityHitResult eh) {
                    double t = p0.distanceTo(eh.getLocation());
                    if (t < bestT) { bestT = t; bestE = eh.getEntity(); bestV = eh.getLocation(); }
                }
                if (bestE != null && bestT <= blockT) {
                    cir.setReturnValue(new EntityHitResult(bestE, bestV));
                    return;
                }
                if (blockT < Double.MAX_VALUE) {
                    cir.setReturnValue(r);
                    return;
                }
            }
            cir.setReturnValue(last);
        } finally {
            BallisticsGuard.exit();
        }
    }
}
