package com.pbcity.block;

import com.pbcity.econ.PlayerFunds;
import com.pbcity.property.PropertyData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;

/** "For sale" sign: click = info, sneak-click = buy (or sell back if you own it). Registered with /pbcity property. */
public class PropertySignBlock extends HorizontalDirectionalBlock {
    public PropertySignBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(FACING); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite());
    }

    @Override
    public InteractionResult use(BlockState s, Level level, BlockPos pos, Player p, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide || hand != InteractionHand.MAIN_HAND || !(p instanceof ServerPlayer sp))
            return InteractionResult.sidedSuccess(level.isClientSide);
        PropertyData d = PropertyData.get(level.getServer());
        PropertyData.Prop prop = d.at(pos);
        long day = level.getServer().overworld().getDayTime() / 24000L;
        String msg;
        if (prop == null) {
            msg = "Unregistered sign. Admins: /pbcity property <type> [price in euro]";
        } else if (prop.owner == null) {
            msg = p.isShiftKeyDown() ? d.buy(sp, pos, day)
                    : prop.type.label + " for sale: " + PlayerFunds.fmt(prop.price)
                      + (prop.type.income > 0 ? " | income " + PlayerFunds.fmt(prop.type.income) + "/day" : "")
                      + " | sneak+click to buy";
        } else if (prop.owner.equals(p.getUUID())) {
            msg = p.isShiftKeyDown() ? d.sell(sp, pos.asLong())
                    : "Yours: " + prop.type.label + " | sneak+click to sell back for " + PlayerFunds.fmt(prop.price * 8 / 10);
        } else {
            msg = prop.type.label + " owned by " + prop.ownerName;
        }
        p.displayClientMessage(Component.literal(msg), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!level.isClientSide && !state.is(newState.getBlock())) PropertyData.get(level.getServer()).remove(pos);
        super.onRemove(state, level, pos, newState, moved);
    }
}
