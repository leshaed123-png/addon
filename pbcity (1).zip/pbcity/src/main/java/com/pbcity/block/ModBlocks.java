package com.pbcity.block;

import com.pbcity.PBCity;
import com.pbcity.item.ModItems;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, PBCity.MODID);
    public static final RegistryObject<Block> ATM = BLOCKS.register("atm",
            () -> new AtmBlock(BlockBehaviour.Properties.of().strength(3.0f, 6.0f).sound(SoundType.METAL)));
    public static final RegistryObject<Item> ATM_ITEM = ModItems.ITEMS.register("atm",
            () -> new BlockItem(ATM.get(), new Item.Properties()));
    public static final RegistryObject<Block> PROPERTY_SIGN = BLOCKS.register("property_sign",
            () -> new PropertySignBlock(BlockBehaviour.Properties.of().strength(2.0f, 6.0f).sound(SoundType.METAL).noOcclusion()));
    public static final RegistryObject<Item> PROPERTY_SIGN_ITEM = ModItems.ITEMS.register("property_sign",
            () -> new BlockItem(PROPERTY_SIGN.get(), new Item.Properties()));
    private ModBlocks() {}
}
