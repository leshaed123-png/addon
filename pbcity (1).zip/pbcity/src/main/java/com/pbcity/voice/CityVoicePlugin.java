package com.pbcity.voice;

import com.google.gson.JsonParser;
import com.pbcity.PBCity;
import com.pbcity.config.PBConfig;
import com.pbcity.npc.NpcService;
import de.maxhenkel.voicechat.api.*;
import de.maxhenkel.voicechat.api.events.*;
import de.maxhenkel.voicechat.api.opus.OpusDecoder;
import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * SVC transport; explicit per-player opt-in, no group calls, bounded PCM and transcription queue.
 */
@ForgeVoicechatPlugin
public class CityVoicePlugin implements VoicechatPlugin {
  private static final int CAP = 48000 * 2 * 8;

  private static final class Buf {
    final ByteArrayOutputStream pcm = new ByteArrayOutputStream();
    long last;
    OpusDecoder decoder;
    ServerPlayer player;
    boolean closed;
  }

  private final Map<UUID, Buf> buffers = new ConcurrentHashMap<>();
  private final Set<UUID> busy = ConcurrentHashMap.newKeySet();

  private static Thread daemon(Runnable r, String n) {
    Thread t = new Thread(r, n);
    t.setDaemon(true);
    return t;
  }

  private final ScheduledExecutorService timer =
      Executors.newSingleThreadScheduledExecutor(r -> daemon(r, "pbcity-voice-clock"));
  private final ThreadPoolExecutor workers =
      new ThreadPoolExecutor(
          1, 2, 20, TimeUnit.SECONDS, new ArrayBlockingQueue<>(8), r -> daemon(r, "pbcity-asr"));
  private final HttpClient http =
      HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
  private volatile VoicechatServerApi api;
  private ScheduledFuture<?> flushTask;

  @Override
  public String getPluginId() {
    return PBCity.MODID;
  }

  @Override
  public void initialize(VoicechatApi a) {}

  @Override
  public void registerEvents(EventRegistration reg) {
    reg.registerEvent(
        VoicechatServerStartedEvent.class,
        e -> {
          api = e.getVoicechat();
          SvcBridge.api = api;
          if (flushTask != null) flushTask.cancel(false);
          flushTask = timer.scheduleAtFixedRate(this::flush, 250, 180, TimeUnit.MILLISECONDS);
        });
    reg.registerEvent(MicrophonePacketEvent.class, this::mic);
    reg.registerEvent(PlayerDisconnectedEvent.class, e -> drop(e.getPlayerUuid()));
    reg.registerEvent(
        VoicechatServerStoppedEvent.class,
        e -> {
          api = null;
          SvcBridge.api = null;
          if (flushTask != null) flushTask.cancel(false);
          for (var id : List.copyOf(buffers.keySet())) drop(id);
        });
  }

  private void drop(UUID id) {
    Buf b = buffers.remove(id);
    if (b != null)
      synchronized (b) {
        b.closed = true;
        b.pcm.reset();
        b.decoder.close();
      }
  }

  private void mic(MicrophonePacketEvent e) {
    var a = api;
    var conn = e.getSenderConnection();
    if (a == null
        || conn == null
        || conn.isInGroup()
        || PBConfig.STT_URL.get().isBlank()
        || !(conn.getPlayer().getPlayer() instanceof ServerPlayer p)
        || !VoiceConsent.listening(p.getUUID())
        || busy.contains(p.getUUID())) return;
    byte[] data = e.getPacket().getOpusEncodedData();
    if (data == null || data.length == 0) return;
    Buf b =
        buffers.computeIfAbsent(
            p.getUUID(),
            k -> {
              var n = new Buf();
              n.decoder = a.createDecoder();
              n.player = p;
              return n;
            });
    synchronized (b) {
      if (b.closed || b.pcm.size() >= CAP) return;
      short[] samples = b.decoder.decode(data);
      for (short v : samples) {
        b.pcm.write(v & 255);
        b.pcm.write(v >>> 8 & 255);
      }
      b.last = System.currentTimeMillis();
    }
  }

  private void flush() {
    long now = System.currentTimeMillis();
    for (var en : buffers.entrySet()) {
      var id = en.getKey();
      var b = en.getValue();
      if (!VoiceConsent.allowed(id)) {
        drop(id);
        continue;
      }
      byte[] raw;
      synchronized (b) {
        if (b.closed || b.pcm.size() == 0 || b.pcm.size() < CAP && now - b.last < 650) continue;
        raw = b.pcm.toByteArray();
        b.pcm.reset();
      }
      if (raw.length < 24_000 || !busy.add(id)) continue;
      try {
        workers.execute(
            () -> {
              try {
                stt(b.player, raw);
              } finally {
                busy.remove(id);
              }
            });
      } catch (RejectedExecutionException full) {
        busy.remove(id);
      }
    }
  }

  private void stt(ServerPlayer p, byte[] pcm) {
    try {
      var server = p.getServer();
      if (server == null || !VoiceConsent.allowed(p.getUUID())) return;
      var r =
          HttpRequest.newBuilder(URI.create(PBConfig.STT_URL.get()))
              .timeout(Duration.ofSeconds(22))
              .header("Content-Type", "audio/wav");
      String key = PBConfig.TTS_KEY.get();
      if (!key.isBlank()) r.header("Authorization", "Bearer " + key);
      var res =
          http.send(
              r.POST(HttpRequest.BodyPublishers.ofByteArray(Wav.wav16(pcm, 48000))).build(),
              HttpResponse.BodyHandlers.ofInputStream());
      String json;
      try (var body = res.body()) {
        if (res.statusCode() != 200) return;
        json = new String(body.readNBytes(8192), java.nio.charset.StandardCharsets.UTF_8);
      }
      String line =
          JsonParser.parseString(json).getAsJsonObject().get("text").getAsString().strip();
      if (line.isEmpty()) return;
      String clean = line.substring(0, Math.min(180, line.length()));
      server.execute(
          () -> {
            if (p.isRemoved() || !VoiceConsent.allowed(p.getUUID())) return;
            p.sendSystemMessage(Component.literal("[Микрофон] " + clean));
            NpcService.onChat(p, clean);
          });
    } catch (Exception ex) {
      com.mojang.logging.LogUtils.getLogger().debug("[PB City] Speech service: {}", ex.toString());
    }
  }
}
