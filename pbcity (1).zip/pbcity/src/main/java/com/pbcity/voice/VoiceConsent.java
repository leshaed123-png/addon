package com.pbcity.voice;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Only explicitly opted-in players' microphone packets may go to speech recognition. */
public final class VoiceConsent {
  private static final Set<UUID> ALLOWED = ConcurrentHashMap.newKeySet();
  private static final Set<UUID> TALKING = ConcurrentHashMap.newKeySet();

  public static boolean listening(UUID id) {
    return ALLOWED.contains(id) && TALKING.contains(id);
  }

  public static void nearby(UUID id, boolean active) {
    if (active) TALKING.add(id);
    else TALKING.remove(id);
  }

  public static boolean allowed(UUID id) {
    return ALLOWED.contains(id);
  }

  public static void set(UUID id, boolean on) {
    if (on) ALLOWED.add(id);
    else {
      ALLOWED.remove(id);
      TALKING.remove(id);
    }
  }

  private VoiceConsent() {}
}
