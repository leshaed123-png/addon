package com.pbcity.voice;

import com.google.gson.JsonObject;
import com.pbcity.config.PBConfig;
import com.pbcity.npc.CityNpc;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.audiochannel.AudioPlayer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import net.minecraft.server.level.ServerLevel;

/**
 * Speaks an NPC line through Simple Voice Chat as a positional sound at the NPC. Each NPC gets a
 * fixed voice id (UUID hash) sent to the TTS service, plus a small pitch offset so even a
 * single-voice TTS gives every resident a different timbre.
 */
final class SvcBridge {
  static volatile VoicechatServerApi api;
  private static final HttpClient HTTP =
      HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();
  private static final ExecutorService POOL =
      new java.util.concurrent.ThreadPoolExecutor(
          2,
          2,
          30,
          java.util.concurrent.TimeUnit.SECONDS,
          new java.util.concurrent.ArrayBlockingQueue<>(12),
          r -> {
            Thread t = new Thread(r, "pbcity-tts");
            t.setDaemon(true);
            return t;
          },
          new java.util.concurrent.ThreadPoolExecutor.DiscardPolicy());

  private SvcBridge() {}

  static void speak(ServerLevel level, CityNpc npc, String text, UUID listener) {
    VoicechatServerApi a = api;
    if (a == null) return;
    int voice = Math.floorMod(npc.getUUID().hashCode(), PBConfig.VOICE_COUNT.get());
    double pitch =
        0.90 + Math.floorMod(npc.getUUID().getLeastSignificantBits(), 25L) / 100.0; // 0.90 .. 1.14
    double x = npc.getX(), y = npc.getEyeY(), z = npc.getZ();
    String clean =
        text.substring(0, Math.min(text.length(), 480))
            .replaceAll("[\\r\\n]+", " ")
            .replaceAll("\\(.*?\\)", "")
            .trim();
    if (clean.isEmpty()) return;
    POOL.execute(
        () -> {
          try {
            JsonObject body = new JsonObject();
            body.addProperty("text", clean);
            body.addProperty("voice", voice);
            body.addProperty("lang", "ru");
            HttpRequest.Builder rb =
                HttpRequest.newBuilder(URI.create(PBConfig.TTS_URL.get()))
                    .timeout(Duration.ofSeconds(30))
                    .header("Content-Type", "application/json");
            if (!PBConfig.TTS_KEY.get().isEmpty())
              rb.header("Authorization", "Bearer " + PBConfig.TTS_KEY.get());
            var res =
                HTTP.send(
                    rb.POST(HttpRequest.BodyPublishers.ofString(body.toString())).build(),
                    HttpResponse.BodyHandlers.ofInputStream());
            byte[] wav;
            try (var in = res.body()) {
              if (res.statusCode() != 200) return;
              wav = in.readNBytes(4_000_001);
            }
            if (wav.length > 4_000_000 || api != a) return;
            short[] pcm = Wav.to48kMono(wav, pitch);
            if (pcm.length == 0) return;
            de.maxhenkel.voicechat.api.audiochannel.AudioChannel ch;
            if (listener != null) {
              var conn = a.getConnectionOf(listener);
              if (conn == null || !conn.isConnected()) return;
              ch = a.createStaticAudioChannel(UUID.randomUUID(), a.fromServerLevel(level), conn);
            } else {
              var loc =
                  a.createLocationalAudioChannel(
                      UUID.randomUUID(), a.fromServerLevel(level), a.createPosition(x, y, z));
              if (loc == null) return;
              loc.setDistance(24f);
              ch = loc;
            }
            if (ch == null) return;
            final int[] pos = {0};
            var encoder = a.createEncoder();
            AudioPlayer pl =
                a.createAudioPlayer(
                    ch,
                    encoder,
                    () -> {
                      if (pos[0] >= pcm.length) return null;
                      short[] frame = new short[960];
                      int n = Math.min(960, pcm.length - pos[0]);
                      System.arraycopy(pcm, pos[0], frame, 0, n);
                      pos[0] += 960;
                      return frame;
                    });
            pl.setOnStopped(encoder::close);
            pl.startPlaying();
          } catch (Exception ignored) {
          }
        });
  }
}
