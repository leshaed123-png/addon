package com.pbcity.ballistics;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Laser measurement along a living entity's line of sight; works on both logical sides. */
public final class Raycast {
    public record Result(double dist, Entity target, Vec3 hit, double pitch) {}

    private Raycast() {}

    public static Result measure(LivingEntity e, double maxR) {
        Vec3 eye = e.getEyePosition();
        Vec3 look = e.getLookAngle();
        Vec3 end = eye.add(look.scale(maxR));
        BlockHitResult b = e.level().clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, e));
        double d = b.getType() == HitResult.Type.MISS ? -1 : b.getLocation().distanceTo(eye);
        double lim = d < 0 ? maxR : d;
        Vec3 hit = d < 0 ? end : b.getLocation();
        AABB box = e.getBoundingBox().expandTowards(look.scale(lim)).inflate(1.0);
        EntityHitResult er = ProjectileUtil.getEntityHitResult(e, eye, end, box,
                en -> !en.isSpectator() && en.isPickable(), lim * lim);
        Entity t = null;
        if (er != null) { d = er.getLocation().distanceTo(eye); t = er.getEntity(); hit = er.getLocation(); }
        return new Result(d, t, hit, -e.getXRot());
    }

    /** Speed in m/s from the last tick's movement. */
    public static double speed(Entity e) {
        return new Vec3(e.getX() - e.xo, e.getY() - e.yo, e.getZ() - e.zo).length() * 20.0;
    }
}
