package com.pbcity.ballistics;

/** Re-entrancy guard: our mixin calls the original ray method per path segment. */
public final class BallisticsGuard {
    private static final ThreadLocal<Boolean> ACTIVE = ThreadLocal.withInitial(() -> false);
    private BallisticsGuard() {}
    public static boolean active() { return ACTIVE.get(); }
    public static void enter() { ACTIVE.set(true); }
    public static void exit() { ACTIVE.set(false); }
}
