package com.pbcity.ballistics;

import com.pbcity.config.PBConfig;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Deterministic wind: a pure function of dimension + game time, so client and server agree without packets. */
public final class WindManager {
    private WindManager() {}

    /** Wind velocity in m/s: the direction the air is moving TOWARD. */
    public static Vec3 wind(Level level) {
        double t = level.getGameTime() / 20.0;
        int deg = Math.floorMod(level.dimension().location().hashCode(), 360);
        double gust = PBConfig.WIND_GUST.get();
        double ang = Math.toRadians(deg) + 0.9 * Math.sin(t / 180.0) + 0.5 * Math.sin(t / 47.0 + 1.3);
        double spd = PBConfig.WIND_BASE.get()
                + gust * Math.sin(t / 95.0) + gust * 0.6 * Math.sin(t / 23.0 + 0.7);
        if (level.isThundering()) spd += 6.0;
        else if (level.isRaining()) spd += 3.0;
        spd = Math.max(0.0, spd);
        return new Vec3(Math.cos(ang) * spd, 0.0, Math.sin(ang) * spd);
    }
}
