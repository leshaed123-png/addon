package com.pbcity.ballistics;

import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public final class Ballistics {
    public static final double G = 9.81;
    public static final double DT = 0.01;
    private Ballistics() {}

    /** Polyline of the bullet path (points ~v*DT apart), cut at maxDist of path length. */
    public static List<Vec3> trajectory(Vec3 origin, Vec3 dir, double maxDist, Vec3 wind, double v0, double k) {
        List<Vec3> pts = new ArrayList<>();
        Vec3 p = origin;
        Vec3 v = dir.normalize().scale(v0);
        pts.add(p);
        double travelled = 0;
        for (int i = 0; i < 700 && travelled < maxDist; i++) {
            Vec3 rel = v.subtract(wind);
            Vec3 a = rel.scale(-k * rel.length()).add(0, -G, 0);
            Vec3 nv = v.add(a.scale(DT));
            Vec3 np = p.add(v.add(nv).scale(0.5 * DT));
            double seg = np.subtract(p).length();
            if (seg < 1e-9) break;
            if (travelled + seg > maxDist) {
                np = p.add(np.subtract(p).scale((maxDist - travelled) / seg));
                seg = maxDist - travelled;
            }
            travelled += seg;
            p = np;
            v = nv;
            pts.add(p);
        }
        return pts;
    }

    /** Bullet drop (meters, positive = below the bore line) at a horizontal range, no wind. */
    public static double dropAt(double range, double v0, double k) {
        if (range <= 0) return 0;
        List<Vec3> pts = trajectory(Vec3.ZERO, new Vec3(1, 0, 0), range * 1.02, Vec3.ZERO, v0, k);
        for (Vec3 q : pts) if (q.x >= range) return -q.y;
        return -pts.get(pts.size() - 1).y;
    }

    /** Time of flight (s) to a horizontal range, no wind. */
    public static double flightTime(double range, double v0, double k) {
        List<Vec3> pts = trajectory(Vec3.ZERO, new Vec3(1, 0, 0), range * 1.02, Vec3.ZERO, v0, k);
        for (int i = 0; i < pts.size(); i++) if (pts.get(i).x >= range) return i * DT;
        return (pts.size() - 1) * DT;
    }
}
