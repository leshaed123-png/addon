package com.pbcity.district;

import com.pbcity.econ.*;
import com.pbcity.item.ModItems;
import com.pbcity.npc.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * One persistent, player-owned shipment. The server checks dimension, parcel nonce, recipient and
 * proximity.
 */
public final class Deliveries {
  public record Brief(
      String title, String client, String object, String blurb, int euros, String photo) {}

  public static final List<Brief> BOARD =
      List.of(
          new Brief(
              "Последний тираж",
              "Типография № 4",
              "коробку с журналами",
              "Свежий выпуск ждут у вечернего киоска.",
              180,
              "eink"),
          new Brief(
              "Плёнка проявлена",
              "Фотолаборатория",
              "кассету с негативами",
              "Забери плёнку из лаборатории до закрытия.",
              240,
              "camera"),
          new Brief(
              "Ночная смена",
              "Кафе «Полоса»",
              "ужин для смены",
              "На линии ночует бригада. Ужин уже упакован.",
              155,
              "bento"),
          new Brief(
              "Голос квартала",
              "Радиостанция 09",
              "полевые записи",
              "Архивист ждёт оригинал уличного эфира.",
              320,
              "recorder"),
          new Brief(
              "Тёплая остановка",
              "Лапшичная «Пар»",
              "набор лапши",
              "Две чашки для дежурных на конечной.",
              135,
              "ramen_chili"),
          new Brief(
              "Тихая сторона",
              "Магазин пластинок",
              "демокассету",
              "Передай пробную запись куратору выставки.",
              210,
              "cassette"));

  public static CompoundTag job(ServerPlayer p) {
    return PlayerFunds.tag(p).getCompound("districtJob");
  }

  public static String clock(long ticks) {
    long mins = Math.floorMod(ticks + 6000, 24000) * 1440 / 24000;
    return String.format(Locale.ROOT, "%02d:%02d", mins / 60, mins % 60);
  }

  static String accept(ServerPlayer p, long index, String variant) {
    var t = PlayerFunds.tag(p);
    if (!District.simOn(p)) return "Активируй SIM в приложении связи";
    if (!job(p).isEmpty()) return "Сначала заверши или отмени текущую доставку";
    if (p.level().dimension() != Level.OVERWORLD) return "Заказы доступны в обычном мире";
    if (index < 0 || index >= BOARD.size()) return "Заявка недоступна";
    boolean alley = !variant.equals("square");
    var pickup = Stops.find(p, "pickup", 10, 5);
    var meet = Stops.find(p, alley ? "alley" : "square", alley ? -22 : 28, alley ? 23 : -17);
    if (pickup == null || meet == null)
      return "Нет доступной площадки. Перейди на улицу или попроси оператора задать точки.";
    var sl = p.serverLevel();
    var n = ModEntities.CITY_NPC.get().create(sl);
    if (n == null) return "Контакт вне сети";
    n.init(CityNpc.Role.CIVILIAN, sl.getRandom());
    n.moveTo(meet.getX() + .5, meet.getY(), meet.getZ() + .5, 140f, 0);
    n.setPersistenceRequired();
    n.restrictTo(meet, 2);
    n.getPersistentData().putUUID("districtOwner", p.getUUID());
    n.getPersistentData().putLong("districtStop", meet.asLong());
    n.getPersistentData().putLong("guestUntil", sl.getGameTime() + 48_000);
    if (!sl.addFreshEntity(n)) return "Сейчас не удаётся назначить встречу";
    var b = BOARD.get((int) index);
    var j = new CompoundTag();
    j.putInt("brief", (int) index);
    j.putUUID("nonce", UUID.randomUUID());
    j.putUUID("recipient", n.getUUID());
    j.putInt("skin", n.appearance());
    j.putString("name", n.npcName());
    j.putString("location", alley ? "Переулок" : "Площадь");
    j.putString("dim", sl.dimension().location().toString());
    j.putLong("pickup", pickup.asLong());
    j.putLong("meet", meet.asLong());
    j.putInt("phase", 1);
    j.putLong("ready", sl.getGameTime() + 200);
    j.putString("time", clock(sl.getDayTime() + 200));
    j.putLong("expires", sl.getGameTime() + 48_000);
    j.putLong("reward", b.euros * 100L);
    t.put("districtJob", j);
    District.log(
        p,
        b.client,
        "Вот фото: "
            + n.npcName()
            + ". Забери "
            + b.object
            + ". Встреча: "
            + j.getString("location")
            + ", с "
            + j.getString("time")
            + ".",
        n.appearance());
    return "Получено фото · " + n.npcName();
  }

  static boolean near(ServerPlayer p, BlockPos v, double dist) {
    return p.distanceToSqr(v.getX() + .5, v.getY(), v.getZ() + .5) <= dist * dist;
  }

  static String pick(ServerPlayer p) {
    var j = job(p);
    if (j.isEmpty() || j.getInt("phase") != 1) return "Нет отправления для выдачи";
    if (!p.level().dimension().location().toString().equals(j.getString("dim"))
        || !near(p, BlockPos.of(j.getLong("pickup")), 5)) return "Подойди к точке выдачи на карте";
    var s = new ItemStack(ModItems.SEALED.get());
    s.getOrCreateTag().putUUID("dispatch", j.getUUID("nonce"));
    s.setHoverName(Component.literal("Посылка: " + BOARD.get(j.getInt("brief")).title));
    if (!p.getInventory().add(s)) return "Нужно свободное место для посылки";
    j.putInt("phase", 2);
    District.log(
        p,
        "Диспетчер",
        "Посылка на руках. Подойди к получателю и нажми ПКМ. Адрес выплаты можно изменить в"
            + " переписке.",
        -1);
    return "Посылка получена";
  }

  private static ItemStack parcel(ServerPlayer p, CompoundTag j) {
    for (var s : p.getInventory().items)
      if (s.is(ModItems.SEALED.get())
          && s.hasTag()
          && s.getTag().hasUUID("dispatch")
          && s.getTag().getUUID("dispatch").equals(j.getUUID("nonce"))) return s;
    var s = p.getOffhandItem();
    return s.is(ModItems.SEALED.get())
            && s.hasTag()
            && s.getTag().hasUUID("dispatch")
            && s.getTag().getUUID("dispatch").equals(j.getUUID("nonce"))
        ? s
        : ItemStack.EMPTY;
  }

  static String route(ServerPlayer p, String address) {
    var j = job(p);
    if (j.isEmpty()) return "Нет открытой переписки по заказу";
    int i = Wallets.which(p, address);
    if (i < 0) return "Нужен адрес своего игрового кошелька. Для Ledger возьми устройство.";
    String canonical = i == Wallets.LEDGER ? address : Wallets.address(p, i);
    j.putString("address", canonical);
    j.putInt("wallet", i);
    District.log(p, "Вы", canonical, -1);
    District.log(
        p,
        j.getString("name"),
        "Принято. Выплата на " + Wallets.NAMES[i] + " · " + Wallets.shortId(canonical),
        j.getInt("skin"));
    return "Адрес для выплаты сохранён";
  }

  public static boolean interact(ServerPlayer p, CityNpc n) {
    if (!n.getPersistentData().hasUUID("districtOwner")) return false;
    var j = job(p);
    if (j.isEmpty() || !j.getUUID("recipient").equals(n.getUUID())) {
      p.displayClientMessage(Component.literal("Получатель ожидает своего курьера."), true);
      return true;
    }
    String result = finish(p, n, j);
    if (result != null) District.send(p, "Узел 09", result);
    return true;
  }

  private static String finish(ServerPlayer p, CityNpc n, CompoundTag j) {
    if (com.pbcity.police.Police.jailed(p)) return "Выдача недоступна во время задержания";
    if (!p.serverLevel().dimension().location().toString().equals(j.getString("dim"))
        || p.distanceToSqr(n) > 36
        || !n.isAlive()) return "Подойди к получателю";
    if (j.getInt("phase") != 2) return "Сначала забери посылку на точке выдачи";
    if (p.level().getGameTime() < j.getLong("ready"))
      return "Получатель готовит накладную до " + j.getString("time");
    var s = parcel(p, j);
    if (s.isEmpty()) return "Нужна посылка именно из этого заказа";
    String addr = j.getString("address");
    long pay = j.getLong("reward");
    String line, source;
    if (!addr.isEmpty()) {
      int i = Wallets.which(p, addr);
      double units = pay / (100d * BitMarket.price(p.level().getGameTime()));
      if (i < 0 || !Wallets.credit(p, addr, units))
        return "Подключи тот же Ledger или пришли другой адрес в переписку";
      source = Wallets.NAMES[i];
      line = "Зачислено +" + Wallets.bit(units) + " · " + PlayerFunds.fmt(pay);
    } else {
      PlayerFunds.setCash(p, PlayerFunds.cash(p) + pay);
      PlayerFunds.addDirty(p, pay);
      source = "Касса";
      line = "Наличные +" + PlayerFunds.fmt(pay) + " · выплата без квитанции";
    }
    s.shrink(1);
    var t = PlayerFunds.tag(p);
    t.remove("districtJob");
    t.putInt("districtDone", t.getInt("districtDone") + 1);
    n.getPersistentData().remove("districtOwner");
    n.getPersistentData().putLong("guestUntil", p.level().getGameTime() + 1200);
    n.clearRestriction();
    District.log(p, source, line, -1);
    District.send(p, source, line);
    return null;
  }

  static String cancel(ServerPlayer p) {
    var j = job(p);
    if (j.isEmpty()) return "Нет открытой доставки";
    var sl = p.getServer().overworld();
    if (sl.getEntity(j.getUUID("recipient")) instanceof CityNpc c) c.discard();
    var s = parcel(p, j);
    if (!s.isEmpty()) s.shrink(1);
    PlayerFunds.tag(p).remove("districtJob");
    return "Заявка закрыта без выплаты";
  }

  private Deliveries() {}
}
