package com.pbcity.district;

import com.pbcity.econ.*;
import com.pbcity.item.LedgerItem;
import java.util.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Not blockchain addresses. Dotted PB ids are meaningful only in this save. All amounts are in-game
 * BIT.
 */
public final class Wallets {
  public static final String[] NAMES = {"Bybit", "Binance", "Orbit", "North", "Ledger"};
  public static final int LEDGER = 4;

  private static String key(int i) {
    return i == 0 ? "bit" : "districtWallet" + i;
  }

  private static List<ItemStack> ledgers(ServerPlayer p) {
    List<ItemStack> out = new ArrayList<>();
    var inv = p.getInventory();
    if (p.getMainHandItem().getItem() instanceof LedgerItem) out.add(p.getMainHandItem());
    for (int i = 0; i < inv.getContainerSize(); i++) {
      var s = inv.getItem(i);
      if (s.getItem() instanceof LedgerItem && s != p.getMainHandItem()) out.add(s);
    }
    return out;
  }

  private static String serial(ItemStack s) {
    var t = s.getOrCreateTag();
    if (!t.hasUUID("districtSerial")) t.putUUID("districtSerial", UUID.randomUUID());
    return t.getUUID("districtSerial").toString();
  }

  public static String address(ServerPlayer p, int i) {
    if (i < 0 || i > NAMES.length - 1) return "";
    if (i == LEDGER) {
      var all = ledgers(p);
      return all.isEmpty() ? "" : "PB.LG." + serial(all.get(0));
    }
    return "PB." + NAMES[i].toUpperCase(Locale.ROOT) + "." + p.getUUID();
  }

  static ItemStack resolve(ServerPlayer p, String id) {
    for (var s : ledgers(p)) if (("PB.LG." + serial(s)).equals(id)) return s;
    return ItemStack.EMPTY;
  }

  static int which(ServerPlayer p, String id) {
    if (id == null || id.isBlank()) return -1;
    for (int i = 0; i < LEDGER; i++) if (id.equalsIgnoreCase(address(p, i))) return i;
    return resolve(p, id).isEmpty() ? -1 : LEDGER;
  }

  private static CompoundTag account(ServerPlayer p, int i, String id) {
    if (i != LEDGER) return PlayerFunds.tag(p);
    var s = resolve(p, id);
    return s.isEmpty() ? null : s.getOrCreateTag();
  }

  private static String slot(int i) {
    return i == LEDGER ? "bit" : key(i);
  }

  static double balance(ServerPlayer p, int i, String id) {
    var t = account(p, i, id);
    return t == null ? 0 : t.getDouble(slot(i));
  }

  static boolean credit(ServerPlayer p, String id, double v) {
    int i = which(p, id);
    if (i < 0 || !Double.isFinite(v) || v <= 0) return false;
    var t = account(p, i, id);
    if (t == null) return false;
    t.putDouble(slot(i), t.getDouble(slot(i)) + v);
    return true;
  }

  static String trade(ServerPlayer p, String verb, String token, long cents) {
    int i;
    try {
      i = Integer.parseInt(token);
    } catch (Exception e) {
      return "Выбери кошелёк";
    }
    if (i < 0 || i >= NAMES.length || cents <= 0 || cents > 100_000_000L)
      return "Недопустимая сумма";
    String addr = address(p, i);
    if (addr.isEmpty()) return "Для Ledger нужен предмет в инвентаре";
    var t = account(p, i, addr);
    double price = BitMarket.price(p.level().getGameTime()), units = cents / (100d * price);
    String k = slot(i);
    if (verb.equals("sell")) {
      if (i == LEDGER && t.getLong("unlock") <= p.level().getGameTime())
        return "Для списания разблокируй свой Ledger";
      if (t.getDouble(k) < units) return "Недостаточно BIT";
      t.putDouble(k, t.getDouble(k) - units);
      PlayerFunds.setBank(p, PlayerFunds.bank(p) + Math.round(cents * .99));
      return "На счёт зачислено " + PlayerFunds.fmt(Math.round(cents * .99));
    }
    boolean cash = verb.equals("cashbit");
    if ((cash ? PlayerFunds.cash(p) : PlayerFunds.bank(p)) < cents) return "Недостаточно средств";
    if (cash) {
      PlayerFunds.cleanDirty(p, Math.min(cents, PlayerFunds.dirty(p)));
      PlayerFunds.setCash(p, PlayerFunds.cash(p) - cents);
    } else PlayerFunds.setBank(p, PlayerFunds.bank(p) - cents);
    t.putDouble(k, t.getDouble(k) + units * (cash ? .97 : .99));
    return NAMES[i] + " · +" + bit(units * (cash ? .97 : .99));
  }

  public static String bit(double v) {
    return String.format(Locale.ROOT, "%.6f BIT", v);
  }

  public static String shortId(String s) {
    return s.length() < 17
        ? s
        : s.substring(0, s.indexOf('.', 3) + 1) + "…" + s.substring(s.length() - 6);
  }

  private Wallets() {}
}
