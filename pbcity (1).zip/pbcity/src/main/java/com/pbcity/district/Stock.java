package com.pbcity.district;

import com.pbcity.econ.PlayerFunds;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * The registry id is identical for the delivered object, the baked item model and its catalogue
 * photo.
 */
public final class Stock {
  public record Product(
      String id, String title, String note, int price, int nutrition, int section) {}

  public static final List<Product> ALL =
      List.of(
          new Product("ramen_chicken", "Дошик · курица", "Чашка, 90 г", 165, 6, 0),
              new Product("ramen_chili", "Дошик · чили", "Чашка, 95 г", 195, 6, 0),
          new Product("ramen_miso", "Лапша мисо", "Кунжут, 90 г", 215, 6, 0),
              new Product("ramen_beef", "Дошик · говядина", "Чашка, 95 г", 185, 7, 0),
          new Product("coffee", "Флэт уайт", "Стакан, 250 мл", 320, 3, 1),
              new Product("matcha", "Матча латте", "Овсяное молоко", 360, 3, 1),
          new Product("soda", "Мандариновая газировка", "Банка, 330 мл", 175, 2, 1),
              new Product("berry", "Ягодный морс", "Банка, 330 мл", 205, 3, 1),
          new Product("bento", "Бэнто с рисом", "Обед из кулинарии", 690, 9, 0),
              new Product("sushi", "Набор маки", "Шесть роллов", 780, 8, 0),
          new Product("mochi", "Моти с клубникой", "В коробке, 3 шт.", 350, 4, 0),
              new Product("pudding", "Карамельный пудинг", "Десерт, 120 г", 285, 4, 0),
          new Product("eink", "Блокнот E-Ink", "Городская серия", 12900, 0, 2),
              new Product("headset", "Наушники Orbit", "Студийная серия", 8900, 0, 2),
          new Product("camera", "Камера Mono 35", "Плёночная серия", 16500, 0, 2),
              new Product("tablet", "Планшет Kontur", "Field Edition · F7", 29500, 0, 2),
          new Product("ledger", "Ledger", "Холодный кошелёк BIT", 18500, 0, 3),
              new Product("pager", "Пейджер P-09", "Лимитированная серия", 7900, 0, 3),
          new Product("cassette", "Кассета «Узел 09»", "Архив ночной линии", 2400, 0, 3),
              new Product("recorder", "Рекордер R-4", "Архивная техника", 12400, 0, 3));

  public static String buy(ServerPlayer p, long i) {
    if (i < 0 || i >= ALL.size()) return "Такого товара нет";
    var v = ALL.get((int) i);
    Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation("pbcity", v.id));
    if (item == null || item == Items.AIR) return "Товар недоступен";
    if (v.section == 3 && !District.simOn(p)) return "Нужна активная игровая SIM";
    if (PlayerFunds.bank(p) < v.price) return "Недостаточно средств на счёте";
    ItemStack s = new ItemStack(item);
    if (!p.getInventory().add(s)) return "Освободи место в инвентаре";
    PlayerFunds.setBank(p, PlayerFunds.bank(p) - v.price);
    return "Доставлено: " + v.title + " · −" + PlayerFunds.fmt(v.price);
  }

  private Stock() {}
}
