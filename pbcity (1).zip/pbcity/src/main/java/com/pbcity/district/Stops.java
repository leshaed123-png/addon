package com.pbcity.district;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.*;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "pbcity")
public final class Stops extends SavedData {
  private CompoundTag points = new CompoundTag();

  static Stops get(ServerLevel l) {
    return l.getDataStorage()
        .computeIfAbsent(
            t -> {
              var a = new Stops();
              a.points = t.copy();
              return a;
            },
            Stops::new,
            "pbcity_district_stops");
  }

  CompoundTag publicPoints() {
    return points.copy();
  }

  void set(String name, BlockPos pos) {
    points.putLong(name, pos.asLong());
    setDirty();
  }

  @Override
  public CompoundTag save(CompoundTag t) {
    t.merge(points);
    return t;
  }

  @SubscribeEvent
  public static void commands(RegisterCommandsEvent e) {
    var b = Commands.literal("point").requires(s -> s.hasPermission(2));
    for (String name : new String[] {"pickup", "alley", "square"})
      b.then(
          Commands.literal(name)
              .executes(
                  c -> {
                    var src = c.getSource();
                    var p = BlockPos.containing(src.getPosition());
                    var d = get(src.getLevel());
                    d.points.putLong(name, p.asLong());
                    d.setDirty();
                    src.sendSuccess(
                        () -> Component.literal("Точка " + name + ": " + p.toShortString()), true);
                    return 1;
                  }));
    e.getDispatcher().register(Commands.literal("pbcity").then(b));
  }

  static boolean safe(ServerLevel l, BlockPos p) {
    return l.hasChunkAt(p)
        && l.getWorldBorder().isWithinBounds(p)
        && l.getBlockState(p.below()).isFaceSturdy(l, p.below(), Direction.UP)
        && l.getFluidState(p).isEmpty()
        && l.getFluidState(p.below()).isEmpty()
        && l.getBlockState(p).getCollisionShape(l, p).isEmpty()
        && l.getBlockState(p.above()).getCollisionShape(l, p.above()).isEmpty();
  }

  static BlockPos find(ServerPlayer pl, String name, int dx, int dz) {
    ServerLevel l = pl.serverLevel();
    var d = get(l);
    if (d.points.contains(name)) {
      BlockPos v = BlockPos.of(d.points.getLong(name));
      return safe(l, v) ? v : null;
    }
    var orig = pl.blockPosition().offset(dx, 0, dz);
    for (int radius = 0; radius <= 12; radius += 2)
      for (int i = -radius; i <= radius; i += 2)
        for (int j = -radius; j <= radius; j += 2) {
          if (radius > 0 && Math.abs(i) != radius && Math.abs(j) != radius) continue;
          var pos = orig.offset(i, 0, j);
          if (!l.hasChunkAt(pos)) continue;
          var t = l.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, pos);
          if (Math.abs(t.getY() - pl.getY()) <= 14 && safe(l, t)) return t;
        }
    return null;
  }
}
