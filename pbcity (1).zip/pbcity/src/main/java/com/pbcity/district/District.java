package com.pbcity.district;

import com.pbcity.config.PBConfig;
import com.pbcity.econ.*;
import com.pbcity.net.*;
import com.pbcity.npc.NpcService;
import com.pbcity.police.*;
import com.pbcity.voice.VoiceConsent;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = "pbcity")
public final class District {
  private static final Set<String> ADMIN =
      Set.of("adminBank", "adminCash", "infOn", "infOff", "pardon", "setJail");

  private record Sequence(String digits, long after, long until) {}

  private static final Map<UUID, Sequence> SIM = new HashMap<>();
  private static final Map<UUID, long[]> RATE = new HashMap<>();

  public static boolean simOn(ServerPlayer p) {
    return !PlayerFunds.tag(p).getBoolean("simOff");
  }

  private static String cap(String s, int max) {
    return s.length() > max ? s.substring(0, max) : s;
  }

  public static void log(ServerPlayer p, String from, String text, int photo) {
    var t = PlayerFunds.tag(p);
    var list = t.getList("districtInbox", 10);
    var m = new CompoundTag();
    m.putString("from", cap(from, 48));
    m.putString("text", cap(text, 240));
    m.putInt("photo", photo);
    m.putString("at", Deliveries.clock(p.level().getDayTime()));
    list.add(m);
    while (list.size() > 32) list.remove(0);
    t.put("districtInbox", list);
  }

  public static void notice(ServerPlayer p, String from, String text) {
    log(p, from, text, -1);
    send(p, from, text);
  }

  public static void handle(ServerPlayer p, DistrictRequest r) {
    long now = p.level().getGameTime();
    var rate = RATE.computeIfAbsent(p.getUUID(), id -> new long[] {now, 0});
    if (rate[0] != now) {
      rate[0] = now;
      rate[1] = 0;
    }
    if (++rate[1] > 8) return;
    String op = r.op(), txt = r.text();
    long v = r.value();
    var t = PlayerFunds.tag(p);
    String msg = "", app = "Телефон";
    if (op.equals("sync")) {
      PropertyIncome.claim(p);
      send(p, "", "");
      return;
    }
    if (ADMIN.contains(op)) {
      admin(p, op, txt, v);
      return;
    }
    if (Police.jailed(p)
        && Set.of(
                "order", "pick", "buy", "walletBuy", "walletSell", "cashbit", "deposit", "withdraw")
            .contains(op)) {
      send(p, "Участок", "Операция недоступна во время задержания");
      return;
    }
    switch (op) {
      case "buy" -> {
        app = "Маркет";
        msg = Stock.buy(p, v);
      }
      case "order" -> {
        app = "Сообщения";
        msg = Deliveries.accept(p, v, txt);
      }
      case "cancel" -> {
        app = "Узел 09";
        msg = Deliveries.cancel(p);
      }
      case "pick" -> {
        app = "Диспетчер";
        msg = Deliveries.pick(p);
      }
      case "route" -> {
        app = "Сообщения";
        msg = Deliveries.route(p, txt);
      }
      case "send" -> {
        app = "Сообщения";
        var j = Deliveries.job(p);
        if (j.isEmpty()) {
          msg = "Сначала прими заявку";
          break;
        }
        if (txt.trim().toUpperCase(Locale.ROOT).startsWith("PB.")) {
          msg = Deliveries.route(p, txt.trim());
          break;
        }
        String q = txt.trim();
        if (q.isEmpty()) return;
        int named = -1;
        for (int i = 0; i < Wallets.NAMES.length; i++)
          if (q.equalsIgnoreCase(Wallets.NAMES[i])) named = i;
        if (q.equalsIgnoreCase("леджер")) named = Wallets.LEDGER;
        if (named >= 0) {
          msg = Deliveries.route(p, Wallets.address(p, named));
          break;
        }
        log(p, "Вы", q, -1);
        String answer = com.pbcity.npc.DistrictTalk.dispatch(q, j);
        log(p, j.getString("name"), answer, j.getInt("skin"));
        msg = "Ответ от " + j.getString("name");
      }
      case "walletBuy", "walletSell", "cashbit" -> {
        app = "Кошельки";
        msg = Wallets.trade(p, op.equals("walletSell") ? "sell" : op, txt, v);
      }
      case "deposit", "withdraw" -> {
        app = "Банк";
        boolean dep = op.equals("deposit");
        if (v <= 0 || v > 100_000_000L || v > (dep ? PlayerFunds.cash(p) : PlayerFunds.bank(p))) {
          msg = "Недостаточно средств или неверная сумма";
          break;
        }
        if (dep) {
          long d = Math.min(v, PlayerFunds.dirty(p));
          PlayerFunds.cleanDirty(p, d);
          PlayerFunds.addTraced(p, d);
        }
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + (dep ? -v : v));
        PlayerFunds.setBank(p, PlayerFunds.bank(p) + (dep ? v : -v));
        msg = (dep ? "Внесено " : "Выдано ") + PlayerFunds.fmt(v);
      }
      case "sim" -> {
        boolean on = v == 1;
        t.putBoolean("simOff", !on);
        msg = on ? "Городская SIM подключена" : "Профиль SIM приостановлен";
        app = "Mobile SIM";
      }
      case "voice" -> {
        boolean on = v == 1;
        t.putBoolean("micConsent", on);
        VoiceConsent.set(p.getUUID(), on);
        msg =
            on ? "Распознавание речи для NPC разрешено" : "Передача речи в распознавание выключена";
        app = "Голос NPC";
      }
      case "puzzle" -> {
        app = "Банк-сим";
        if (!simOn(p)) {
          msg = "Активируй SIM";
          break;
        }
        if (now < t.getLong("simNext")) {
          msg = "Следующая тренировка позже";
          break;
        }
        StringBuilder b = new StringBuilder();
        for (int k = 0; k < 4; k++) b.append(1 + p.getRandom().nextInt(4));
        SIM.put(p.getUUID(), new Sequence(b.toString(), now + 50, now + 600));
        msg = "Запомни четыре символа";
      }
      case "answer" -> {
        app = "Банк-сим";
        var s = SIM.remove(p.getUUID());
        if (!simOn(p) || s == null || now < s.after || now > s.until || !s.digits.equals(txt)) {
          msg = "Цепочка не совпала. Попробуй ещё раз.";
          break;
        }
        t.putLong("simNext", now + 2400);
        PlayerFunds.setBank(p, PlayerFunds.bank(p) + 2500);
        msg = "Учебный счёт восстановлен · +€25,00";
      }
      default -> {
        return;
      }
    }
    if (Set.of("buy", "walletBuy", "walletSell", "cashbit", "deposit", "withdraw", "answer")
        .contains(op)) log(p, app, msg, -1);
    send(p, app, msg);
  }

  private static void admin(ServerPlayer p, String verb, String id, long v) {
    if (!p.hasPermissions(2)) {
      send(p, "Система", "Требуются права оператора уровня 2");
      return;
    }
    if (verb.equals("setJail")) {
      if (p.level() != p.getServer().overworld()) {
        send(p, "Оператор", "Выбери точку в обычном мире");
        return;
      }
      var d = PoliceData.get(p.getServer());
      d.jail = p.blockPosition();
      d.setDirty();
      send(p, "Оператор", "Точка участка: " + d.jail.toShortString());
      return;
    }
    ServerPlayer target;
    try {
      target = p.getServer().getPlayerList().getPlayer(UUID.fromString(id));
    } catch (IllegalArgumentException e) {
      target = null;
    }
    if (target == null) {
      send(p, "Оператор", "Игрок уже вышел");
      return;
    }
    String result;
    switch (verb) {
      case "adminBank", "adminCash" -> {
        if (v < 1 || v > 100_000_000_000L) {
          send(p, "Оператор", "Сумма: от 0,01 до 1 млрд евро");
          return;
        }
        if (verb.equals("adminBank")) PlayerFunds.setBank(target, PlayerFunds.bank(target) + v);
        else PlayerFunds.setCash(target, PlayerFunds.cash(target) + v);
        result = (verb.equals("adminBank") ? "На счёт" : "Наличными") + " +" + PlayerFunds.fmt(v);
      }
      case "infOn", "infOff" -> {
        boolean on = verb.equals("infOn");
        PlayerFunds.toggleUnlimited(target, on);
        result = "Безлимит " + (on ? "включён" : "выключен");
      }
      case "pardon" -> {
        Police.pardon(target);
        result = "Ограничения сняты";
      }
      default -> {
        return;
      }
    }
    com.mojang.logging.LogUtils.getLogger()
        .info(
            "[PB City] Operator {}: {} -> {} ({})",
            p.getGameProfile().getName(),
            verb,
            target.getGameProfile().getName(),
            v);
    notice(target, "Оператор", result);
    if (target != p) send(p, "Оператор", target.getGameProfile().getName() + ": " + result);
  }

  public static void send(ServerPlayer p, String app, String note) {
    var t = PlayerFunds.tag(p);
    var d = new CompoundTag();
    d.putLong("cash", PlayerFunds.cash(p));
    d.putLong("bank", PlayerFunds.bank(p));
    d.putLong("dirty", PlayerFunds.dirty(p));
    d.putLong("traced", PlayerFunds.traced(p));
    d.putBoolean("inf", PlayerFunds.unlimited(p));
    d.putBoolean("op", p.hasPermissions(2));
    d.putBoolean("sim", simOn(p));
    d.putBoolean("mic", t.getBoolean("micConsent"));
    d.putBoolean("svc", ModList.get().isLoaded("voicechat"));
    d.putBoolean("stt", !PBConfig.STT_URL.get().isBlank());
    d.putBoolean("tts", !PBConfig.TTS_URL.get().isBlank());
    d.putInt("done", t.getInt("districtDone"));
    d.putInt("number", 100000 + Math.floorMod(p.getUUID().hashCode(), 900000));
    d.putString("police", Police.status(p));
    d.putLong("simNext", t.getLong("simNext"));
    d.put("inbox", t.getList("districtInbox", 10).copy());
    d.put("job", Deliveries.job(p).copy());
    var poi = Stops.get(p.serverLevel()).publicPoints();
    var jail = PoliceData.get(p.getServer()).jail;
    if (jail != null && p.level() == p.getServer().overworld())
      poi.putLong("station", jail.asLong());
    d.put("points", poi);
    d.putString("estate", com.pbcity.property.PropertyData.get(p.getServer()).estateString(p));
    for (int i = 0; i < Wallets.NAMES.length; i++) {
      String id = Wallets.address(p, i);
      d.putString("address" + i, id);
      d.putDouble("bit" + i, id.isEmpty() ? 0 : Wallets.balance(p, i, id));
    }
    var s = SIM.get(p.getUUID());
    if (s != null && p.level().getGameTime() < s.until) {
      d.putLong("hide", s.after);
      d.putLong("until", s.until);
      if (p.level().getGameTime() < s.after) d.putString("pattern", s.digits);
    }
    if (p.hasPermissions(2)) {
      ListTag players = new ListTag();
      p.getServer().getPlayerList().getPlayers().stream()
          .sorted(Comparator.comparing(a -> a.getGameProfile().getName()))
          .limit(256)
          .forEach(
              a -> {
                var x = new CompoundTag();
                x.putString("id", a.getUUID().toString());
                x.putString("name", a.getGameProfile().getName());
                x.putBoolean("inf", PlayerFunds.unlimited(a));
                x.putLong("bank", PlayerFunds.bank(a));
                x.putLong("cash", PlayerFunds.cash(a));
                players.add(x);
              });
      d.put("players", players);
    }
    Net.CH.send(
        PacketDistributor.PLAYER.with(() -> p), new DistrictState(d, cap(app, 48), cap(note, 240)));
  }

  @SubscribeEvent
  public static void login(PlayerEvent.PlayerLoggedInEvent e) {
    if (e.getEntity() instanceof ServerPlayer p) {
      VoiceConsent.set(p.getUUID(), PlayerFunds.tag(p).getBoolean("micConsent"));
      send(p, "", "");
    }
  }

  @SubscribeEvent
  public static void logout(PlayerEvent.PlayerLoggedOutEvent e) {
    var id = e.getEntity().getUUID();
    VoiceConsent.set(id, false);
    RATE.remove(id);
    SIM.remove(id);
  }

  @SubscribeEvent
  public static void voiceRange(TickEvent.ServerTickEvent e) {
    if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 10 != 0) return;
    for (var p : e.getServer().getPlayerList().getPlayers())
      if (VoiceConsent.allowed(p.getUUID()))
        VoiceConsent.nearby(
            p.getUUID(),
            !PlayerFunds.tag(p).getString("callNpc").isEmpty()
                || NpcService.nearestInFront(p, 8) != null);
  }

  @SubscribeEvent
  public static void maintain(TickEvent.ServerTickEvent e) {
    if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 100 != 0) return;
    long t = e.getServer().overworld().getGameTime();
    for (var p : e.getServer().getPlayerList().getPlayers()) {
      var j = Deliveries.job(p);
      if (!j.isEmpty() && t >= j.getLong("expires")) {
        Deliveries.cancel(p);
        notice(p, "Диспетчер", "Срок доставки истёк. Можно взять новую заявку.");
      }
    }
  }

  private static final class PropertyIncome {
    static void claim(ServerPlayer p) {
      com.pbcity.property.PropertyData.get(p.getServer()).claim(p);
    }
  }

  private District() {}
}
