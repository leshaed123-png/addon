package com.pbcity.district;

import com.pbcity.npc.*;
import com.pbcity.police.PoliceData;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "pbcity")
public final class Quarter {
  @SubscribeEvent
  public static void commands(RegisterCommandsEvent e) {
    e.getDispatcher()
        .register(
            Commands.literal("pbcity")
                .then(
                    Commands.literal("quarter")
                        .requires(s -> s.hasPermission(2))
                        .executes(
                            c -> {
                              c.getSource()
                                  .sendSuccess(
                                      () ->
                                          Component.literal(
                                              "Нужна свободная площадка 46×36 на юг от тебя. Пол"
                                                  + " заменяется, существующие постройки над ним не"
                                                  + " перезаписываются. Подтверждение: /pbcity"
                                                  + " quarter confirm"),
                                      false);
                              return 1;
                            })
                        .then(
                            Commands.literal("confirm")
                                .executes(
                                    c -> {
                                      var p = c.getSource().getPlayerOrException();
                                      var result = place(p);
                                      c.getSource()
                                          .sendSuccess(() -> Component.literal(result), true);
                                      return 1;
                                    }))));
  }

  public static String place(ServerPlayer p) {
    if (!p.hasPermissions(2) || p.level().dimension() != Level.OVERWORLD)
      return "Только для оператора в обычном мире";
    var sl = p.serverLevel();
    var origin = p.blockPosition().offset(-22, -1, 3);
    if (origin.getY() + 16 >= sl.getMaxBuildHeight() || origin.getY() < sl.getMinBuildHeight())
      return "Высота не подходит";
    for (int x = 0; x < 46; x++)
      for (int z = 0; z < 36; z++) {
        var b = origin.offset(x, 0, z);
        if (!sl.hasChunkAt(b)
            || !sl.getWorldBorder().isWithinBounds(b)
            || !sl.getFluidState(b).isEmpty()
            || sl.getBlockEntity(b) != null) return "Нужна загруженная сухая площадка";
        for (int y = 1; y < 16; y++) {
          var pos = b.above(y);
          if (!sl.getBlockState(pos).canBeReplaced() || !sl.getFluidState(pos).isEmpty())
            return "Площадка занята: " + pos.toShortString() + ". Ничего не изменено.";
        }
      }
    var template = sl.getStructureManager().get(new ResourceLocation("pbcity", "kontur_quarter"));
    if (template.isEmpty()
        || !template
            .get()
            .placeInWorld(
                sl,
                origin,
                origin,
                new StructurePlaceSettings().setIgnoreEntities(true),
                sl.getRandom(),
                2)) return "Не удалось разместить квартал";
    var stops = Stops.get(sl);
    stops.set("pickup", origin.offset(9, 1, 15));
    stops.set("alley", origin.offset(2, 1, 9));
    stops.set("square", origin.offset(32, 1, 17));
    var police = PoliceData.get(p.getServer());
    police.jail = origin.offset(38, 1, 29);
    police.setDirty();
    for (int i = 0; i < 6; i++) {
      var n = ModEntities.CITY_NPC.get().create(sl);
      if (n == null) continue;
      var a = origin.offset(6 + i * 2, 1, 23);
      var b = origin.offset(30 + i * 2, 1, 15);
      n.init(CityNpc.Role.CIVILIAN, sl.getRandom());
      n.moveTo(a.getX() + .5, a.getY(), a.getZ() + .5, 0, 0);
      n.setPersistenceRequired();
      n.getPersistentData().putLong("dayStop", b.asLong());
      n.getPersistentData().putLong("nightStop", a.asLong());
      sl.addFreshEntity(n);
    }
    return "Квартал 07 открыт. Выдача — у типографии; переулок, площадь и участок отмечены в мире.";
  }

  private Quarter() {}
}
