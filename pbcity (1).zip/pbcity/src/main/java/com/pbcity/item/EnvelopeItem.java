package com.pbcity.item;

import com.pbcity.econ.PlayerFunds;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Sealed envelope with euro cash (NBT "cents"). Right-click to put the money into your cash. */
public class EnvelopeItem extends Item {
    public EnvelopeItem(Properties p) { super(p); }

    public static ItemStack of(long cents) {
        ItemStack s = new ItemStack(ModItems.ENVELOPE.get());
        s.getOrCreateTag().putLong("cents", cents);
        return s;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack s = p.getItemInHand(hand);
        long c = s.hasTag() ? s.getTag().getLong("cents") : 0;
        if (!level.isClientSide && c > 0) {
            PlayerFunds.setCash(p, PlayerFunds.cash(p) + c);
            PlayerFunds.addDirty(p, c);
            s.shrink(1);
            p.displayClientMessage(Component.literal("+" + PlayerFunds.fmt(c)), true);
        }
        return InteractionResultHolder.sidedSuccess(s, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
        long c = s.hasTag() ? s.getTag().getLong("cents") : 0;
        tip.add(Component.literal("Cash inside: " + PlayerFunds.fmt(c)));
    }
}
