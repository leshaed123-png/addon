package com.pbcity.item;

import com.pbcity.client.DeviceClient;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

/**
 * Cold wallet for BIT. State lives in the item's NBT: "pin", "unlock" (game time until which it is open) and "bit".
 * Commands: /ledger setpin|unlock|lock|deposit|withdraw. Coins on the Ledger survive the death penalty.
 */
public class LedgerItem extends Item {
    public LedgerItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack s = p.getItemInHand(hand);
        if (!level.isClientSide) {
            CompoundTag t = s.getOrCreateTag();
            String msg;
            if (t.getString("pin").isEmpty()) msg = "Ledger: задай PIN командой /ledger setpin 1234";
            else if (t.getLong("unlock") > level.getGameTime())
                msg = String.format("Ledger открыт: %.5f BIT (закроется через %d с)", t.getDouble("bit"),
                        (t.getLong("unlock") - level.getGameTime()) / 20);
            else msg = "Ledger заблокирован: /ledger unlock <PIN>";
            p.displayClientMessage(Component.literal(msg), true);
        }
        return InteractionResultHolder.sidedSuccess(s, level.isClientSide);
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
        tip.add(Component.literal("Холодный кошелёк. /ledger setpin | unlock | lock | deposit | withdraw"));
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(DeviceClient.extensions());
    }
}
