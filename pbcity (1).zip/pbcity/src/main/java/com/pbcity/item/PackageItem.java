package com.pbcity.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Sealed street package (NBT "units", "quality"). Only a trade good in this mod. */
public class PackageItem extends Item {
    public PackageItem(Properties p) { super(p); }

    public static ItemStack of(int units, int quality) {
        ItemStack s = new ItemStack(ModItems.PACKAGE.get());
        s.getOrCreateTag().putInt("units", units);
        s.getTag().putInt("quality", quality);
        return s;
    }

    @Override
    public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
        if (s.hasTag()) tip.add(Component.literal(s.getTag().getInt("units") + " units, quality ~"
                + s.getTag().getInt("quality") + "%"));
    }
}
