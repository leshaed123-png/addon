package com.pbcity.item;

import com.pbcity.client.DeviceClient;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.function.Consumer;

/**
 * Handheld wind / ballistics meter. No GUI: the readout is drawn on the 3D model's own LCD while the impeller
 * spins with the real wind. Right-click = next page (wind, ballistic, environment, time),
 * Shift + right-click = next unit (m/s, km/h, mph, kt).
 */
public class WindMeterItem extends Item {
    public WindMeterItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack s = p.getItemInHand(hand);
        if (!level.isClientSide) {
            CompoundTag t = s.getOrCreateTag();
            if (p.isShiftKeyDown()) t.putInt("unit", (t.getInt("unit") + 1) % 4);
            else t.putInt("page", (t.getInt("page") + 1) % 4);
            p.getCooldowns().addCooldown(this, 6);
        }
        return InteractionResultHolder.sidedSuccess(s, level.isClientSide);
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(DeviceClient.extensions());
    }
}
