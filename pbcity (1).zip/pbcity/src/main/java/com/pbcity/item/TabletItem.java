package com.pbcity.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

public final class TabletItem extends Item {
  public TabletItem(Properties p) {
    super(p);
  }

  @Override
  public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
    if (l.isClientSide)
      DistExecutor.unsafeRunWhenOn(
          Dist.CLIENT, () -> () -> com.pbcity.client.kontur.KonturScreen.open(true));
    return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
  }
}
