package com.pbcity.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * A bagged trade good (NBT "units", "quality"). Right-click uses one: short game effects with a side effect,
 * and using too many in a short time causes an overdose penalty. Purely a game mechanic.
 */
public class GoodsItem extends Item {
    private final int kind; // 0 cocaine, 1 mephedrone, 2 crystals, 3 weed

    public GoodsItem(Properties p, int kind) {
        super(p);
        this.kind = kind;
    }

    public static ItemStack of(Item item, int units, int quality) {
        ItemStack s = new ItemStack(item);
        s.getOrCreateTag().putInt("units", units);
        s.getTag().putInt("quality", quality);
        return s;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack s = p.getItemInHand(hand);
        if (!level.isClientSide) {
            CompoundTag t = p.getPersistentData();
            long now = level.getGameTime();
            int recent = now - t.getLong("pbcUseAt") < 2400 ? t.getInt("pbcUses") + 1 : 1;
            t.putLong("pbcUseAt", now);
            t.putInt("pbcUses", recent);
            if (recent >= 3) {
                p.addEffect(new MobEffectInstance(MobEffects.POISON, 200, 1));
                p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 300, 0));
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 400, 1));
                p.displayClientMessage(Component.literal("Передоз! Тебе очень плохо."), true);
            } else {
                switch (kind) {
                    case 0 -> {
                        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1));
                        p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 800, 1));
                        p.addEffect(new MobEffectInstance(MobEffects.HUNGER, 800, 1));
                    }
                    case 1 -> {
                        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1200, 0));
                        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 0));
                        p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 160, 0));
                    }
                    case 2 -> {
                        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 1));
                        p.addEffect(new MobEffectInstance(MobEffects.JUMP, 800, 0));
                        p.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
                    }
                    default -> {
                        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 600, 0));
                        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 600, 0));
                        p.addEffect(new MobEffectInstance(MobEffects.HUNGER, 400, 0));
                    }
                }
                p.displayClientMessage(Component.literal("Тебя накрыло."), true);
            }
            s.shrink(1);
            p.getCooldowns().addCooldown(this, 100);
        }
        return InteractionResultHolder.sidedSuccess(s, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
        if (s.hasTag()) tip.add(Component.literal(s.getTag().getInt("units") + " ед., качество ~"
                + s.getTag().getInt("quality") + "%"));
        tip.add(Component.literal("ПКМ - употребить (3 подряд = передоз)"));
    }
}
