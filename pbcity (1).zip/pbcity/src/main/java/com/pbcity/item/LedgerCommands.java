package com.pbcity.item;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.pbcity.PBCity;
import com.pbcity.econ.PlayerFunds;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /ledger setpin <pin> | unlock <pin> | lock | deposit <bit> | withdraw <bit> - acts on the Ledger in your main hand. */
@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class LedgerCommands {
    private static final long OPEN_TICKS = 1200; // 60 s

    private LedgerCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("ledger")
                .then(Commands.literal("setpin").then(Commands.argument("pin", StringArgumentType.word())
                        .executes(c -> run(c.getSource(), "setpin", StringArgumentType.getString(c, "pin"), 0))))
                .then(Commands.literal("unlock").then(Commands.argument("pin", StringArgumentType.word())
                        .executes(c -> run(c.getSource(), "unlock", StringArgumentType.getString(c, "pin"), 0))))
                .then(Commands.literal("lock").executes(c -> run(c.getSource(), "lock", "", 0)))
                .then(Commands.literal("deposit").then(Commands.argument("amount", DoubleArgumentType.doubleArg(0.00001))
                        .executes(c -> run(c.getSource(), "deposit", "", DoubleArgumentType.getDouble(c, "amount")))))
                .then(Commands.literal("withdraw").then(Commands.argument("amount", DoubleArgumentType.doubleArg(0.00001))
                        .executes(c -> run(c.getSource(), "withdraw", "", DoubleArgumentType.getDouble(c, "amount"))))));
    }

    private static int fail(ServerPlayer p, String msg) {
        p.sendSystemMessage(Component.literal(msg));
        return 0;
    }

    private static int run(CommandSourceStack src, String op, String arg, double amt) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ItemStack st = p.getMainHandItem();
        if (!(st.getItem() instanceof LedgerItem)) return fail(p, "Возьми Ledger в основную руку.");
        CompoundTag t = st.getOrCreateTag();
        long now = p.level().getGameTime();
        boolean open = t.getLong("unlock") > now;
        String pin = t.getString("pin");
        switch (op) {
            case "setpin" -> {
                if (!pin.isEmpty() && !open) return fail(p, "Сначала разблокируй Ledger (/ledger unlock <PIN>).");
                if (!arg.matches("\\d{4,8}")) return fail(p, "PIN - от 4 до 8 цифр.");
                t.putString("pin", arg);
                t.putLong("unlock", 0);
                p.sendSystemMessage(Component.literal("PIN установлен. Ledger заблокирован."));
            }
            case "unlock" -> {
                if (pin.isEmpty()) return fail(p, "PIN ещё не задан: /ledger setpin 1234");
                if (!pin.equals(arg)) return fail(p, "Неверный PIN.");
                t.putLong("unlock", now + OPEN_TICKS);
                p.sendSystemMessage(Component.literal("Ledger открыт на 60 секунд."));
            }
            case "lock" -> {
                t.putLong("unlock", 0);
                p.sendSystemMessage(Component.literal("Ledger заблокирован."));
            }
            case "deposit" -> {
                if (!open) return fail(p, "Ledger заблокирован.");
                CompoundTag pt = PlayerFunds.tag(p);
                double hot = pt.getDouble("bit");
                if (amt > hot + 1e-9) return fail(p, String.format("На телефоне только %.5f BIT.", hot));
                pt.putDouble("bit", Math.max(0, hot - amt));
                t.putDouble("bit", t.getDouble("bit") + amt);
                p.sendSystemMessage(Component.literal(String.format("На Ledger переведено %.5f BIT (всего %.5f).", amt, t.getDouble("bit"))));
            }
            case "withdraw" -> {
                if (!open) return fail(p, "Ledger заблокирован.");
                double cold = t.getDouble("bit");
                if (amt > cold + 1e-9) return fail(p, String.format("На Ledger только %.5f BIT.", cold));
                t.putDouble("bit", Math.max(0, cold - amt));
                CompoundTag pt = PlayerFunds.tag(p);
                pt.putDouble("bit", pt.getDouble("bit") + amt);
                p.sendSystemMessage(Component.literal(String.format("На телефон переведено %.5f BIT.", amt)));
            }
            default -> { }
        }
        return 1;
    }
}
