package com.pbcity.item;

import com.pbcity.ballistics.Raycast;
import com.pbcity.client.DeviceClient;
import com.pbcity.config.PBConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.function.Consumer;

/**
 * Handheld laser rangefinder. No GUI: the readout is drawn on the 3D model's own LCD.
 * Right-click = measure (green laser beam), Shift + right-click = switch mode (distance / speed / angle).
 */
public class RangefinderItem extends Item {
    public RangefinderItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack s = p.getItemInHand(hand);
        if (!level.isClientSide) {
            CompoundTag t = s.getOrCreateTag();
            int mode = t.getInt("mode");
            if (p.isShiftKeyDown()) {
                t.putInt("mode", (mode + 1) % 3);
                t.putInt("n", 0);
            } else {
                Raycast.Result r = Raycast.measure(p, PBConfig.MAX_RANGE.get());
                double v = mode == 0 ? Math.max(0, r.dist())
                        : mode == 1 ? (r.target() == null ? 0 : Raycast.speed(r.target())) : r.pitch();
                t.putDouble("h0", t.getDouble("h1"));
                t.putDouble("h1", t.getDouble("h2"));
                t.putDouble("h2", v);
                t.putInt("n", Math.min(3, t.getInt("n") + 1));
                t.putDouble("hx", r.hit().x);
                t.putDouble("hy", r.hit().y);
                t.putDouble("hz", r.hit().z);
                t.putLong("laser", level.getGameTime() + 25);
            }
            p.getCooldowns().addCooldown(this, 8);
        }
        return InteractionResultHolder.sidedSuccess(s, level.isClientSide);
    }

    /** NBT changes (readings) must not replay the "equip" animation. */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(DeviceClient.extensions());
    }
}
