package com.pbcity.client.kontur;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Cartography from already-loaded client chunks. No network tiles, synthetic streets or chunk
 * generation.
 */
final class Terrain implements AutoCloseable {
  final int w, h;
  final DynamicTexture bitmap;
  final ResourceLocation id;
  int x, z, step = -1;
  long last = -100;

  Terrain(int w, int h) {
    this.w = w;
    this.h = h;
    bitmap = new DynamicTexture(w, h, false);
    id = Minecraft.getInstance().getTextureManager().register("kontur_topography", bitmap);
  }

  void update(int X, int Z, int scale) {
    var l = Minecraft.getInstance().level;
    if (l == null) return;
    long tick = l.getGameTime();
    if (x == X && z == Z && step == scale && tick - last < 40) return;
    x = X;
    z = Z;
    step = scale;
    last = tick;
    var pos = new BlockPos.MutableBlockPos();
    var pixels = bitmap.getPixels();
    if (pixels == null) return;
    for (int j = 0; j < h; j++)
      for (int i = 0; i < w; i++) {
        int wx = x + (i - w / 2) * step, wz = z + (j - h / 2) * step;
        int rgb = 0xcdd3cd;
        var chunk = l.getChunkSource().getChunkNow(wx >> 4, wz >> 4);
        if (chunk != null) {
          int y = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, wx & 15, wz & 15);
          pos.set(wx, y, wz);
          var s = chunk.getBlockState(pos);
          int raw = s.getMapColor(l, pos).col;
          int r = raw >> 16 & 255, g = raw >> 8 & 255, b = raw & 255;
          float k = .48f;
          int base = !s.getFluidState().isEmpty() ? 0x80b9c6 : g > r * 1.16 ? 0xa9c398 : 0xd1c7b5;
          int shade = Math.floorMod(y, 7) - 3;
          int R = (int) ((base >> 16 & 255) * (1 - k) + r * k) + shade,
              G = (int) ((base >> 8 & 255) * (1 - k) + g * k) + shade,
              B = (int) ((base & 255) * (1 - k) + b * k) + shade;
          rgb = (Math.max(0, R) << 16) | (Math.max(0, G) << 8) | Math.max(0, B);
        } else if (((i + j) / 5) % 2 == 0) rgb = 0xd7dcd5;
        pixels.setPixelRGBA(
            i, j, 0xff000000 | ((rgb & 255) << 16) | (rgb & 0xff00) | (rgb >> 16 & 255));
      }
    bitmap.upload();
    bitmap.setFilter(true, false);
  }

  @Override
  public void close() {
    Minecraft.getInstance().getTextureManager().release(id);
  }
}
