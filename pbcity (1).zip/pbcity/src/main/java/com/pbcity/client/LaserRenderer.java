package com.pbcity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.pbcity.PBCity;
import com.pbcity.item.RangefinderItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Draws the green laser beam (and the dot where it lands) for every player who just fired a rangefinder. */
@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class LaserRenderer {
    private LaserRenderer() {}

    private static ItemStack held(Player p) {
        if (p.getMainHandItem().getItem() instanceof RangefinderItem) return p.getMainHandItem();
        if (p.getOffhandItem().getItem() instanceof RangefinderItem) return p.getOffhandItem();
        return ItemStack.EMPTY;
    }

    private static void seg(VertexConsumer vc, PoseStack.Pose pose, Vec3 a, Vec3 b, float r, float g, float bl, float al) {
        Vec3 n = b.subtract(a);
        double len = n.length();
        if (len < 1e-6) return;
        n = n.scale(1.0 / len);
        vc.vertex(pose.pose(), (float) a.x, (float) a.y, (float) a.z).color(r, g, bl, al)
                .normal(pose.normal(), (float) n.x, (float) n.y, (float) n.z).endVertex();
        vc.vertex(pose.pose(), (float) b.x, (float) b.y, (float) b.z).color(r, g, bl, al)
                .normal(pose.normal(), (float) n.x, (float) n.y, (float) n.z).endVertex();
    }

    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long now = mc.level.getGameTime();
        float pt = e.getPartialTick();
        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        boolean drew = false;
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        VertexConsumer vc = buf.getBuffer(RenderType.lines());
        PoseStack.Pose pose = ps.last();
        for (Player p : mc.level.players()) {
            ItemStack s = held(p);
            if (s.isEmpty() || !s.hasTag()) continue;
            CompoundTag t = s.getTag();
            if (t.getLong("laser") <= now) continue;
            Vec3 end = new Vec3(t.getDouble("hx"), t.getDouble("hy"), t.getDouble("hz"));
            Vec3 eye = p.getEyePosition(pt);
            Vec3 look = p.getViewVector(pt);
            Vec3 right = look.cross(new Vec3(0, 1, 0));
            if (right.lengthSqr() < 1e-4) continue;
            right = right.normalize();
            Vec3 down = look.cross(right).normalize();
            Vec3 start = eye.add(look.scale(0.55)).add(right.scale(p == mc.player ? 0.17 : 0.25)).add(down.scale(0.14));
            float al = (float) (0.65 + 0.35 * Math.sin((now + pt) * 1.3));
            seg(vc, pose, start, end, 0.1f, 1f, 0.2f, al);
            double o = 0.006;
            seg(vc, pose, start.add(right.scale(o)), end.add(right.scale(o)), 0.1f, 1f, 0.2f, al * 0.35f);
            seg(vc, pose, start.subtract(right.scale(o)), end.subtract(right.scale(o)), 0.1f, 1f, 0.2f, al * 0.35f);
            seg(vc, pose, start.add(down.scale(o)), end.add(down.scale(o)), 0.1f, 1f, 0.2f, al * 0.35f);
            seg(vc, pose, start.subtract(down.scale(o)), end.subtract(down.scale(o)), 0.1f, 1f, 0.2f, al * 0.35f);
            double d = 0.09;
            seg(vc, pose, end.add(d, 0, 0), end.subtract(d, 0, 0), 0.4f, 1f, 0.5f, 1f);
            seg(vc, pose, end.add(0, d, 0), end.subtract(0, d, 0), 0.4f, 1f, 0.5f, 1f);
            seg(vc, pose, end.add(0, 0, d), end.subtract(0, 0, d), 0.4f, 1f, 0.5f, 1f);
            drew = true;
        }
        ps.popPose();
        if (drew) buf.endBatch(RenderType.lines());
    }
}
