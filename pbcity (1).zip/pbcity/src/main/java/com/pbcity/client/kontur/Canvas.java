package com.pbcity.client.kontur;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import java.util.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/**
 * Subpixel device canvas: antialiased nine-patches, batch-per-string atlas text, and original
 * monoline symbols.
 */
public final class Canvas {
  private static final Map<String, ResourceLocation> TEX = new HashMap<>();
  public static final int PAPER = 0xf4f3ec,
      WHITE = 0xfffef8,
      INK = 0x213731,
      MUTED = 0x536962,
      LINE = 0xd4dad0,
      GREEN = 0x245b51,
      LIME = 0xd4e6aa,
      ORANGE = 0xec926a,
      DARK = 0x20252b;
  public final GuiGraphics g;
  private BufferBuilder buf;
  private Matrix4f mat;

  public Canvas(GuiGraphics g) {
    this.g = g;
  }

  public static ResourceLocation tex(String k) {
    return TEX.computeIfAbsent(
        k, n -> new ResourceLocation("pbcity", "textures/kontur/" + n + ".png"));
  }

  private void begin(ResourceLocation rl) {
    g.flush();
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.setShaderColor(1, 1, 1, 1);
    RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
    RenderSystem.setShaderTexture(0, rl);
    buf = Tesselator.getInstance().getBuilder();
    buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
    mat = g.pose().last().pose();
  }

  private void vertex(float x, float y, float u, float v, int c) {
    buf.vertex(mat, x, y, 0)
        .uv(u, v)
        .color(c >> 16 & 255, c >> 8 & 255, c & 255, (c >>> 24) == 0 ? 255 : c >>> 24)
        .endVertex();
  }

  private void quad(float x, float y, float w, float h, float u, float v, float U, float V, int c) {
    vertex(x, y + h, u, V, c);
    vertex(x + w, y + h, U, V, c);
    vertex(x + w, y, U, v, c);
    vertex(x, y, u, v, c);
  }

  private void end() {
    BufferUploader.drawWithShader(buf.end());
  }

  public void round(float x, float y, float w, float h, float r, int c) {
    if (w <= 0 || h <= 0) return;
    r = Math.min(r, Math.min(w, h) * .5f);
    begin(tex("round"));
    if (r < .4f) quad(x, y, w, h, .48f, .48f, .52f, .52f, c);
    else {
      float[] X = {x, x + r, x + w - r, x + w},
          Y = {y, y + r, y + h - r, y + h},
          uv = {0, .375f, .625f, 1};
      for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
          quad(X[i], Y[j], X[i + 1] - X[i], Y[j + 1] - Y[j], uv[i], uv[j], uv[i + 1], uv[j + 1], c);
    }
    end();
  }

  public void pic(String k, float x, float y, float w, float h) {
    image(tex(k), x, y, w, h, 0, 0, 1, 1);
  }

  public void image(
      ResourceLocation rl, float x, float y, float w, float h, float u, float v, float U, float V) {
    begin(rl);
    quad(x, y, w, h, u, v, U, V, 0xffffffff);
    end();
  }

  public void icon(String name, float x, float y, float s, int c) {
    int i = Symbols.NAMES.indexOf(name);
    if (i < 0) return;
    float u = i % 8 / 8f, v = i / 8 / 8f;
    begin(tex("icons"));
    quad(x, y, s, s, u, v, u + .125f, v + .125f, c);
    end();
  }

  private static int glyph(char c) {
    int i = GlyphData.CHARS.indexOf(c);
    return i < 0 ? 31 : i;
  }

  public static float width(String s, float size, boolean bold) {
    float w = 0;
    for (char c : s.toCharArray()) w += GlyphData.WIDTH[bold ? 1 : 0][glyph(c)] * size / 320f;
    return w;
  }

  public static String fit(String s, float max, float size, boolean b) {
    if (width(s, size, b) <= max) return s;
    float x = width("…", size, b);
    int i = 0;
    for (; i < s.length(); i++) {
      x += GlyphData.WIDTH[b ? 1 : 0][glyph(s.charAt(i))] * size / 320f;
      if (x > max) break;
    }
    return s.substring(0, i) + "…";
  }

  public void text(String s, float x, float y, float size, int color, boolean bold) {
    if (s == null || s.isEmpty()) return;
    begin(tex(bold ? "bold" : "regular"));
    float f = size / 32f;
    for (char c : s.toCharArray()) {
      int i = glyph(c);
      float u = i % 16 / 16f, v = i / 16 / 16f;
      quad(
          x - 3 * f,
          y,
          48 * f,
          46 * f,
          u + .00005f,
          v + .00005f,
          u + 48f / 1024,
          v + 46f / 1024,
          color);
      x += GlyphData.WIDTH[bold ? 1 : 0][i] * size / 320f;
    }
    end();
  }

  public void small(String s, float x, float y, float max, float sz, int c, boolean b) {
    text(fit(s, max, sz, b), x, y, sz, c, b);
  }

  public void right(String s, float x, float y, float sz, int c, boolean b) {
    text(s, x - width(s, sz, b), y, sz, c, b);
  }

  public void center(String s, float x, float y, float sz, int c, boolean b) {
    text(s, x - width(s, sz, b) / 2, y, sz, c, b);
  }

  public void wrap(String s, int x, int y, int w, float size, int line, int max, int c) {
    var words = s.split(" ");
    String row = "";
    int n = 0;
    for (String word : words) {
      String r = row.isEmpty() ? word : row + " " + word;
      if (width(r, size, false) > w && !row.isEmpty()) {
        text(fit(row, w, size, false), x, y + n * line, size, c, false);
        if (++n >= max) return;
        row = word;
      } else row = r;
    }
    if (n < max) text(fit(row, w, size, false), x, y + n * line, size, c, false);
  }

  public void line(float x, float y, float X, float Y, float thick, int c) {
    float dx = X - x, dy = Y - y, len = (float) Math.hypot(dx, dy);
    if (len == 0) return;
    g.pose().pushPose();
    g.pose().translate(x, y, 0);
    g.pose().mulPose(Axis.ZP.rotation((float) Math.atan2(dy, dx)));
    round(0, -thick / 2, len, thick, thick / 2, c);
    g.pose().popPose();
  }
}
