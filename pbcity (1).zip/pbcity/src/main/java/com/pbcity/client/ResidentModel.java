package com.pbcity.client;

import com.pbcity.npc.CityNpc;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;

public final class ResidentModel extends PlayerModel<CityNpc> {
  public static final ModelLayerLocation LAYER =
      new ModelLayerLocation(new ResourceLocation("pbcity", "district_resident"), "body");
  private final ModelPart cap, bag, scarf, phones, hair;

  public ResidentModel(ModelPart root) {
    super(root, false);
    cap = head.getChild("peak");
    bag = body.getChild("ruck");
    scarf = body.getChild("collar");
    phones = head.getChild("orbit");
    hair = head.getChild("hair_back");
  }

  public static LayerDefinition layer() {
    var root = PlayerModel.createMesh(CubeDeformation.NONE, false);
    var head = root.getRoot().getChild("head");
    var body = root.getRoot().getChild("body");
    head.addOrReplaceChild(
        "peak",
        CubeListBuilder.create().texOffs(16, 32).addBox(-4.35f, -7, -6.2f, 8.7f, .8f, 3.1f),
        PartPose.ZERO);
    head.addOrReplaceChild(
        "orbit",
        CubeListBuilder.create()
            .texOffs(18, 32)
            .addBox(-5.15f, -5.3f, -2, 1.45f, 3.7f, 3.4f)
            .addBox(3.7f, -5.3f, -2, 1.45f, 3.7f, 3.4f)
            .addBox(-4.55f, -8.8f, -1.3f, 9.1f, .8f, 2.1f),
        PartPose.ZERO);
    head.addOrReplaceChild(
        "hair_back",
        CubeListBuilder.create().texOffs(0, 0).addBox(-3.8f, -6, 3.2f, 7.6f, 8.3f, 1.7f),
        PartPose.ZERO);
    body.addOrReplaceChild(
        "ruck",
        CubeListBuilder.create()
            .texOffs(16, 32)
            .addBox(-3.4f, 2.1f, 1.9f, 6.8f, 8, 3.1f)
            .addBox(-2.9f, 6.7f, 4.8f, 5.8f, 2.4f, 1.05f),
        PartPose.ZERO);
    body.addOrReplaceChild(
        "collar",
        CubeListBuilder.create()
            .texOffs(16, 32)
            .addBox(-4.15f, -.5f, -2.3f, 8.3f, 1.9f, 4.6f)
            .addBox(1, 1, -2.45f, 2.4f, 4.8f, .75f),
        PartPose.ZERO);
    return LayerDefinition.create(root, 64, 64);
  }

  @Override
  public void setupAnim(CityNpc n, float a, float b, float c, float d, float e) {
    super.setupAnim(n, a, b, c, d, e);
    int i = n.appearance() % 8;
    cap.visible = i == 0 || i == 3;
    bag.visible = i == 0 || i == 4 || i == 6;
    scarf.visible = i == 1 || i == 5;
    phones.visible = i == 2 || i == 7;
    hair.visible = i == 5 || i == 6;
    jacket.visible = false;
  }
}
