package com.pbcity.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Small drawing helpers: rounded rectangles, vertical gradients, soft shadows and scaled / centred text. */
final class Gfx {
    private Gfx() {}

    static void rr(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        new com.pbcity.client.kontur.Canvas(g).round(x,y,w,h,r,c);
    }

    /** Rounded rectangle with a soft drop shadow underneath. */
    static void card(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        rr(g, x, y + 2, w, h, r, 0x16000000);
        rr(g, x, y + 1, w, h, r, 0x22000000);
        rr(g, x, y, w, h, r, c);
    }

    static int lerp(int a, int b, float f) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | (int) (ar + (br - ar) * f) << 16 | (int) (ag + (bg - ag) * f) << 8 | (int) (ab + (bb - ab) * f);
    }

    /** Vertical gradient inside a rounded shape: fills rows with an inset that follows the corner radius. */
    static void gradRr(GuiGraphics g, int x, int y, int w, int h, int r, int top, int bottom) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int dy = 0; dy < h; dy++) {
            int d = dy < r ? r - dy : (dy >= h - r ? dy - (h - r) + 1 : 0);
            int inset = 0;
            if (d > 0) {
                double yy = d - 0.5;
                inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - yy * yy)));
            }
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, lerp(top, bottom, h <= 1 ? 0 : dy / (float) (h - 1)));
        }
    }

    static void text(GuiGraphics g, Font f, String s, int x, int y, int color, float scale, boolean center) {
        var canvas=new com.pbcity.client.kontur.Canvas(g);float size=9.2f*scale;
        if(center)canvas.center(s,x,y,size,color,false);else canvas.text(s,x,y,size,color,false);
    }

    static void textRight(GuiGraphics g, Font f, String s, int xRight, int y, int color, float scale) {
        text(g, f, s, xRight - (int) (f.width(s) * scale), y, color, scale, false);
    }
}
