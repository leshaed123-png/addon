package com.pbcity.client;

import com.pbcity.npc.CityNpc;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CityNpcRenderer extends HumanoidMobRenderer<CityNpc, ResidentModel> {
    private static final ResourceLocation[] SKINS = new ResourceLocation[49];
    static {
        for (int i = 0; i < SKINS.length; i++)
            SKINS[i] = new ResourceLocation("pbcity", String.format("textures/entity/npc/skin_%02d.png", i));
    }

    public CityNpcRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new ResidentModel(ctx.bakeLayer(ResidentModel.LAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(CityNpc e) {
        return SKINS[e.appearance()];
    }
}
