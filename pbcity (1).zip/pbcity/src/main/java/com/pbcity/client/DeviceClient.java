package com.pbcity.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** Client-side hook that gives the handheld devices their custom (animated, LCD-drawing) renderer. */
public final class DeviceClient {
    private static DeviceRenderer renderer;

    private DeviceClient() {}

    public static IClientItemExtensions extensions() {
        return new IClientItemExtensions() {
            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) {
                    Minecraft mc = Minecraft.getInstance();
                    renderer = new DeviceRenderer(mc.getBlockEntityRenderDispatcher(), mc.getEntityModels());
                }
                return renderer;
            }
        };
    }
}
