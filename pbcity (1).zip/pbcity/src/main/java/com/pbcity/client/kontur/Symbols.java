package com.pbcity.client.kontur;

final class Symbols {
  static final java.util.List<String> NAMES =
      java.util.List.of(
          "home", "market", "map", "node", "mail", "wallet", "sim", "op", "more", "bank", "arrow",
          "up", "back", "next", "logo", "pin", "bag", "chat", "check", "clock", "voice", "card",
          "gear", "send", "person", "phone", "copy", "clip", "signal", "cube", "cross", "plus",
          "minus");
}
