package com.pbcity.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.pbcity.PBCity;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class PhoneKeys {
    public static final KeyMapping OPEN = new KeyMapping("key.pbcity.phone", InputConstants.KEY_UP, "key.categories.pbcity");

    public static final KeyMapping TABLET = new KeyMapping("key.pbcity.tablet", org.lwjgl.glfw.GLFW.GLFW_KEY_F7, "key.categories.pbcity");

    private PhoneKeys() {}

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(OPEN); e.register(TABLET);
    }
}
