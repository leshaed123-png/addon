package com.pbcity.client.kontur;

import static com.pbcity.client.kontur.Canvas.*;

import com.pbcity.client.PhoneKeys;
import com.pbcity.client.PhoneScreen;
import com.pbcity.district.*;
import com.pbcity.econ.*;
import com.pbcity.net.*;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Both devices share accounts and inbox, not a stretched layout: portrait launcher vs landscape
 * split workspace.
 */
public final class KonturScreen extends Screen {
  enum App {
    HOME("Обзор", "home"),
    SHOP("Маркет", "market"),
    NODE("Узел 09", "node"),
    MAP("Карта", "map"),
    CHAT("Сообщения", "mail"),
    WALLETS("Кошельки", "wallet"),
    BANK("Банк", "bank"),
    SIM("Mobile SIM", "sim"),
    MORE("Приложения", "more"),
    ADMIN("Оператор", "op");
    final String title, icon;

    App(String t, String i) {
      title = t;
      icon = i;
    }
  }

  record Hit(int x, int y, int w, int h, Runnable run) {}

  private final boolean wide;
  private final int W, H;
  private final List<Hit> hits = new ArrayList<>();
  private Canvas c;
  private App app = App.HOME;
  private float scale;
  private int ox,
      oy,
      mx,
      my,
      x,
      y,
      w,
      h,
      ticks,
      tab,
      page,
      focus,
      filter,
      detail = -1,
      wallet,
      amount = 1,
      playerIndex,
      zoom = 1,
      mapCenter,
      threadPage;
  private boolean square, confirm, editing;
  private String input = "", status = "", symbols = "", adminAmount = "1000";
  private long statusAt, born, lastBuy, lastDraw;
  private Terrain terrain;
  private static final long[] AMOUNTS = {1000, 10000, 50000, 100000};
  private static final int[] ZOOMS = {1, 2, 4, 8};
  private static final String[] SIGS = {"◆", "●", "▲", "■"};

  public KonturScreen(boolean wide) {
    super(Component.literal(wide ? "Контур · Планшет" : "Контур · Телефон"));
    this.wide = wide;
    W = wide ? 748 : 270;
    H = wide ? 454 : 440;
    born = System.currentTimeMillis();
  }

  public static void open(boolean wide) {
    Minecraft.getInstance().setScreen(new KonturScreen(wide));
  }

  @Override
  protected void init() {
    req("sync", "", 0);
  }

  @Override
  public boolean isPauseScreen() {
    return false;
  }

  @Override
  public void removed() {
    if (terrain != null) {
      terrain.close();
      terrain = null;
    }
  }

  private CompoundTag d() {
    return Inbox.state;
  }

  private CompoundTag job() {
    return d().getCompound("job");
  }

  private boolean has() {
    return !job().isEmpty();
  }

  private boolean dark() {
    return app == App.NODE;
  }

  private int ink() {
    return dark() ? 0xeee9f4 : INK;
  }

  private int muted() {
    return dark() ? 0xada7bd : MUTED;
  }

  private int card() {
    return dark() ? 0x30303e : WHITE;
  }

  private int accent() {
    return dark() ? 0xc2afd9 : GREEN;
  }

  private int pale() {
    return dark() ? 0x454151 : 0xe1e9dc;
  }

  private void req(String op, String text, long v) {
    Net.CH.sendToServer(new DistrictRequest(op, text, v));
  }

  private void note(String s) {
    status = s;
    statusAt = System.currentTimeMillis();
  }

  private long time() {
    return minecraft == null || minecraft.level == null ? 0 : minecraft.level.getGameTime();
  }

  private String clock() {
    return minecraft == null || minecraft.level == null
        ? "--:--"
        : Deliveries.clock(minecraft.level.getDayTime());
  }

  private void go(App a) {
    if (a == App.ADMIN && !d().getBoolean("op")) return;
    app = a;
    page = 0;
    tab = 0;
    filter = 0;
    detail = -1;
    confirm = false;
    editing = false;
    input = "";
    symbols = "";
    threadPage = 0;
    status = "";
    req("sync", "", 0);
  }

  @Override
  public void tick() {
    if (++ticks % 40 == 0) req("sync", "", 0);
  }

  private void hit(int X, int Y, int bw, int bh, Runnable r) {
    hits.add(new Hit(X, Y, bw, bh, r));
  }

  private boolean hover(int X, int Y, int bw, int bh) {
    return mx >= X && mx < X + bw && my >= Y && my < Y + bh;
  }

  @Override
  public boolean mouseClicked(double X, double Y, int b) {
    if (b != 0) return false;
    int u = (int) Math.floor((X - ox) / scale), v = (int) Math.floor((Y - oy) / scale);
    for (int i = hits.size() - 1; i >= 0; i--) {
      var k = hits.get(i);
      if (u >= k.x && u < k.x + k.w && v >= k.y && v < k.y + k.h) {
        k.run.run();
        return true;
      }
    }
    editing = false;
    return super.mouseClicked(X, Y, b);
  }

  @Override
  public boolean mouseScrolled(double X, double Y, double amt) {
    if (app == App.CHAT && tab == 0) {
      threadPage = Math.max(0, threadPage + (amt > 0 ? 1 : -1));
      return true;
    }
    if (app == App.MAP) {
      zoom = Math.max(0, Math.min(3, zoom + (amt > 0 ? -1 : 1)));
      return true;
    }
    if (app == App.SHOP || app == App.NODE || app == App.MORE) {
      page = Math.max(0, page + (amt < 0 ? 1 : -1));
      return true;
    }
    return false;
  }

  @Override
  public boolean charTyped(char ch, int mods) {
    if (editing && !Character.isISOControl(ch) && input.length() < 100) {
      input += ch;
      return true;
    }
    return super.charTyped(ch, mods);
  }

  @Override
  public boolean keyPressed(int k, int scan, int mods) {
    if (editing) {
      if (k == GLFW.GLFW_KEY_ESCAPE) {
        editing = false;
        return true;
      }
      if (k == GLFW.GLFW_KEY_BACKSPACE) {
        if (!input.isEmpty()) input = input.substring(0, input.length() - 1);
        return true;
      }
      if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER) {
        submit();
        return true;
      }
      if (isPaste(k)) {
        String s = minecraft.keyboardHandler.getClipboard().replaceAll("[\\p{Cntrl}]", "");
        input = (input + s).substring(0, Math.min(100, input.length() + s.length()));
        return true;
      }
      if (isSelectAll(k)) {
        input = "";
        return true;
      }
      return true;
    }
    if (PhoneKeys.TABLET.matches(k, scan) || PhoneKeys.OPEN.matches(k, scan)) {
      boolean tablet = PhoneKeys.TABLET.matches(k, scan);
      if (tablet != wide) open(tablet);
      else onClose();
      return true;
    }
    if (k == GLFW.GLFW_KEY_ESCAPE && (detail >= 0 || app != App.HOME)) {
      if (detail >= 0) detail = -1;
      else go(App.HOME);
      return true;
    }
    return super.keyPressed(k, scan, mods);
  }

  private void submit() {
    editing = false;
    if (app == App.CHAT && !input.isBlank()) {
      req("send", input.trim(), 0);
      input = "";
    } else if (app == App.ADMIN) {
      adminAmount = input.isBlank() ? adminAmount : input;
      input = "";
    }
  }

  @Override
  public void render(GuiGraphics gg, int M, int N, float pt) {
    c = new Canvas(gg);
    hits.clear();
    scale = Math.min((width - (wide ? 8 : 12)) / (float) W, (height - 9) / (float) H);
    scale = Math.min(scale, wide ? 1.65f : 1.22f);
    ox = wide ? (int) ((width - W * scale) / 2) : width - (int) (W * scale) - 6;
    oy = (int) ((height - H * scale) / 2);
    double f = Math.max(0, 1 - (System.currentTimeMillis() - born) / 220d);
    oy += (int) (f * f * (wide ? 14 : 45) * scale);
    mx = (int) ((M - ox) / scale);
    my = (int) ((N - oy) / scale);
    if (wide) c.round(0, 0, width, height, 0, 0x66202c29);
    gg.pose().pushPose();
    gg.pose().translate(ox, oy, 10);
    gg.pose().scale(scale, scale, 1);
    c.round(1, 3, W - 2, H - 1, wide ? 20 : 27, 0x68060c09);
    c.round(0, 0, W, H, wide ? 18 : 26, 0x61716a);
    c.round(1, 1, W - 2, H - 2, wide ? 17 : 25, 0x181f1e);
    c.round(5, 5, W - 10, H - 10, wide ? 13 : 21, dark() ? 0x22232d : PAPER);
    if (wide) tabletChrome();
    else phoneChrome();
    switch (app) {
      case HOME -> home();
      case SHOP -> catalog(false);
      case NODE -> node();
      case CHAT -> messages();
      case WALLETS -> wallets();
      case MAP -> map();
      case BANK -> bank();
      case SIM -> sim();
      case MORE -> more();
      case ADMIN -> admin();
    }
    if (!wide) {
      c.round(W / 2 - 22, H - 13, 44, 3, 2, dark() ? 0xb1a6c0 : 0x6b786f);
      hit(W / 2 - 40, H - 22, 80, 19, () -> go(App.HOME));
    }
    if (!status.isEmpty() && System.currentTimeMillis() - statusAt < 2900) {
      c.round(x, y + h - 26, w, 25, 7, 0xf2253832);
      c.small(status, x + 10, y + h - 20, w - 20, 11, WHITE, false);
    }
    gg.pose().popPose();
    Inbox.draw(gg, width, wide);
  }

  private void tabletChrome() {
    c.round(5, 5, 146, H - 10, 13, 0x1b302c);
    c.round(138, 5, 14, H - 10, 0, 0x1b302c);
    c.round(19, 22, 31, 31, 8, LIME);
    c.icon("logo", 22, 25, 25, GREEN);
    c.text("КОНТУР", 58, 23, 17, WHITE, true);
    c.text("FIELD SYSTEM / 07", 58, 42, 7.6f, 0xb6c9bb, true);
    c.text("РАБОЧИЙ СТОЛ", 20, 73, 8, 0x9db5a6, true);
    int row = 0;
    for (App a : App.values()) {
      if (a == App.ADMIN && !d().getBoolean("op")) continue;
      int Y = 91 + row++ * 29;
      boolean sel = app == a;
      int fg = sel ? 0x1b3931 : 0xd2e1d5;
      if (sel || hover(14, Y, 127, 26)) c.round(14, Y, 127, 25, 6, sel ? LIME : 0x334a42);
      c.icon(a.icon, 22, Y + 4, 17, fg);
      c.text(a.title, 47, Y + 5, 12, fg, sel);
      hit(14, Y, 127, 26, () -> go(a));
    }
    c.round(18, 400, 118, 1, 0, 0x466057);
    c.round(21, 420, 6, 6, 3, d().getBoolean("sim") ? LIME : ORANGE);
    c.text(d().getBoolean("sim") ? "Сеть района" : "SIM отключена", 34, 415, 10, 0xc3d4c6, false);
    x = 169;
    y = 76;
    w = W - x - 22;
    h = H - y - 23;
    c.text(
        "ПЕРВОМАЙСК  /  " + (dark() ? "ЗАКРЫТЫЙ КАНАЛ" : "ГОРОДСКАЯ СЕТЬ"),
        x,
        18,
        8.4f,
        muted(),
        true);
    c.text(app == App.HOME ? "Панель района" : app.title, x, 36, 25, ink(), true);
    c.round(W - 131, 24, 104, 28, 14, pale());
    c.icon("signal", W - 119, 31, 13, accent());
    c.text(clock(), W - 101, 29, 14, ink(), true);
    c.round(W - 53, 33, 13, 7, 2, accent());
  }

  private void phoneChrome() {
    c.text(clock(), 22, 15, 10.5f, ink(), true);
    c.round(W / 2 - 23, 12, 46, 11, 6, 0x15201c);
    c.icon("signal", W - 54, 13, 14, ink());
    c.round(W - 35, 18, 13, 6, 2, ink());
    if (app != App.HOME) {
      c.round(15, 34, 25, 25, 8, pale());
      c.icon("back", 20, 39, 15, accent());
      hit(13, 32, 31, 30, () -> go(App.HOME));
    }
    c.text(app == App.HOME ? "КОНТУР" : app.title, app == App.HOME ? 18 : 48, 36, 20, ink(), true);
    c.text(app == App.HOME ? "MOBILE / 07" : "", 165, 44, 8, muted(), true);
    x = 17;
    y = 70;
    w = W - 34;
    h = H - y - 26;
  }

  private void label(String s, int X, int Y) {
    c.text(s, X, Y, 8.7f, muted(), true);
  }

  private void button(int X, int Y, int bw, int bh, String s, boolean primary, Runnable run) {
    boolean over = hover(X, Y, bw, bh);
    int
        bg =
            primary
                ? (dark() ? 0xc9b6df : over ? 0x347263 : GREEN)
                : over ? (dark() ? 0x504a59 : 0xd3e1cd) : pale(),
        fg = primary ? (dark() ? 0x23212a : WHITE) : ink();
    c.round(X, Y, bw, bh, 7, bg);
    c.center(Canvas.fit(s, bw - 8, 11, true), X + bw * .5f, Y + (bh - 12) * .5f, 11, fg, true);
    hit(X, Y, bw, bh, run);
  }

  private void tile(int X, int Y, int bw, int bh, App a, String sub) {
    boolean over = hover(X, Y, bw, bh);
    c.round(X, Y, bw, bh, 10, over ? 0xe8eee1 : WHITE);
    c.round(
        X + 10, Y + 9, 27, 27, 7, a == App.NODE ? 0x373443 : a == App.SHOP ? 0xf3d9bc : 0xdce8d6);
    c.icon(a.icon, X + 15, Y + 14, 17, a == App.NODE ? 0xd6bbeb : GREEN);
    if (wide) {
      c.icon("up", X + bw - 22, Y + 11, 11, MUTED);
      c.small(a.title, X + 10, Y + 44, bw - 20, 15, INK, true);
      c.small(sub, X + 10, Y + 65, bw - 20, 10, MUTED, false);
    } else {
      c.small(a == App.MORE ? "Ещё" : a.title, X + 6, Y + 41, bw - 9, 9.5f, INK, true);
    }
    hit(X, Y, bw, bh, () -> go(a));
  }

  private void home() {
    int hero = wide ? 142 : 104;
    c.pic("city", x, y, w, hero);
    int tx = x + (wide ? 18 : 11);
    c.round(tx, y + 11, wide ? 85 : 73, 15, 6, 0xdfd4e6aa);
    c.text("ВЫПУСК   /   07", tx + 6, y + 14, wide ? 8.4f : 7.6f, 0x234334, true);
    c.text(wide ? "На линии." : "На линии", tx, y + (wide ? 38 : 32), wide ? 32 : 24, WHITE, true);
    c.text(
        wide ? "Почта, поездки и дела квартала." : "Город у тебя в руках.",
        tx,
        y + (wide ? 80 : 66),
        wide ? 12 : 10,
        0xe0eee0,
        false);
    if (wide) {
      c.round(tx, y + 106, 115, 24, 7, LIME);
      c.text("Открыть карту", tx + 10, y + 112, 11, INK, true);
      c.icon("arrow", tx + 95, y + 112, 12, INK);
      hit(tx, y + 106, 115, 24, () -> go(App.MAP));
    }
    int Y = y + hero + 13;
    if (wide) {
      label("БЫСТРЫЙ ДОСТУП", x, Y);
      int bw = (w - 16) / 3;
      tile(x, Y + 16, bw, 84, App.SHOP, "Еда и городские вещи");
      tile(x + bw + 8, Y + 16, bw, 84, App.NODE, "Диспетчерская и выдача");
      tile(x + 2 * (bw + 8), Y + 16, w - 2 * (bw + 8), 84, App.CHAT, "Фото и квитанции");
      Y += 112;
      c.round(x, Y, w, 62, 9, 0xdfe7d6);
      c.icon("wallet", x + 14, Y + 17, 24, GREEN);
      c.text("Счёт района", x + 48, Y + 11, 14, INK, true);
      c.text("Банк · игровые средства", x + 48, Y + 33, 10, MUTED, false);
      c.right(eur(d().getLong("bank")), x + w - 17, Y + 16, 22, GREEN, true);
      hit(x, Y, w, 62, () -> go(App.BANK));
    } else {
      App[] apps = {
        App.SHOP,
        App.MAP,
        App.CHAT,
        App.BANK,
        App.WALLETS,
        App.SIM,
        App.NODE,
        App.MORE,
        d().getBoolean("op") ? App.ADMIN : App.HOME
      };
      int bw = (w - 12) / 3;
      for (int i = 0; i < apps.length; i++) {
        if (i == 8 && apps[i] == App.HOME) continue;
        tile(x + (i % 3) * (bw + 6), Y + (i / 3) * 64, bw, 58, apps[i], "");
      }
      c.round(x, Y + 193, w, 27, 8, 0xdce6d5);
      c.text("Банк", x + 10, Y + 200, 10, MUTED, true);
      c.right(eur(d().getLong("bank")), x + w - 10, Y + 198, 13, GREEN, true);
      hit(x, Y + 193, w, 27, () -> go(App.BANK));
    }
  }

  private static String eur(long cents) {
    return String.format(Locale.ROOT, "%,.2f €", cents / 100d).replace(',', ' ').replace('.', ',');
  }

  private void tabs(String[] s, int selected, int Y, java.util.function.IntConsumer on) {
    int gap = 4, bw = (w - gap * (s.length - 1)) / s.length;
    for (int i = 0; i < s.length; i++) {
      int X = x + i * (bw + gap), v = i;
      int bg = i == selected ? (dark() ? 0x6a577b : GREEN) : pale();
      c.round(X, Y, bw, 23, 7, bg);
      c.center(
          Canvas.fit(s[i], bw - 5, 10.4f, true),
          X + bw / 2f,
          Y + 5,
          10.4f,
          i == selected ? WHITE : ink(),
          true);
      hit(X, Y, bw, 23, () -> on.accept(v));
    }
  }

  private void pager(int Y, int pages) {
    int n = Math.max(1, pages);
    page = Math.max(0, Math.min(page, n - 1));
    c.text("ЛИСТ  " + (page + 1) + " / " + n, x, Y + 6, 9, muted(), true);
    button(x + w - 68, Y, 31, 23, "‹", false, () -> page = Math.max(0, page - 1));
    button(x + w - 31, Y, 31, 23, "›", false, () -> page = Math.min(n - 1, page + 1));
  }

  private void catalog(boolean privateShop) {
    int top = y + (privateShop ? 31 : 0);
    if (detail >= 0) {
      productDetail(top);
      return;
    }
    if (!privateShop) {
      tabs(
          new String[] {"Витрина", "Еда", "Напитки", "Техника"},
          filter,
          top,
          i -> {
            filter = i;
            page = 0;
          });
      top += 32;
    }
    List<Integer> ids = new ArrayList<>();
    for (int i = 0; i < Stock.ALL.size(); i++) {
      var p = Stock.ALL.get(i);
      if (privateShop
          ? p.section() == 3
          : p.section() != 3 && (filter == 0 || p.section() == filter - 1)) ids.add(i);
    }
    label(
        privateShop
            ? "УЗЕЛ 09   /   АРХИВ ПРЕДМЕТОВ"
            : "CITY SUPPLY   /   " + ids.size() + " ПОЗИЦИЙ",
        x,
        top);
    top += 17;
    int cols = wide ? 3 : 2, per = cols * 2, n = (ids.size() + per - 1) / per;
    page = Math.max(0, Math.min(page, n - 1));
    int gap = 7, bw = (w - (cols - 1) * gap) / cols, hh = (y + h - 31 - top - gap) / 2;
    for (int j = 0; j < per && page * per + j < ids.size(); j++) {
      int i = ids.get(page * per + j);
      var v = Stock.ALL.get(i);
      int X = x + j % cols * (bw + gap), Y = top + j / cols * (hh + gap);
      c.round(X, Y, bw, hh, 8, card());
      int ih = Math.min(hh - 39, (int) (bw * .53));
      c.pic("products/" + v.id(), X + 3, Y + 3, bw - 6, ih);
      c.small(v.title(), X + 7, Y + ih + 7, bw - 14, wide ? 12.5f : 10.6f, ink(), true);
      c.small(eur(v.price()), X + 7, Y + hh - 17, bw - 27, 11, accent(), true);
      c.icon("plus", X + bw - 20, Y + hh - 18, 12, accent());
      hit(X, Y, bw, hh, () -> detail = i);
    }
    pager(y + h - 24, n);
  }

  private void productDetail(int Y) {
    var v = Stock.ALL.get(detail);
    button(x, Y, 68, 23, "‹  Каталог", false, () -> detail = -1);
    int by = Y + 33;
    int iw = wide ? w / 2 : w, ih = wide ? 174 : 124;
    c.pic("products/" + v.id(), x, by, iw, ih);
    int X = wide ? x + iw + 15 : x, top = wide ? by + 7 : by + ih + 12, sw = wide ? w - iw - 15 : w;
    label(v.section() == 3 ? "АРХИВ   /   FIELD OBJECT" : "КАТАЛОГ   /   ГОРОДСКАЯ СЕРИЯ", X, top);
    c.small(v.title(), X, top + 19, sw, wide ? 20 : 16, ink(), true);
    c.text(v.note(), X, top + 49, 12, muted(), false);
    c.text(eur(v.price()), X, top + 75, 22, accent(), true);
    c.small(
        v.nutrition() > 0
            ? "Съедобный предмет · питание +" + v.nutrition()
            : "Предмет попадёт в инвентарь",
        X,
        top + 108,
        sw,
        10,
        muted(),
        false);
    button(
        x,
        y + h - 32,
        w,
        30,
        "Купить за " + eur(v.price()),
        true,
        () -> {
          long n = System.currentTimeMillis();
          if (n - lastBuy > 450) {
            req("buy", "", detail);
            lastBuy = n;
          }
        });
  }

  private void node() {
    tabs(
        new String[] {"Диспетчерская", "Закрытая лавка"},
        tab,
        y,
        i -> {
          tab = i;
          detail = -1;
          page = 0;
        });
    if (tab == 1) {
      catalog(true);
      return;
    }
    int Y = y + 32;
    if (has()) {
      active(Y);
      return;
    }
    if (detail >= 0) {
      var b = Deliveries.BOARD.get(detail);
      button(x, Y, 84, 23, "‹  К заявкам", false, () -> detail = -1);
      c.pic("products/" + b.photo(), x, Y + 32, wide ? 180 : 102, wide ? 105 : 76);
      int X = x + (wide ? 194 : 111);
      label("ЗАЯВКА  /  0" + (detail + 1), X, Y + 37);
      c.small(b.title(), X, Y + 54, w - (X - x), wide ? 23 : 14, ink(), true);
      c.small(b.client(), X, Y + 83, w - (X - x), 11, muted(), false);
      int A = Y + (wide ? 150 : 124);
      c.wrap(b.blurb(), x, A, w, 13, 16, 2, ink());
      label("ВЫБЕРИ МЕСТО ПЕРЕДАЧИ", x, A + 41);
      int half = (w - 6) / 2;
      button(x, A + 60, half, 27, "Переулок", !square, () -> square = false);
      button(x + half + 6, A + 60, w - half - 6, 27, "Площадь", square, () -> square = true);
      button(
          x,
          y + h - 33,
          w,
          31,
          "Принять   ·   " + b.euros() + " €",
          true,
          () -> req("order", square ? "square" : "alley", detail));
      return;
    }
    c.pic("night", x, Y, w, wide ? 82 : 63);
    c.text("УЗЕЛ / 09", x + 12, Y + 8, wide ? 25 : 22, WHITE, true);
    c.text(
        "Закрытый канал городских доставок",
        x + 12,
        Y + (wide ? 49 : 40),
        wide ? 12 : 10,
        0xe1cfee,
        false);
    Y += wide ? 93 : 73;
    int cols = wide ? 2 : 1, per = wide ? 4 : 3, n = (Deliveries.BOARD.size() + per - 1) / per;
    page = Math.max(0, Math.min(page, n - 1));
    int bw = (w - (cols - 1) * 7) / cols, bh = wide ? 85 : 57;
    for (int k = 0; k < per && page * per + k < Deliveries.BOARD.size(); k++) {
      int i = page * per + k;
      var b = Deliveries.BOARD.get(i);
      int X = x + (k % cols) * (bw + 7), YY = Y + (k / cols) * (bh + 7);
      c.round(X, YY, bw, bh, 8, card());
      int iw = wide ? 84 : 66;
      c.pic("products/" + b.photo(), X + 5, YY + 6, iw, bh - 12);
      int tx = X + iw + 12;
      c.small("0" + (i + 1) + "   /   " + b.client(), tx, YY + 7, bw - iw - 17, 8, muted(), true);
      c.small(b.title(), tx, YY + (wide ? 28 : 21), bw - iw - 17, wide ? 14 : 12, ink(), true);
      c.text(b.euros() + " €", tx, YY + bh - 22, 13, 0xd6bddf, true);
      hit(X, YY, bw, bh, () -> detail = i);
    }
    pager(y + h - 24, n);
  }

  private void active(int Y) {
    var j = job();
    var b = Deliveries.BOARD.get(j.getInt("brief"));
    int ph = j.getInt("phase");
    c.round(x, Y, w, wide ? 103 : 94, 9, card());
    int phw = wide ? 72 : 57;
    c.pic(face(j.getInt("skin")), x + 8, Y + 7, phw, wide ? 86 : 76);
    int X = x + phw + 17;
    c.text("АКТИВНАЯ ДОСТАВКА", X, Y + 10, 8.5f, accent(), true);
    c.small(b.title(), X, Y + 29, w - phw - 26, wide ? 19 : 14, ink(), true);
    c.small(j.getString("name"), X, Y + 53, w - phw - 26, 12, ink(), false);
    c.small(
        j.getString("location") + "  /  с " + j.getString("time"),
        X,
        Y + 72,
        w - phw - 26,
        10,
        muted(),
        false);
    int yy = Y + (wide ? 119 : 108);
    label("ЖУРНАЛ МАРШРУТА", x, yy);
    String[] stops = {
      "Забрать посылку на выдаче",
      "Встретить получателя у метки",
      "Получить " + eur(j.getLong("reward"))
    };
    for (int i = 0; i < 3; i++) {
      int row = yy + 19 + i * 24;
      c.round(x + 1, row, 16, 16, 8, i + 1 <= ph ? 0xb9a1ce : 0x44424f);
      c.center("" + (i + 1), x + 9, row + 2, 10, i + 1 <= ph ? DARK : ink(), true);
      c.small(stops[i], x + 26, row + 1, w - 28, 12, ink(), i + 1 == ph);
    }
    int half = (w - 6) / 2;
    button(
        x,
        yy + 100,
        half,
        27,
        "На карте",
        true,
        () -> {
          go(App.MAP);
          mapCenter = ph;
        });
    button(x + half + 6, yy + 100, w - half - 6, 27, "Переписка", false, () -> go(App.CHAT));
    button(
        x,
        y + h - 29,
        w,
        26,
        confirm ? "Подтвердить отмену" : "Отменить заказ",
        false,
        () -> {
          if (!confirm) {
            confirm = true;
            return;
          }
          req("cancel", "", 0);
          confirm = false;
          detail = -1;
        });
  }

  private static String face(int i) {
    return String.format(Locale.ROOT, "faces/%02d", Math.floorMod(i, 49));
  }

  private void messages() {
    tabs(
        new String[] {"Переписка", "Реквизиты"},
        tab,
        y,
        i -> {
          tab = i;
          threadPage = 0;
          editing = false;
        });
    int Y = y + 30;
    if (tab == 1) {
      if (!has()) {
        empty("wallet", "Реквизиты для заказа", "Сначала выбери доставку в Узле 09.", Y, App.NODE);
        return;
      }
      label("ОТПРАВИТЬ АДРЕС ПОЛУЧАТЕЛЮ", x, Y + 3);
      for (int i = 0; i < 5; i++) {
        final int k = i;
        String addr = d().getString("address" + i);
        int row = Y + 20 + i * 44;
        c.round(x, row, w, 39, 8, card());
        c.icon(i == 4 ? "sim" : "wallet", x + 8, row + 10, 18, accent());
        c.text(Wallets.NAMES[i], x + 34, row + 5, 13, ink(), true);
        c.small(
            addr.isEmpty() ? "Нужен Ledger в инвентаре" : Wallets.shortId(addr),
            x + 34,
            row + 22,
            w - 124,
            9,
            muted(),
            false);
        button(
            x + w - 81,
            row + 6,
            74,
            26,
            "Отправить",
            true,
            () -> {
              if (addr.isEmpty()) note("Сначала возьми физический Ledger");
              else {
                req("route", d().getString("address" + k), 0);
                tab = 0;
                threadPage = 0;
              }
            });
      }
      c.wrap(
          "Это адреса внутри сохранения. Внешних переводов и реальных монет здесь нет.",
          x,
          Y + 245,
          w,
          11,
          15,
          3,
          muted());
      return;
    }
    ListTag ml = d().getList("inbox", 10);
    if (ml.isEmpty()) {
      empty(
          "chat",
          "Пока тихо",
          "Прими заказ — диспетчер пришлёт фото, место встречи и время.",
          Y,
          App.NODE);
      return;
    }
    int rows = wide ? 4 : 3,
        available = has() ? h - 103 : h - 75,
        rh = Math.min(69, available / rows);
    int maxPage = (ml.size() - 1) / rows;
    threadPage = Math.max(0, Math.min(maxPage, threadPage));
    label("ЖУРНАЛ   /   НОВЫЕ СВЕРХУ", x, Y + 2);
    Y += 17;
    for (int i = 0; i < rows; i++) {
      int idx = ml.size() - 1 - threadPage * rows - i;
      if (idx < 0) break;
      var m = ml.getCompound(idx);
      int YY = Y + i * rh, ph = m.getInt("photo");
      c.round(x, YY, w, rh - 4, 7, m.getString("from").equals("Вы") ? 0xe1ebda : card());
      int iw = ph >= 0 ? 37 : 20;
      if (ph >= 0) c.pic(face(ph), x + 6, YY + 5, iw, rh - 14);
      else c.icon("mail", x + 6, YY + 10, iw, accent());
      int X = x + iw + 14;
      c.small(m.getString("from"), X, YY + 4, w - iw - 67, 11, ink(), true);
      c.right(m.getString("at"), x + w - 8, YY + 5, 9, muted(), false);
      c.wrap(
          m.getString("text"), X, YY + 20, w - iw - 22, wide ? 11 : 10, wide ? 13 : 11, 3, ink());
    }
    int footer = y + h - (has() ? 57 : 25);
    button(x, footer, 63, 21, "‹  Новее", false, () -> threadPage = Math.max(0, threadPage - 1));
    button(
        x + 68,
        footer,
        70,
        21,
        "Старее  ›",
        false,
        () -> threadPage = Math.min(maxPage, threadPage + 1));
    if (has()) {
      field(x, y + h - 28, w - 38, 27, "Сообщение или адрес PB…");
      button(x + w - 33, y + h - 28, 33, 27, "→", true, this::submit);
    }
  }

  private void field(int X, int Y, int bw, int bh, String placeholder) {
    c.round(X, Y, bw, bh, 6, editing ? accent() : LINE);
    c.round(X + 1, Y + 1, bw - 2, bh - 2, 5, card());
    c.small(
        editing
            ? input + ((System.currentTimeMillis() / 450) % 2 == 0 ? "|" : "")
            : input.isEmpty() ? placeholder : input,
        X + 7,
        Y + 7,
        bw - 14,
        11,
        ink(),
        false);
    hit(
        X,
        Y,
        bw,
        bh,
        () -> {
          if (!editing && app == App.ADMIN) input = adminAmount;
          editing = true;
        });
  }

  private void empty(String ico, String title, String body, int Y, App next) {
    c.round(x, Y, w, 152, 10, card());
    c.round(x + 12, Y + 13, 32, 32, 9, pale());
    c.icon(ico, x + 19, Y + 20, 18, accent());
    c.text(title, x + 13, Y + 54, wide ? 20 : 16, ink(), true);
    c.wrap(body, x + 13, Y + 85, w - 26, 12, 15, 3, muted());
    button(x, Y + 166, w, 30, "Открыть: " + next.title, true, () -> go(next));
  }

  private void denominations(int Y) {
    int bw = (w - 12) / 4;
    for (int i = 0; i < 4; i++) {
      int k = i;
      button(x + i * (bw + 4), Y, bw, 24, AMOUNTS[i] / 100 + " €", amount == i, () -> amount = k);
    }
  }

  private void wallets() {
    tabs(Wallets.NAMES, wallet, y, i -> wallet = i);
    int Y = y + 32;
    String addr = d().getString("address" + wallet);
    int bg = wallet == 0 ? 0x302f2b : wallet == 1 ? 0x3b3626 : wallet == 4 ? 0x30323b : 0x234b46,
        col = wallet == 1 ? 0xf4cb61 : wallet == 0 ? 0xefb56e : wallet == 4 ? 0xcbbde2 : LIME;
    c.round(x, Y, w, 95, 10, bg);
    c.text(
        Wallets.NAMES[wallet].toUpperCase(Locale.ROOT) + "   /   PB · BIT",
        x + 13,
        Y + 10,
        10,
        col,
        true);
    c.small(
        Wallets.bit(d().getDouble("bit" + wallet)),
        x + 13,
        Y + 31,
        w - 27,
        wide ? 26 : 22,
        WHITE,
        true);
    c.small(
        addr.isEmpty() ? "Устройство не подключено" : Wallets.shortId(addr),
        x + 13,
        Y + 71,
        w - 60,
        10,
        0xd2dbd1,
        false);
    c.icon("copy", x + w - 29, Y + 65, 16, col);
    hit(
        x,
        Y + 60,
        w,
        34,
        () -> {
          if (addr.isEmpty()) {
            note("Возьми Ledger в основную руку или инвентарь");
            return;
          }
          minecraft.keyboardHandler.setClipboard(addr);
          note("Игровой адрес скопирован");
        });
    int A = Y + 106;
    label("ИГРОВОЙ КУРС  /  1 BIT", x, A);
    c.text(eur(Math.round(BitMarket.price(time()) * 100)), x, A + 16, 16, ink(), true);
    int chartW = wide ? 153 : 74;
    float last = 0;
    for (int i = 0; i < 28; i++) {
      float v = (float) (BitMarket.price(time() - (27 - i) * 550L) / 40000d);
      float cy = A + 27 - (v - 1) * 34;
      if (i > 0)
        c.line(
            x + w - chartW + (i - 1) * chartW / 27f,
            last,
            x + w - chartW + i * chartW / 27f,
            cy,
            1.5f,
            GREEN);
      last = cy;
    }
    denominations(A + 45);
    int half = (w - 6) / 2;
    button(
        x,
        A + 78,
        half,
        26,
        "Купить со счёта",
        true,
        () -> req("walletBuy", "" + wallet, AMOUNTS[amount]));
    button(
        x + half + 6,
        A + 78,
        w - half - 6,
        26,
        "Продать в банк",
        false,
        () -> req("walletSell", "" + wallet, AMOUNTS[amount]));
    button(
        x,
        A + 111,
        w,
        26,
        "Обменять игровые наличные",
        false,
        () -> req("cashbit", "" + wallet, AMOUNTS[amount]));
    c.wrap(
        wallet == 4
            ? "Входящие — на конкретный предмет. Для расхода возьми Ledger в руку и используй"
                + " /ledger unlock."
            : "Счёт и продажа: 1% комиссии. Обмен наличных: 3%. Счета существуют только в этом"
                + " мире.",
        x,
        A + 148,
        w,
        10.6f,
        13,
        3,
        muted());
  }

  private void bank() {
    c.round(x, y, w, 105, 12, 0x23493f);
    c.icon("bank", x + 12, y + 11, 19, LIME);
    c.text("ГОРОДСКОЙ БАНК", x + 40, y + 14, 10, LIME, true);
    c.small(
        d().getBoolean("inf") ? "∞  Безлимит" : eur(d().getLong("bank")),
        x + 13,
        y + 42,
        w - 27,
        wide ? 30 : 23,
        WHITE,
        true);
    c.text("Наличные: " + eur(d().getLong("cash")), x + 14, y + 82, 11, 0xd8e8d6, false);
    int A = y + 117;
    label("ОПЕРАЦИЯ  /  СУММА", x, A);
    denominations(A + 19);
    int half = (w - 6) / 2;
    button(x, A + 54, half, 26, "Внести", true, () -> req("deposit", "", AMOUNTS[amount]));
    button(
        x + half + 6,
        A + 54,
        w - half - 6,
        26,
        "Снять",
        false,
        () -> req("withdraw", "", AMOUNTS[amount]));
    c.round(x, A + 96, w, 96, 8, card());
    c.text("Статус выплат", x + 10, A + 107, 14, ink(), true);
    c.small(
        "Без квитанции: " + eur(d().getLong("dirty")), x + 10, A + 132, w - 20, 11, muted(), false);
    c.small(
        "Отметка банка: " + eur(d().getLong("traced")),
        x + 10,
        A + 150,
        w - 20,
        11,
        muted(),
        false);
    c.small("Участок: " + d().getString("police"), x + 10, A + 169, w - 20, 11, accent(), true);
  }

  private void sim() {
    tabs(
        new String[] {"Моя SIM", "Банк-сим", "Голос NPC"},
        tab,
        y,
        i -> {
          tab = i;
          symbols = "";
        });
    int Y = y + 32;
    if (tab == 0) {
      c.round(x, Y, w, 127, 12, 0x294b4a);
      c.icon("sim", x + 12, Y + 12, 25, LIME);
      c.text("MOBILE SIM  /  07", x + 46, Y + 17, 11, LIME, true);
      c.text("PB  " + d().getInt("number"), x + 13, Y + 54, wide ? 28 : 23, WHITE, true);
      c.text(
          d().getBoolean("sim") ? "Городская сеть активна" : "Профиль приостановлен",
          x + 14,
          Y + 97,
          12,
          WHITE,
          false);
      c.wrap(
          "Игровая SIM открывает канал заявок и учебный банковский терминал. Мессенджер и карта"
              + " доступны без тарифа.",
          x,
          Y + 142,
          w,
          12,
          16,
          4,
          muted());
      button(
          x,
          Y + 218,
          w,
          30,
          d().getBoolean("sim") ? "Приостановить SIM" : "Подключить SIM",
          true,
          () -> req("sim", "", d().getBoolean("sim") ? 0 : 1));
      return;
    }
    if (tab == 2) {
      c.text("Голосовой канал", x, Y + 3, 20, ink(), true);
      String[] rows = {"Simple Voice Chat", "Распознавание речи", "Озвучивание ответов"};
      boolean[] vals = {d().getBoolean("svc"), d().getBoolean("stt"), d().getBoolean("tts")};
      for (int i = 0; i < 3; i++) {
        c.round(x, Y + 38 + i * 30, w, 26, 6, card());
        c.text(rows[i], x + 9, Y + 45 + i * 30, 11, ink(), false);
        c.right(
            vals[i] ? (i == 0 ? "Установлен" : "Настроено") : "Не настроено",
            x + w - 9,
            Y + 45 + i * 30,
            10,
            muted(),
            true);
      }
      c.wrap(
          "Только с твоего разрешения реплики микрофона передаются в сервис распознавания сервера."
              + " Можно говорить текстом без микрофона.",
          x,
          Y + 145,
          w,
          12,
          16,
          5,
          muted());
      button(
          x,
          y + h - 32,
          w,
          30,
          d().getBoolean("mic") ? "Выключить распознавание" : "Разрешить распознавание",
          true,
          () -> req("voice", "", d().getBoolean("mic") ? 0 : 1));
      return;
    }
    c.text("Учебный терминал", x, Y + 4, wide ? 23 : 18, ink(), true);
    c.wrap(
        "Восстанови доступ к вымышленному счёту: запомни последовательность, затем повтори её."
            + " Награда — 25 игровых евро.",
        x,
        Y + 39,
        w,
        12,
        15,
        4,
        muted());
    long now = time(), until = d().getLong("until");
    boolean playing = until > now;
    String pattern = d().getString("pattern");
    String show = playing ? (now < d().getLong("hide") ? pattern : symbols) : "";
    c.round(x, Y + 113, w, 53, 9, 0x273f39);
    StringBuilder shown = new StringBuilder();
    for (int i = 0; i < 4; i++) {
      int sym = i < show.length() ? show.charAt(i) - '1' : -1;
      shown.append(sym >= 0 && sym < 4 ? SIGS[sym] : "·").append("   ");
    }
    c.center(shown.toString().trim(), x + w / 2f, Y + 127, 21, LIME, true);
    if (!playing) {
      long rem = (d().getLong("simNext") - now + 19) / 20;
      button(
          x,
          Y + 186,
          w,
          29,
          rem > 0 ? "Следующий сеанс через " + rem + " с" : "Начать сеанс",
          true,
          () -> {
            symbols = "";
            req("puzzle", "", 0);
          });
    } else if (now >= d().getLong("hide")) {
      int bw = (w - 12) / 4;
      for (int i = 0; i < 4; i++) {
        int k = i;
        button(
            x + i * (bw + 4),
            Y + 184,
            bw,
            33,
            SIGS[i],
            true,
            () -> {
              if (symbols.length() < 4) symbols += (k + 1);
              if (symbols.length() == 4) req("answer", symbols, 0);
            });
      }
    } else c.text("Запоминай…", x, Y + 185, 12, muted(), false);
  }

  private void map() {
    if (minecraft.player == null || minecraft.level == null) return;
    var pl = minecraft.player;
    var j = job();
    boolean same =
        has() && minecraft.level.dimension().location().toString().equals(j.getString("dim"));
    var pois = d().getCompound("points");
    String[] centers =
        same
            ? new String[] {"Моя позиция", "Выдача", "Встреча"}
            : pois.contains("pickup")
                ? new String[] {"Моя позиция", "Квартал"}
                : new String[] {"Моя позиция"};
    if (mapCenter >= centers.length) mapCenter = 0;
    tabs(centers, mapCenter, y, i -> mapCenter = i);
    int Y = y + 31, mh = wide ? 218 : 199;
    BlockPos p = pl.blockPosition(),
        pick = BlockPos.of(j.getLong("pickup")),
        meet = BlockPos.of(j.getLong("meet")),
        centre =
            mapCenter == 0
                ? p
                : !same ? BlockPos.of(pois.getLong("pickup")) : mapCenter == 1 ? pick : meet;
    int tw = wide ? 222 : 126, th = wide ? 88 : 107;
    if (terrain == null) terrain = new Terrain(tw, th);
    int st = ZOOMS[zoom];
    terrain.update(
        Math.floorDiv(centre.getX(), st) * st, Math.floorDiv(centre.getZ(), st) * st, st);
    c.image(terrain.id, x, Y, w, mh, 0, 0, 1, 1);
    float[] me = point(p, Y, mh);
    String[] names = {"Выдача", "Переулок", "Площадь", "Участок"},
        keys = {"pickup", "alley", "square", "station"},
        icons = {"cube", "pin", "pin", "op"};
    List<int[]> placed = new ArrayList<>();
    for (int i = 0; i < keys.length; i++) {
      if (!pois.contains(keys[i])) continue;
      float[] pt = point(BlockPos.of(pois.getLong(keys[i])), Y, mh);
      if (pt[2] == 0) continue;
      int X = (int) pt[0], YY = (int) pt[1], lw = (int) Canvas.width(names[i], 9, true) + 8;
      c.round(X - 5, YY - 5, 10, 10, 4, i == 3 ? 0x8e7a9e : 0x54817b);
      c.icon(icons[i], X - 4, YY - 4, 8, WHITE);
      int lx = Math.max(x + 3, Math.min(x + w - lw - 3, X + 7)), ly = YY - 7;
      for (int k = 0; k < 5; k++) {
        boolean overlap = false;
        for (var a : placed)
          if (lx < a[0] + a[2] + 1 && lx + lw > a[0] - 1 && ly < a[1] + 14 && ly + 13 > a[1])
            overlap = true;
        if (!overlap) break;
        ly += 13;
      }
      if (ly < Y + mh - 16) {
        c.round(lx, ly, lw, 13, 4, 0xebfffef8);
        c.text(names[i], lx + 4, ly + 1, 9, INK, true);
        placed.add(new int[] {lx, ly, lw});
      }
    }

    if (!d().getString("estate").isEmpty()
        && minecraft.level.dimension() == net.minecraft.world.level.Level.OVERWORLD)
      for (String s : d().getString("estate").split(";")) {
        String[] a = s.split("\\|");
        if (a.length < 2) continue;
        try {
          String[] coords = a[1].split(",");
          float[] m =
              point(
                  new BlockPos(
                      Integer.parseInt(coords[0]),
                      Integer.parseInt(coords[1]),
                      Integer.parseInt(coords[2])),
                  Y,
                  mh);
          if (m[2] > 0) c.icon("home", m[0] - 6, m[1] - 7, 13, 0x72664d);
        } catch (RuntimeException ignored) {
        }
      }
    if (same) {
      float[] one = point(pick, Y, mh),
          two = point(meet, Y, mh),
          dest = j.getInt("phase") == 1 ? one : two;
      int pieces =
          Math.min(70, Math.max(2, (int) (Math.hypot(dest[0] - me[0], dest[1] - me[1]) / 8)));
      for (int i = 0; i < pieces; i += 2) {
        float f = i / (float) pieces, F = (i + 1f) / pieces;
        c.line(
            me[0] + (dest[0] - me[0]) * f,
            me[1] + (dest[1] - me[1]) * f,
            me[0] + (dest[0] - me[0]) * F,
            me[1] + (dest[1] - me[1]) * F,
            2.4f,
            0x5b568e);
      }
      marker(one, "1", 0x326453);
      marker(two, "2", 0x95603f);
    }
    if (me[2] > 0) {
      c.round(me[0] - 9, me[1] - 9, 18, 18, 9, 0x604678a9);
      c.round(me[0] - 5, me[1] - 5, 10, 10, 5, WHITE);
      c.round(me[0] - 3.6f, me[1] - 3.6f, 7.2f, 7.2f, 3.6f, 0x3f76a9);
    }
    c.round(x + 7, Y + 7, 24, 23, 6, WHITE);
    c.center("N", x + 19, Y + 11, 12, GREEN, true);
    button(x + w - 31, Y + 7, 24, 23, "+", false, () -> zoom = Math.max(0, zoom - 1));
    button(x + w - 31, Y + 33, 24, 23, "−", false, () -> zoom = Math.min(3, zoom + 1));
    c.round(x + 7, Y + mh - 22, wide ? 148 : 107, 16, 5, 0xecfffef8);
    c.small(
        "X " + centre.getX() + "  /  Z " + centre.getZ(),
        x + 12,
        Y + mh - 19,
        wide ? 139 : 98,
        9,
        INK,
        true);
    int B = Y + mh + 10;
    if (same) {
      int phase = j.getInt("phase");
      BlockPos dest = phase == 1 ? pick : meet;
      int dist =
          (int)
              Math.round(
                  Math.sqrt(pl.distanceToSqr(dest.getX() + .5, dest.getY(), dest.getZ() + .5)));
      label("АКТИВНАЯ ДОСТАВКА", x, B);
      c.small(
          (phase == 1 ? "Точка выдачи" : j.getString("location")) + "  ·  " + dist + " м",
          x,
          B + 15,
          w,
          wide ? 17 : 14,
          ink(),
          true);
      c.small(
          "X "
              + dest.getX()
              + "   Y "
              + dest.getY()
              + "   Z "
              + dest.getZ()
              + "    /    "
              + (phase == 1 ? "забрать посылку" : "передать лично, ПКМ"),
          x,
          B + 38,
          w,
          10,
          muted(),
          false);
      button(
          x,
          y + h - 25,
          w,
          24,
          phase == 1 ? "Забрать на месте" : "Открыть переписку",
          true,
          () -> {
            if (phase == 1) req("pick", "", 0);
            else go(App.CHAT);
          });
    } else {
      label("ТОПОГРАФИЯ  /  СЕВЕР СВЕРХУ", x, B);
      c.wrap(
          "Цвета — поверхность загруженных чанков. Штриховка — неизведанная зона. После принятия"
              + " заявки здесь появятся точки маршрута.",
          x,
          B + 18,
          w,
          11,
          14,
          3,
          muted());
    }
  }

  private float[] point(BlockPos p, int Y, int mh) {
    float X = x + w * .5f + (p.getX() - terrain.x) * w / (float) (terrain.w * terrain.step),
        yy = Y + mh * .5f + (p.getZ() - terrain.z) * mh / (float) (terrain.h * terrain.step);
    return new float[] {
      Math.max(x + 9, Math.min(x + w - 9, X)),
      Math.max(Y + 9, Math.min(Y + mh - 9, yy)),
      X >= x && X < x + w && yy >= Y && yy < Y + mh ? 1 : 0
    };
  }

  private void marker(float[] p, String s, int cl) {
    if (p[2] == 0) return;
    c.round(p[0] - 8, p[1] - 8, 16, 16, 8, WHITE);
    c.round(p[0] - 6, p[1] - 6, 12, 12, 6, cl);
    c.center(s, p[0], p[1] - 5, 8, WHITE, true);
  }

  private void admin() {
    if (!d().getBoolean("op")) {
      empty("op", "Нет доступа", "Панель открыта только операторам уровня 2.", y, App.HOME);
      return;
    }
    var players = d().getList("players", 10);
    if (players.isEmpty()) return;
    playerIndex = Math.max(0, Math.min(playerIndex, players.size() - 1));
    var t = players.getCompound(playerIndex);
    String id = t.getString("id");
    int Y = y;
    c.round(x, Y, w, 63, 9, 0x293d37);
    c.text(
        "ОПЕРАТОР  /  ИГРОК " + (playerIndex + 1) + " ИЗ " + players.size(),
        x + 11,
        Y + 8,
        9,
        LIME,
        true);
    c.small(t.getString("name"), x + 11, Y + 28, w - 90, 19, WHITE, true);
    button(
        x + w - 74,
        Y + 19,
        28,
        25,
        "‹",
        false,
        () -> playerIndex = Math.floorMod(playerIndex - 1, players.size()));
    button(
        x + w - 39,
        Y + 19,
        28,
        25,
        "›",
        false,
        () -> playerIndex = (playerIndex + 1) % players.size());
    label("СЧЁТ  /  " + eur(t.getLong("bank")), x, Y + 76);
    c.small("Наличными: " + eur(t.getLong("cash")), x, Y + 94, w, 11, muted(), false);
    label("СУММА В ИГРОВЫХ ЕВРО", x, Y + 122);
    field(x, Y + 138, w, 27, adminAmount + " €  ·  изменить");
    int half = (w - 6) / 2;
    button(x, Y + 174, half, 29, "На счёт", true, () -> grant(id, "adminBank"));
    button(
        x + half + 6, Y + 174, w - half - 6, 29, "Наличными", false, () -> grant(id, "adminCash"));
    boolean inf = t.getBoolean("inf");
    button(
        x,
        Y + 215,
        w,
        28,
        inf ? "∞   Выключить безлимит" : "∞   Включить безлимит",
        !inf,
        () -> req(inf ? "infOff" : "infOn", id, 0));
    button(x, Y + 252, half, 25, "Помиловать", false, () -> req("pardon", id, 0));
    button(
        x + half + 6,
        Y + 252,
        w - half - 6,
        25,
        confirm ? "Подтвердить" : "Участок здесь",
        false,
        () -> {
          if (confirm) {
            req("setJail", "", 0);
            confirm = false;
          } else confirm = true;
        });
    c.wrap(
        "Сервер проверяет права, игрока и сумму при каждой операции. Выключение безлимита"
            + " возвращает сохранённый баланс.",
        x,
        Y + 290,
        w,
        10,
        13,
        3,
        muted());
  }

  private void grant(String id, String op) {
    if (editing) submit();
    try {
      var n =
          new java.math.BigDecimal(adminAmount.replace(',', '.'))
              .movePointRight(2)
              .longValueExact();
      if (n <= 0 || n > 100_000_000_000L) throw new NumberFormatException();
      req(op, id, n);
    } catch (RuntimeException e) {
      note("Введи сумму от 0,01 до 1 000 000 000 €");
    }
  }

  private void more() {
    String[][] a = {
      {"CONTACTS", "Контакты", "Звонки знакомым жителям", "phone"},
      {"JOBS", "Биржа смен", "Работа и выдача зарплаты", "bag"},
      {"ESTATE", "Недвижимость", "Объекты и доход", "home"},
      {"MARKET", "Барахолка", "Продажа вещи из руки", "market"},
      {"WEATHER", "Погода", "Сводка по миру", "signal"},
      {"CALC", "Калькулятор", "Карманный счёт", "card"},
      {"CASINO", "Аркада", "Игры на городские деньги", "cube"},
      {"GROCERY", "Бакалея", "Продукты классической лавки", "bag"},
      {"NET", "Старая сеть", "Игра на память", "node"},
      {"BLACK", "Архив PB", "Каталог из build 15", "clip"}
    };
    int per = wide ? 8 : 5, n = (a.length + per - 1) / per, cols = wide ? 2 : 1;
    page = Math.max(0, Math.min(page, n - 1));
    label("СЕРВИСЫ  /  PB CITY", x, y + 2);
    int bw = (w - (cols - 1) * 8) / cols;
    for (int i = 0; i < per && i + page * per < a.length; i++) {
      var entry = a[page * per + i];
      int X = x + i % cols * (bw + 8), Y = y + 21 + i / cols * (wide ? 68 : 54);
      c.round(X, Y, bw, wide ? 60 : 47, 8, card());
      c.round(X + 7, Y + 9, 29, 29, 7, pale());
      c.icon(entry[3], X + 13, Y + 15, 17, accent());
      c.text(entry[1], X + 45, Y + 7, 13, ink(), true);
      c.small(entry[2], X + 45, Y + 27, bw - 53, 10, muted(), false);
      hit(X, Y, bw, wide ? 60 : 47, () -> minecraft.setScreen(new PhoneScreen(entry[0], wide)));
    }
    pager(y + h - 24, n);
  }
}
