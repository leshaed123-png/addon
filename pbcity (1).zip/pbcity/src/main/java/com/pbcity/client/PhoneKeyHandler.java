package com.pbcity.client;

import com.pbcity.PBCity;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class PhoneKeyHandler {
    private PhoneKeyHandler() {}

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (PhoneKeys.TABLET.consumeClick()) if(mc.player!=null && mc.screen==null)com.pbcity.client.kontur.KonturScreen.open(true);
        while (PhoneKeys.OPEN.consumeClick()) {
            if (mc.player != null && mc.screen == null) com.pbcity.client.kontur.KonturScreen.open(false);
        }
    }
}
