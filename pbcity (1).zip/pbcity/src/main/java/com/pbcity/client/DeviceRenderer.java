package com.pbcity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.pbcity.PBCity;
import com.pbcity.ballistics.Ballistics;
import com.pbcity.ballistics.Raycast;
import com.pbcity.ballistics.WindManager;
import com.pbcity.config.PBConfig;
import com.pbcity.item.LedgerItem;
import com.pbcity.item.RangefinderItem;
import com.pbcity.item.WindMeterItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Draws the two handheld devices: the static body from a baked model, the animated parts (spinning impeller,
 * scanning laser emitter) with a live rotation, and the LCD text directly onto the model's screen.
 * Model space is 16 pixels per block; the screen faces +z.
 */
public class DeviceRenderer extends BlockEntityWithoutLevelRenderer {
    public static final ResourceLocation RF_BODY = new ResourceLocation(PBCity.MODID, "item/rangefinder_body");
    public static final ResourceLocation RF_RING = new ResourceLocation(PBCity.MODID, "item/rangefinder_ring");
    public static final ResourceLocation WM_BODY = new ResourceLocation(PBCity.MODID, "item/wind_meter_body");
    public static final ResourceLocation WM_BLADES = new ResourceLocation(PBCity.MODID, "item/wind_meter_blades");
    public static final ResourceLocation LG_BODY = new ResourceLocation(PBCity.MODID, "item/ledger_body");

    private static final int INK = 0xFF23306B, INK2 = 0xFF1E1C16;
    private static final String[] UNIT_NAMES = {"m/s", "kmh", "mph", "kt"};
    private static final double[] UF = {1.0, 3.6, 2.23694, 1.94384};

    private static long cacheTick = -1;
    private static double cacheDist = 300;

    public DeviceRenderer(BlockEntityRenderDispatcher d, EntityModelSet m) { super(d, m); }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf,
                             int light, int overlay) {
        if (stack.getItem() instanceof RangefinderItem) rangefinder(stack, ctx, ps, buf, light, overlay);
        else if (stack.getItem() instanceof WindMeterItem) windMeter(stack, ctx, ps, buf, light, overlay);
        else if (stack.getItem() instanceof LedgerItem) ledger(stack, ctx, ps, buf, light, overlay);
    }

    /** The outer renderer already moved us by -0.5; undo that so the baked model lands where it was authored. */
    private static void model(ResourceLocation rl, ItemStack stack, ItemDisplayContext ctx, PoseStack ps,
                              MultiBufferSource buf, int light, int overlay) {
        Minecraft mc = Minecraft.getInstance();
        BakedModel m = mc.getModelManager().getModel(rl);
        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        mc.getItemRenderer().render(stack, ctx, false, ps, buf, light, overlay, m);
        ps.popPose();
    }

    private static void lcd(PoseStack ps, MultiBufferSource buf, String s, float xPx, float yTopPx, float zPx,
                            float k, int color) {
        Font f = Minecraft.getInstance().font;
        ps.pushPose();
        ps.translate(xPx / 16f, yTopPx / 16f, zPx / 16f);
        ps.scale(k / 16f, -k / 16f, k / 16f);
        f.drawInBatch(s, 0f, 0f, color, false, ps.last().pose(), buf, Font.DisplayMode.NORMAL, 0,
                LightTexture.FULL_BRIGHT);
        ps.popPose();
    }

    private static float fit(String s, float maxPx, float kMax) {
        int w = Math.max(1, Minecraft.getInstance().font.width(s));
        return Math.min(kMax, maxPx / w);
    }

    // ---- rangefinder -----------------------------------------------------------------------------
    private void rangefinder(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf,
                             int light, int overlay) {
        Minecraft mc = Minecraft.getInstance();
        model(RF_BODY, stack, ctx, ps, buf, light, overlay);

        CompoundTag t = stack.getTag();
        boolean laser = t != null && mc.level != null && t.getLong("laser") > mc.level.getGameTime();
        double sec = System.currentTimeMillis() / 1000.0;
        float angle = (float) (sec * (laser ? 14.0 : 1.2));
        ps.pushPose();
        ps.translate(8 / 16f, 16.15f / 16f, 8.5f / 16f);
        ps.mulPose(Axis.YP.rotation(angle));
        ps.translate(-8 / 16f, -16.15f / 16f, -8.5f / 16f);
        model(RF_RING, stack, ctx, ps, buf, light, overlay);
        ps.popPose();

        int mode = t == null ? 0 : t.getInt("mode");
        int n = t == null ? 0 : t.getInt("n");
        String[] names = {"DIST", "SPD", "ANG"};
        String[] units = {"m", "m/s", "deg"};
        float z = 10.03f;
        lcd(ps, buf, names[mode], 5.5f, 14.35f, z, 0.075f, INK);
        lcd(ps, buf, units[mode], 9.3f, 14.35f, z, 0.075f, INK);
        if (n >= 3) lcd(ps, buf, String.format("%.1f", t.getDouble("h0")), 5.6f, 13.5f, z, 0.09f, INK);
        if (n >= 2) lcd(ps, buf, String.format("%.1f", t.getDouble("h1")), 5.6f, 12.6f, z, 0.09f, INK);
        String big = n >= 1 ? String.format("%.1f", t.getDouble("h2")) : "----";
        lcd(ps, buf, big, 5.6f, 11.7f, z, fit(big, 5.0f, 0.2f), INK);
        if (laser) lcd(ps, buf, "*", 9.9f, 10.3f, z, 0.12f, 0xFF1FA64A);
    }

    // ---- ledger: screen shows the lock state, masked PIN or the cold-storage balance ---------------
    private void ledger(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf,
                        int light, int overlay) {
        Minecraft mc = Minecraft.getInstance();
        model(LG_BODY, stack, ctx, ps, buf, light, overlay);
        CompoundTag t = stack.getTag();
        boolean hasPin = t != null && !t.getString("pin").isEmpty();
        boolean open = t != null && mc.level != null && t.getLong("unlock") > mc.level.getGameTime();
        float z = 9.6f;
        int green = 0xFF60FFB0;
        lcd(ps, buf, "LEDGER", 5.9f, 12.6f, z, 0.085f, green);
        if (!hasPin) {
            lcd(ps, buf, "SET PIN", 5.9f, 11.4f, z, 0.09f, 0xFFFFFFFF);
        } else if (open) {
            lcd(ps, buf, "BIT", 5.9f, 11.4f, z, 0.09f, green);
            String bal = String.format("%.4f", t.getDouble("bit"));
            lcd(ps, buf, bal, 5.9f, 10.3f, z, fit(bal, 4.1f, 0.11f), 0xFFFFFFFF);
        } else {
            lcd(ps, buf, "PIN", 5.9f, 11.4f, z, 0.09f, green);
            lcd(ps, buf, "* * * *", 5.9f, 10.3f, z, 0.11f, 0xFFFFFFFF);
        }
    }

    // ---- wind meter ------------------------------------------------------------------------------
    private static String compass(double deg) {
        String[] n = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        return n[(int) Math.floorMod(Math.round(deg / 45.0), 8L)];
    }

    private void windMeter(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf,
                           int light, int overlay) {
        Minecraft mc = Minecraft.getInstance();
        model(WM_BODY, stack, ctx, ps, buf, light, overlay);
        double wspd = mc.level == null ? 3 : WindManager.wind(mc.level).horizontalDistance();

        double sec = System.currentTimeMillis() / 1000.0;
        float angle = (float) (sec * (2.0 + wspd * 1.5));
        ps.pushPose();
        ps.translate(8 / 16f, 14.5f / 16f, 10.25f / 16f);
        ps.mulPose(Axis.ZP.rotation(angle));
        ps.translate(-8 / 16f, -14.5f / 16f, -10.25f / 16f);
        model(WM_BLADES, stack, ctx, ps, buf, light, overlay);
        ps.popPose();

        CompoundTag t = stack.getTag();
        int page = t == null ? 0 : t.getInt("page");
        int unit = t == null ? 0 : t.getInt("unit");
        String[] l = lines(mc, page, unit, ctx.firstPerson());
        float z = 10.03f;
        float[] y = {11.7f, 10.85f, 10.0f, 9.15f};
        for (int i = 0; i < 4; i++) lcd(ps, buf, l[i], 6.0f, y[i], z, fit(l[i], 4.0f, 0.09f), INK2);
    }

    private static String[] lines(Minecraft mc, int page, int unit, boolean firstPerson) {
        if (mc.level == null || mc.player == null) return new String[]{"--", "", "", ""};
        Vec3 wind = WindManager.wind(mc.level);
        Vec3 look = mc.player.getLookAngle();
        Vec3 lh = new Vec3(look.x, 0, look.z);
        lh = lh.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : lh.normalize();
        Vec3 right = new Vec3(-lh.z, 0, lh.x);
        switch (page) {
            case 0 -> {
                double toward = Math.toDegrees(Math.atan2(wind.x, -wind.z));
                double from = (toward + 180 + 360) % 360;
                return new String[]{String.format("%.1f %s", wind.horizontalDistance() * UF[unit], UNIT_NAMES[unit]),
                        String.format("%s %03.0f", compass(from), from),
                        String.format("X %+.1f", wind.dot(right) * UF[unit]),
                        String.format("H %+.1f", wind.dot(lh) * UF[unit])};
            }
            case 1 -> {
                long tick = mc.level.getGameTime();
                if (firstPerson && tick != cacheTick) {
                    cacheTick = tick;
                    Raycast.Result r = Raycast.measure(mc.player, PBConfig.MAX_RANGE.get());
                    if (r.dist() > 0) cacheDist = r.dist();
                }
                double range = Math.max(10, Math.round(cacheDist / 10.0) * 10.0);
                List<Vec3> pts = Ballistics.trajectory(Vec3.ZERO, lh, range, wind,
                        PBConfig.MUZZLE_VELOCITY.get(), PBConfig.DRAG_K.get());
                Vec3 p = pts.get(pts.size() - 1);
                return new String[]{String.format("R%.0f", range), String.format("D%.2f", -p.y),
                        String.format("W%+.2f", p.dot(right)), String.format("T%.2f", (pts.size() - 1) * Ballistics.DT)};
            }
            case 2 -> {
                float base = mc.level.getBiome(mc.player.blockPosition()).value().getBaseTemperature();
                int hum = mc.level.isThundering() ? 95 : mc.level.isRaining() ? 85 : 45;
                double pres = 1013 - (mc.player.getY() - 64) * 0.12 - (mc.level.isRaining() ? 8 : 0);
                return new String[]{String.format("%.0f C", base * 22.0), hum + " %",
                        String.format("%.0f", pres), String.format("Y %.0f", mc.player.getY())};
            }
            default -> {
                long dt = mc.level.getDayTime();
                long tt = dt % 24000L;
                int h = (int) ((tt / 1000 + 6) % 24), m = (int) ((tt % 1000) * 60 / 1000);
                String w = mc.level.isThundering() ? "STORM" : mc.level.isRaining() ? "RAIN" : "CLEAR";
                return new String[]{String.format("%02d:%02d", h, m), "DAY " + (dt / 24000L), w, ""};
            }
        }
    }
}
