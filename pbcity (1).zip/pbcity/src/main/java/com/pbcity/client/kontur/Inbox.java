package com.pbcity.client.kontur;

import com.pbcity.net.DistrictState;
import java.util.ArrayDeque;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "pbcity", value = Dist.CLIENT)
public final class Inbox {
  public static CompoundTag state = new CompoundTag();

  private record Note(String from, String line, long at) {}

  private static final ArrayDeque<Note> notes = new ArrayDeque<>();
  private static long last;

  public static void receive(DistrictState m) {
    state = m.data();
    if (m.note().isBlank()) return;
    long now = System.currentTimeMillis();
    if (notes.size() > 4) notes.removeFirst();
    notes.addLast(new Note(m.app(), m.note(), now));
    if (notes.size() == 1) last = now;
  }

  @SubscribeEvent
  public static void leave(ClientPlayerNetworkEvent.LoggingOut e) {
    state = new CompoundTag();
    notes.clear();
  }

  @SubscribeEvent
  public static void hud(RenderGuiOverlayEvent.Post e) {
    if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()
        || net.minecraft.client.Minecraft.getInstance().screen != null) return;
    draw(e.getGuiGraphics(), e.getWindow().getGuiScaledWidth(), false);
  }

  public static void draw(GuiGraphics g, int w, boolean tablet) {
    if (notes.isEmpty()) return;
    long now = System.currentTimeMillis();
    if (now - last > 3800) {
      notes.removeFirst();
      last = now;
      if (notes.isEmpty()) return;
    }
    Note n = notes.getFirst();
    float a = Math.min(1, (now - last) / 170f);
    int bw = Math.min(213, w - 12), x = w - bw - 6, y = (int) (5 - (1 - a) * (1 - a) * 42);
    var c = new Canvas(g);
    g.pose().pushPose();
    g.pose().translate(0, 0, 400);
    c.round(x, y + 1, bw, 39, 8, 0x700a1513);
    c.round(x, y, bw, 38, 8, 0xf3243934);
    c.round(x + 7, y + 8, 21, 21, 6, Canvas.LIME);
    c.icon("mail", x + 10, y + 11, 15, Canvas.GREEN);
    c.small(
        (tablet ? "ПЛАНШЕТ" : "ТЕЛЕФОН") + "  /  " + n.from,
        x + 35,
        y + 5,
        bw - 43,
        8,
        Canvas.LIME,
        true);
    c.wrap(n.line, x + 35, y + 17, bw - 42, 8.8f, 9, 2, Canvas.WHITE);
    g.pose().popPose();
  }

  private Inbox() {}
}
