package com.pbcity.npc;

import com.pbcity.econ.PlayerFunds;
import com.pbcity.item.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** A walking, talking city resident. Role decides what the meeting offers. */
public class CityNpc extends PathfinderMob {
  public enum Role {
    CIVILIAN,
    DEALER,
    BUYER
  }

  private static final String[] FIRST = {
    "Марек", "Виктор", "Андрей", "Лукаш", "Дмитрий", "Томаш", "Иван", "Рафал", "Михаил", "Йонас",
    "Анна", "Елена", "Марта", "Ирина", "Катя", "София", "Ольга", "Дарья"
  };
  private static final String[] LAST = {
    "Коваль",
    "Волков",
    "Петраускас",
    "Новак",
    "Соколов",
    "Бранд",
    "Орлов",
    "Зелинский",
    "Марин",
    "Каплан",
    "Мороз",
    "Ленарт",
    "Кузнец",
    "Бондарь"
  };

  private Role role = Role.CIVILIAN;
  private long price; // dealer: asking price; buyer: promised sum (cents)
  private long actual; // buyer: what is really in the envelope
  private static final String[] GOODS = {"Cocaine", "Mephedrone", "Crystals", "Weed"};
  private static final String[] GOODS_RU = {"кокаин", "мефедрон", "кристаллы", "траву"};
  private static final double[] GOODS_MULT = {1.5, 0.9, 1.2, 0.5};
  private int goods;
  private boolean wantsGoods, haggled, done;
  private String markedBy = "";

  public CityNpc(EntityType<CityNpc> type, Level level) {
    super(type, level);
  }

  public static AttributeSupplier.Builder attrs() {
    return Mob.createMobAttributes()
        .add(Attributes.MAX_HEALTH, 20.0)
        .add(Attributes.MOVEMENT_SPEED, 0.25)
        .add(Attributes.FOLLOW_RANGE, 16.0);
  }

  @Override
  protected void registerGoals() {
    goalSelector.addGoal(0, new FloatGoal(this));
    goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6));
    goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6f));
    goalSelector.addGoal(7, new RandomLookAroundGoal(this));
  }

  public void init(Role r, RandomSource rnd) {
    role = r;
    if (r != Role.CIVILIAN) setPersistenceRequired(); // plain civilians despawn when far away
    int voiceFamily = Math.floorMod(getUUID().hashCode(), 4);
    int first = voiceFamily == 1 ? 10 + rnd.nextInt(FIRST.length - 10) : rnd.nextInt(10);
    setCustomName(Component.literal(FIRST[first] + " " + LAST[rnd.nextInt(LAST.length)]));
    goods = rnd.nextInt(GOODS.length);
    price = (3 + rnd.nextInt(18)) * 10_000L; // EUR 300..2000
    price = Math.max(10_000L, Math.round(price * GOODS_MULT[goods] / 1000.0) * 1000L);
    wantsGoods = rnd.nextBoolean();
    actual =
        rnd.nextInt(4) == 0
            ? price * (60 + rnd.nextInt(30)) / 100
            : price; // 25%: envelope is short
  }

  private static final net.minecraft.network.syncher.EntityDataAccessor<Integer> LOOK =
      net.minecraft.network.syncher.SynchedEntityData.defineId(
          CityNpc.class, net.minecraft.network.syncher.EntityDataSerializers.INT);

  @Override
  protected void defineSynchedData() {
    super.defineSynchedData();
    entityData.define(LOOK, -1);
  }

  public int appearance() {
    int v = entityData.get(LOOK);
    return v < 0 ? Math.floorMod(getUUID().hashCode(), 48) : Math.min(v, 48);
  }

  public void setAppearance(int v) {
    entityData.set(LOOK, v);
  }

  @Override
  public void aiStep() {
    super.aiStep();
    if (!level().isClientSide && tickCount % 20 == 0) {
      var t = getPersistentData();
      long until = t.getLong("guestUntil");
      if (until > 0 && level().getGameTime() >= until) {
        discard();
        return;
      }
      if (t.contains("dayStop") && tickCount % 60 == 0) {
        long day = Math.floorMod(level().getDayTime(), 24000);
        var dest = net.minecraft.core.BlockPos.of(t.getLong(day < 11500 ? "dayStop" : "nightStop"));
        restrictTo(dest, 3);
        if (!blockPosition().closerThan(dest, 3))
          getNavigation().moveTo(dest.getX() + .5, dest.getY(), dest.getZ() + .5, .70);
      }
      if (t.hasUUID("districtOwner")) {
        var pos = net.minecraft.core.BlockPos.of(t.getLong("districtStop"));
        if (!blockPosition().closerThan(pos, 2.8))
          getNavigation().moveTo(pos.getX() + .5, pos.getY(), pos.getZ() + .5, .85);
        else getNavigation().stop();
      }
    }
  }

  public Role getRole() {
    return role;
  }

  public String goodsName() {
    return GOODS[goods];
  }

  public String goodsRu() {
    return GOODS_RU[goods];
  }

  public Item goodsItem() {
    return switch (goods) {
      case 0 -> ModItems.COCAINE.get();
      case 1 -> ModItems.MEPHEDRONE.get();
      case 2 -> ModItems.CRYSTALS.get();
      default -> ModItems.WEED.get();
    };
  }

  public long price() {
    return price;
  }

  public long actual() {
    return actual;
  }

  public boolean wantsGoods() {
    return wantsGoods;
  }

  public boolean haggled() {
    return haggled;
  }

  public boolean done() {
    return done;
  }

  public void setDone(boolean d) {
    done = d;
  }

  public void setHaggled(boolean h) {
    haggled = h;
  }

  public boolean marked() {
    return !markedBy.isEmpty();
  }

  public void markFor(String playerUuid) {
    markedBy = playerUuid;
    setPersistenceRequired();
  }

  public void scale(double f) {
    price = Math.round(price * f);
    actual = Math.round(actual * f);
  }

  public String npcName() {
    return getCustomName() != null ? getCustomName().getString() : "Незнакомец";
  }

  public boolean dealOpen() {
    return role != Role.CIVILIAN && !done;
  }

  public String offerInfo() {
    return switch (role) {
      case DEALER -> "Продаёт " + GOODS_RU[goods] + " - " + PlayerFunds.fmt(price);
      case BUYER ->
          wantsGoods
              ? "Покупает " + GOODS_RU[goods] + " - даёт " + PlayerFunds.fmt(price)
              : "Тёмная работа - обещает " + PlayerFunds.fmt(price);
      default -> "";
    };
  }

  @Override
  protected InteractionResult mobInteract(Player p, InteractionHand hand) {
    if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
    if (!level().isClientSide
        && p instanceof ServerPlayer sp
        && !com.pbcity.district.Deliveries.interact(sp, this)) NpcService.greet(sp, this);
    return InteractionResult.sidedSuccess(level().isClientSide);
  }

  @Override
  public void addAdditionalSaveData(CompoundTag t) {
    super.addAdditionalSaveData(t);
    t.putInt("districtLook", entityData.get(LOOK));
    t.putString("role", role.name());
    t.putLong("price", price);
    t.putInt("goods", goods);
    t.putLong("actual", actual);
    t.putBoolean("wantsGoods", wantsGoods);
    t.putBoolean("haggled", haggled);
    t.putBoolean("done", done);
    t.putString("markedBy", markedBy);
  }

  @Override
  public void readAdditionalSaveData(CompoundTag t) {
    super.readAdditionalSaveData(t);
    if (t.contains("districtLook")) setAppearance(t.getInt("districtLook"));
    try {
      role = Role.valueOf(t.getString("role"));
    } catch (IllegalArgumentException e) {
      role = Role.CIVILIAN;
    }
    price = t.getLong("price");
    goods = Math.floorMod(t.getInt("goods"), GOODS.length);
    actual = t.getLong("actual");
    wantsGoods = t.getBoolean("wantsGoods");
    haggled = t.getBoolean("haggled");
    done = t.getBoolean("done");
    markedBy = t.getString("markedBy");
  }
}
