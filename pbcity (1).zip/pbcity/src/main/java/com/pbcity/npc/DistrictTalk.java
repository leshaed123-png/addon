package com.pbcity.npc;

import java.util.*;
import net.minecraft.nbt.CompoundTag;

/**
 * Offline conversations keep the subject of the preceding turn. No key, network or model required.
 */
public final class DistrictTalk {
  private static final String[] TRADES = {
    "рисую таблички для трамвайных остановок",
    "проявляю плёнку в маленькой лаборатории",
    "собираю голоса квартала для радио",
    "вожу первый утренний трамвай",
    "готовлю лапшу в киоске у кольца",
    "чиню старые магнитофоны"
  };
  private static final String[] STORIES = {
    "Лучшую табличку пришлось переделать: ночью буквы сливались с фонарём.",
    "Однажды на пустом кадре проступил целый двор после дождя.",
    "Самый удачный эфир получился из скрипа ворот и утренней переклички птиц.",
    "Первый рейс всегда самый тихий. Одна пассажирка приносит водителю яблоко.",
    "Как-то на открытие пришёл весь двор. Запас стаканчиков кончился до обеда.",
    "В одном плеере я нашёл запись детского хора. Хозяин искал её двадцать лет."
  };

  private static boolean has(String q, String... words) {
    for (String w : words) if (q.contains(w)) return true;
    return false;
  }

  public static String reply(
      String name, int profile, String text, List<String[]> history, boolean raining) {
    String q = text.toLowerCase(Locale.ROOT).replace('ё', 'е');
    int k = Math.floorMod(profile, TRADES.length);
    String prev = "";
    for (int i = history.size() - 1; i >= 0; i--)
      if (history.get(i)[0].equals("assistant")) {
        prev = history.get(i)[1];
        break;
      }
    if (!q.contains("меня") && has(q, "как зовут", "твое имя", "представ"))
      return "Я " + name + ". Мы, кажется, на этой линии ещё не встречались. А тебя как зовут?";
    if (has(q, "меня зовут", "я — ")) {
      int i = q.indexOf("меня зовут");
      String a = i >= 0 ? text.substring(i + 10).trim() : text.substring(3).trim();
      String first = a.replaceAll("[^\\p{L}0-9-]+", " ").trim();
      if (first.isEmpty()) return "Как мне тебя называть?";
      return "Приятно познакомиться, "
          + first.split(" ")[0]
          + ". Я "
          + name.split(" ")[0]
          + ". Что привело тебя в район?";
    }
    if (has(q, "мое имя", "моё имя", "как меня зовут")) {
      for (int i = history.size() - 2; i >= 0; i--) {
        String s = history.get(i)[1];
        int at = s.toLowerCase(Locale.ROOT).indexOf("меня зовут ");
        if (at >= 0) return "Ты представился так: " + s.substring(at + 11).trim() + ". Я запомнил.";
      }
      return "Ты пока не представлялся. Как к тебе обращаться?";
    }
    if (has(q, "работ", "занима", "професс"))
      return "Я " + TRADES[k] + ". Хочешь, расскажу случай со смены?";
    if (has(q, "погод", "дожд", "солнц"))
      return raining
          ? "Слышишь, как по крыше барабанит? Хорошо, что у остановки есть навес."
          : "Сегодня сухо. К вечеру у старого депо свет красивее всего. Ты гуляешь или по делу?";
    if (has(q, "кошел", "ledger", "bybit", "binance", "оплат"))
      return "В сообщениях по доставке отправь свой игровой адрес PB. Тогда награда придёт туда, а"
                 + " не наличными.";
    if (has(q, "еду", "еда", "поесть", "лапш", "кофе"))
      return "В маркете есть лапша мисо и флэт уайт. Я бы взял горячее: дорога до кольца длинная. А"
                 + " ты что любишь?";
    if (has(q, "заказ", "карт", "куда", "дорог", "переул"))
      return "На F7 открой «Узел 09». После принятия карта покажет обе точки доставки. Ты уже"
                 + " выбрал заказ?";
    if (has(q, "привет", "здравств", "добрый"))
      return "Привет! Я "
          + name.split(" ")[0]
          + ". Можем про город поболтать, а можем про мою работу. Что интереснее?";
    if (has(q, "спасибо", "пока", "увидим"))
      return "До встречи на линии! Заглядывай, когда окажешься в нашем квартале.";
    if (has(q, "полици", "штраф", "участ"))
      return "Если есть заявление, в приложении появится статус дела. А точку участка задаёт"
                 + " оператор города.";
    if (has(q, "да", "почему", "расскажи", "дальше", "интерес", "город", "истор", "район", "еще"))
      return prev.contains(STORIES[k])
          ? "А теперь район меняется. Что бы ты здесь оставил как есть — трамваи, двор или старую"
                + " мастерскую?"
          : STORIES[k] + " А у тебя такое случалось?";
    if (prev.contains("любишь"))
      return "Запомню твой выбор. Мне нравится, что у каждого здесь своё любимое место. Часто"
                 + " заходишь в наш квартал?";
    return prev.contains("смены")
        ? STORIES[k]
        : "Ты говоришь: «"
            + text.substring(0, Math.min(42, text.length()))
            + "». А что для тебя в этом главное? Я вот "
            + TRADES[k]
            + ", потому и смотрю на это по-своему.";
  }

  public static String dispatch(String text, CompoundTag j) {
    String q = text.toLowerCase(Locale.ROOT);
    if (has(q, "врем", "когда", "жд"))
      return "Буду принимать посылку с "
          + j.getString("time")
          + ". Не страшно, если подойдёшь чуть позже.";
    if (has(q, "где", "куда", "мест", "точк"))
      return "Встреча: " + j.getString("location") + ". Метка уже на карте; нажми «К получателю».";
    if (has(q, "ден", "оплат", "кошел"))
      return "Отправь адрес кнопкой кошелька в этой переписке. Без адреса расчёт наличными.";
    if (has(q, "привет", "здрав"))
      return "Привет! Я " + j.getString("name") + ". Накладная у меня. Вопрос по месту или оплате?";
    return j.getInt("phase") == 1
        ? "Посылка ещё в точке выдачи. Забери её — я буду на связи. Спросишь про время или адрес?"
        : "Вижу отметку о выдаче. Встретимся у метки, передашь посылку лично.";
  }

  private DistrictTalk() {}
}
