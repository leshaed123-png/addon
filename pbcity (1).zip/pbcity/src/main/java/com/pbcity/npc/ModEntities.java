package com.pbcity.npc;

import com.pbcity.PBCity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PBCity.MODID);
    public static final RegistryObject<EntityType<CityNpc>> CITY_NPC = ENTITIES.register("city_npc",
            () -> EntityType.Builder.of(CityNpc::new, MobCategory.MISC).sized(0.6f, 1.8f)
                    .clientTrackingRange(10).build("city_npc"));
    private ModEntities() {}
}
