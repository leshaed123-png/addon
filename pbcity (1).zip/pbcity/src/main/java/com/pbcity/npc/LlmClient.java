package com.pbcity.npc;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;

/** Minimal OpenAI-compatible chat call. Returns null on any problem so the caller can fall back. */
public final class LlmClient {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    private LlmClient() {}

    public static boolean configured(String url,String key) {
        if(url==null||url.isBlank())return false;if(key!=null&&!key.isBlank())return true;
        try{return java.util.Set.of("localhost","127.0.0.1","[::1]").contains(URI.create(url).getHost());}catch(RuntimeException ignored){return false;}
    }
    public static String chat(String url, String key, String model, String system, List<String[]> history) {
        if (!configured(url,key)) return null;
        try {
            JsonObject root = new JsonObject();
            root.addProperty("model", model);
            root.addProperty("max_tokens", 120);
            JsonArray msgs = new JsonArray();
            JsonObject sys = new JsonObject();
            sys.addProperty("role", "system");
            sys.addProperty("content", system);
            msgs.add(sys);
            for (String[] h : history) {
                JsonObject m = new JsonObject();
                m.addProperty("role", h[0]);
                m.addProperty("content", h[1]);
                msgs.add(m);
            }
            root.add("messages", msgs);
            HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(12))
                    .header("Content-Type", "application/json")
                    ;
            if(key!=null&&!key.isBlank())builder.header("Authorization", "Bearer " + key);
            HttpRequest req=builder.POST(HttpRequest.BodyPublishers.ofString(root.toString()))
                    .build();
            HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() != 200) return null;
            JsonObject j = JsonParser.parseString(res.body()).getAsJsonObject();
            String out = j.getAsJsonArray("choices").get(0).getAsJsonObject()
                    .getAsJsonObject("message").get("content").getAsString().trim();
            return out.isEmpty() ? null : out;
        } catch (Exception e) {
            return null;
        }
    }
}
