package com.pbcity.npc;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.pbcity.PBCity;
import com.pbcity.config.PBConfig;
import com.pbcity.econ.PlayerFunds;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class NpcEvents {
    private static final Random RNG = new Random();

    private NpcEvents() {}

    /** Keeps the streets populated: tops up residents near every player on street level. */
    @SubscribeEvent
    public static void levelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel sl) || sl.dimension() != Level.OVERWORLD) return;
        int min = PBConfig.AUTO_MIN.get();
        if (min <= 0 || sl.getGameTime() % 200 != 0) return;
        for (ServerPlayer p : sl.players()) {
            NpcService.maybeSms(sl, p);
            int near = sl.getEntitiesOfClass(CityNpc.class, p.getBoundingBox().inflate(96)).size();
            int spawned = 0;
            for (int tries = 0; tries < 12 && near + spawned < min && spawned < 4; tries++) {
                double ang = RNG.nextDouble() * Math.PI * 2, dist = 28 + RNG.nextDouble() * 36;
                int x = (int) (p.getX() + Math.cos(ang) * dist), z = (int) (p.getZ() + Math.sin(ang) * dist);
                if (!sl.hasChunkAt(new BlockPos(x, 0, z))) continue;
                BlockPos top = sl.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
                if (Math.abs(top.getY() - p.getY()) > 6) continue;           // street level, not roofs
                BlockPos below = top.below();
                if (!sl.getBlockState(below).isFaceSturdy(sl, below, Direction.UP)
                        || !sl.getFluidState(below).isEmpty() || !sl.getFluidState(top).isEmpty()) continue;
                int roll = RNG.nextInt(100);
                CityNpc.Role role = roll < 70 ? CityNpc.Role.CIVILIAN : roll < 85 ? CityNpc.Role.DEALER : CityNpc.Role.BUYER;
                if (make(sl, role, x + 0.5, top.getY(), z + 0.5) != null) spawned++;
            }
        }
    }

    /** Plain chat: if a resident is in front of the player, they answer in chat. */
    @SubscribeEvent
    public static void onChat(ServerChatEvent e) {
        NpcService.onChat(e.getPlayer(), e.getRawText());
    }

    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        for (String kind : new String[]{"inspect", "haggle", "accept", "refuse"}) {
            e.getDispatcher().register(Commands.literal("npc").then(Commands.literal(kind).executes(c -> {
                NpcService.chatAction(c.getSource().getPlayerOrException(), kind.toUpperCase());
                return 1;
            })));
        }
        e.getDispatcher().register(Commands.literal("pbcity").requires(s -> s.hasPermission(2))
                .then(Commands.literal("spawn").requires(s->s.hasPermission(2)).then(Commands.argument("role", StringArgumentType.word())
                        .executes(c -> spawnAt(c.getSource(), StringArgumentType.getString(c, "role")))))
                .then(Commands.literal("populate").requires(s->s.hasPermission(2)).then(Commands.argument("count", IntegerArgumentType.integer(1, 200))
                        .executes(c -> populate(c.getSource(), IntegerArgumentType.getInteger(c, "count"))))));
    }

    private static CityNpc make(ServerLevel level, CityNpc.Role role, double x, double y, double z) {
        CityNpc n = ModEntities.CITY_NPC.get().create(level);
        if (n == null) return null;
        n.moveTo(x, y, z, RNG.nextFloat() * 360f, 0f);
        n.init(role, level.getRandom());
        level.addFreshEntity(n);
        return n;
    }

    private static int spawnAt(CommandSourceStack src, String roleName) {
        CityNpc.Role role;
        try { role = CityNpc.Role.valueOf(roleName.toUpperCase()); }
        catch (IllegalArgumentException ex) {
            src.sendFailure(Component.literal("Role: civilian | dealer | buyer"));
            return 0;
        }
        make(src.getLevel(), role, src.getPosition().x, src.getPosition().y, src.getPosition().z);
        return 1;
    }

    private static int populate(CommandSourceStack src, int count) {
        ServerLevel level = src.getLevel();
        int made = 0;
        for (int i = 0; i < count; i++) {
            int x = (int) src.getPosition().x + RNG.nextInt(121) - 60;
            int z = (int) src.getPosition().z + RNG.nextInt(121) - 60;
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
            int roll = RNG.nextInt(100);
            CityNpc.Role role = roll < 70 ? CityNpc.Role.CIVILIAN : roll < 85 ? CityNpc.Role.DEALER : CityNpc.Role.BUYER;
            if (make(level, role, top.getX() + 0.5, top.getY(), top.getZ() + 0.5) != null) made++;
        }
        final int total = made;
        src.sendSuccess(() -> Component.literal("Spawned " + total + " residents"), true);
        return made;
    }
}
