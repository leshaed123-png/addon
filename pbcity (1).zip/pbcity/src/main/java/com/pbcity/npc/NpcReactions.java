package com.pbcity.npc;

import com.pbcity.PBCity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Residents comment in chat on what happens around them: attacks and deaths of residents or players. */
@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class NpcReactions {
    private static final Random RNG = new Random();
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();

    private static final String[] HURT_SELF = {"Ай! Ты чего?!", "Эй, больно же!", "Ты с ума сошёл?!", "Не стреляй!"};
    private static final String[] HURT_SEEN = {"Эй! Ты что творишь?!", "Он нападает на людей!", "Кто-нибудь, остановите его!", "Звоните в полицию!"};
    private static final String[] DEATH_SEEN = {"Он убил человека!", "Боже... он его убил!", "Бегите, это убийца!", "Я ничего не видел, я ничего не видел..."};
    private static final String[] PLAYER_DOWN = {"Мужик, ты как? Держись!", "Кого-то подстрелили!", "Человеку плохо, помогите!"};

    private NpcReactions() {}

    private static boolean ready(CityNpc n, long gameTime) {
        long last = COOLDOWN.getOrDefault(n.getUUID(), -1000L);
        if (gameTime - last < 100) return false;   // 5 s per resident
        COOLDOWN.put(n.getUUID(), gameTime);
        return true;
    }

    private static void witnesses(ServerLevel sl, Entity centre, CityNpc exclude, String[] lines, int max) {
        List<CityNpc> list = sl.getEntitiesOfClass(CityNpc.class, centre.getBoundingBox().inflate(24), c -> c != exclude);
        int said = 0;
        for (CityNpc c : list) {
            if (said >= max) break;
            if (RNG.nextInt(100) < 70 && ready(c, sl.getGameTime())) {
                NpcService.say(sl, c, null, lines[RNG.nextInt(lines.length)]);
                said++;
            }
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getEntity().level() instanceof ServerLevel sl)) return;
        if (!(e.getEntity() instanceof CityNpc victim) || !(e.getSource().getEntity() instanceof Player)) return;
        ServerPlayer target = e.getSource().getEntity() instanceof ServerPlayer sp ? sp : null;
        if (ready(victim, sl.getGameTime())) NpcService.say(sl, victim, target, HURT_SELF[RNG.nextInt(HURT_SELF.length)]);
        witnesses(sl, victim, victim, HURT_SEEN, 2);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getEntity().level() instanceof ServerLevel sl)) return;
        if (e.getEntity() instanceof CityNpc victim) {
            witnesses(sl, victim, victim, DEATH_SEEN, 3);
        } else if (e.getEntity() instanceof Player pl) {
            witnesses(sl, pl, null, PLAYER_DOWN, 2);
        }
    }
}
