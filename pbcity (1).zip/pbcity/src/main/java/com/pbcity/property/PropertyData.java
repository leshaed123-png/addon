package com.pbcity.property;

import com.pbcity.econ.PlayerFunds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** World-saved ownership of properties, plus income that accumulates while the owner is offline. */
public class PropertyData extends SavedData {
    public static final class Prop {
        public PropertyType type;
        public long price;
        public UUID owner;
        public String ownerName = "";
        public long lastDay;
    }

    private final Map<Long, Prop> props = new LinkedHashMap<>();
    private final Map<UUID, Long> pending = new HashMap<>();

    public static PropertyData get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(PropertyData::load, PropertyData::new, "pbcity_properties");
    }

    public static PropertyData load(CompoundTag t) {
        PropertyData d = new PropertyData();
        ListTag l = t.getList("props", 10);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            Prop p = new Prop();
            try { p.type = PropertyType.valueOf(c.getString("type")); } catch (IllegalArgumentException e) { continue; }
            p.price = c.getLong("price");
            String o = c.getString("owner");
            p.owner = o.isEmpty() ? null : UUID.fromString(o);
            p.ownerName = c.getString("ownerName");
            p.lastDay = c.getLong("lastDay");
            d.props.put(c.getLong("pos"), p);
        }
        ListTag pl = t.getList("pending", 10);
        for (int i = 0; i < pl.size(); i++) {
            CompoundTag c = pl.getCompound(i);
            d.pending.put(UUID.fromString(c.getString("id")), c.getLong("v"));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        ListTag l = new ListTag();
        for (Map.Entry<Long, Prop> e : props.entrySet()) {
            CompoundTag c = new CompoundTag();
            Prop p = e.getValue();
            c.putLong("pos", e.getKey());
            c.putString("type", p.type.name());
            c.putLong("price", p.price);
            c.putString("owner", p.owner == null ? "" : p.owner.toString());
            c.putString("ownerName", p.ownerName);
            c.putLong("lastDay", p.lastDay);
            l.add(c);
        }
        t.put("props", l);
        ListTag pl = new ListTag();
        for (Map.Entry<UUID, Long> e : pending.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putString("id", e.getKey().toString());
            c.putLong("v", e.getValue());
            pl.add(c);
        }
        t.put("pending", pl);
        return t;
    }

    public void register(BlockPos pos, PropertyType type, long price) {
        Prop p = new Prop();
        p.type = type;
        p.price = price;
        props.put(pos.asLong(), p);
        setDirty();
    }

    public Prop at(BlockPos pos) { return props.get(pos.asLong()); }

    /** Sign broken: the property disappears; an owner is refunded the full price into pending income. */
    public void remove(BlockPos pos) {
        Prop p = props.remove(pos.asLong());
        if (p != null && p.owner != null) pending.merge(p.owner, p.price, Long::sum);
        setDirty();
    }

    public String buy(ServerPlayer pl, BlockPos pos, long day) {
        Prop p = at(pos);
        if (p == null) return "Not for sale";
        if (p.owner != null) return "Already owned by " + p.ownerName;
        if (PlayerFunds.bank(pl) < p.price) return "Not enough in your bank: need " + PlayerFunds.fmt(p.price);
        PlayerFunds.setBank(pl, PlayerFunds.bank(pl) - p.price);
        p.owner = pl.getUUID();
        p.ownerName = pl.getGameProfile().getName();
        p.lastDay = day;
        setDirty();
        return "You bought the " + p.type.label + " for " + PlayerFunds.fmt(p.price);
    }

    /** Sell back for 80% of the price. */
    public String sell(ServerPlayer pl, long key) {
        Prop p = props.get(key);
        if (p == null || p.owner == null || !p.owner.equals(pl.getUUID())) return "You don't own that";
        long refund = p.price * 8 / 10;
        PlayerFunds.setBank(pl, PlayerFunds.bank(pl) + refund);
        p.owner = null;
        p.ownerName = "";
        setDirty();
        return "Sold the " + p.type.label + " for " + PlayerFunds.fmt(refund);
    }

    public List<Map.Entry<Long, Prop>> owned(UUID id) {
        List<Map.Entry<Long, Prop>> out = new ArrayList<>();
        for (Map.Entry<Long, Prop> e : props.entrySet())
            if (id.equals(e.getValue().owner)) out.add(e);
        out.sort(Comparator.comparingLong(Map.Entry::getKey));
        return out;
    }

    /** Credit one daily income step per game day passed (max 20 catch-up days). */
    public void tick(long day) {
        boolean changed = false;
        for (Prop p : props.values()) {
            if (p.owner == null) continue;
            int guard = 0;
            while (p.lastDay < day && guard++ < 20) {
                if (p.type.income > 0) pending.merge(p.owner, p.type.income, Long::sum);
                p.lastDay++;
                changed = true;
            }
        }
        if (changed) setDirty();
    }

    public long claim(ServerPlayer pl) {
        Long v = pending.remove(pl.getUUID());
        if (v == null || v <= 0) return 0;
        PlayerFunds.setBank(pl, PlayerFunds.bank(pl) + v);
        setDirty();
        return v;
    }

    public String estateString(ServerPlayer pl) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Long, Prop> e : owned(pl.getUUID())) {
            BlockPos pos = BlockPos.of(e.getKey());
            if (sb.length() > 0) sb.append(';');
            sb.append(e.getValue().type.label).append('|').append(pos.getX()).append(',').append(pos.getY())
                    .append(',').append(pos.getZ()).append('|').append(e.getValue().type.income)
                    .append('|').append(e.getValue().price);
            if (sb.length() > 330) break;
        }
        return sb.toString();
    }
}
