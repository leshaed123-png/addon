package com.pbcity.property;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.pbcity.PBCity;
import com.pbcity.block.ModBlocks;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Arrays;

@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PropertyEvents {
    private PropertyEvents() {}

    @SubscribeEvent
    public static void tick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel sl)
                || sl.dimension() != Level.OVERWORLD || sl.getGameTime() % 200 != 0) return;
        PropertyData.get(sl.getServer()).tick(sl.getDayTime() / 24000L);
    }

    /** /pbcity property <house|apartment|gun_shop|ammo_shop|business|garage> [price in euro] */
    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("pbcity").requires(s -> s.hasPermission(2))
                .then(Commands.literal("property").then(Commands.argument("type", StringArgumentType.word())
                        .executes(c -> create(c.getSource(), StringArgumentType.getString(c, "type"), -1))
                        .then(Commands.argument("price", IntegerArgumentType.integer(1000, 1_000_000_000))
                                .executes(c -> create(c.getSource(), StringArgumentType.getString(c, "type"),
                                        IntegerArgumentType.getInteger(c, "price")))))));
    }

    private static int create(CommandSourceStack src, String t, long euros) throws CommandSyntaxException {
        PropertyType type = PropertyType.parse(t);
        if (type == null) {
            src.sendFailure(Component.literal("Types: " + Arrays.toString(PropertyType.values()).toLowerCase()));
            return 0;
        }
        ServerPlayer p = src.getPlayerOrException();
        ServerLevel sl = src.getLevel();
        BlockPos pos = p.blockPosition();
        sl.setBlock(pos, ModBlocks.PROPERTY_SIGN.get().defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, p.getDirection().getOpposite()), 3);
        long price = euros > 0 ? euros * 100 : type.price;
        PropertyData.get(src.getServer()).register(pos, type, price);
        src.sendSuccess(() -> Component.literal("Registered " + type.label + " sign here"), true);
        return 1;
    }
}
