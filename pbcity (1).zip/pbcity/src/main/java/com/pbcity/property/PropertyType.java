package com.pbcity.property;

/** Things a player can own. Prices and daily income are in euro cents. */
public enum PropertyType {
    HOUSE("House", 8_000_000L, 0L),
    APARTMENT("Apartment", 3_500_000L, 0L),
    GUN_SHOP("Gun shop", 25_000_000L, 400_000L),
    AMMO_SHOP("Ammo shop", 12_000_000L, 200_000L),
    BUSINESS("Nightclub", 40_000_000L, 700_000L),
    GARAGE("Garage", 6_000_000L, 50_000L);

    public final String label;
    public final long price, income;

    PropertyType(String label, long price, long income) {
        this.label = label;
        this.price = price;
        this.income = income;
    }

    public static PropertyType parse(String s) {
        try { return valueOf(s.toUpperCase()); } catch (IllegalArgumentException e) { return null; }
    }
}
