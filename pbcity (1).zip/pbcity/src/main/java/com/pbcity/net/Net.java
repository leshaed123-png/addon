package com.pbcity.net;

import com.pbcity.PBCity;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
  private static final String VERSION = "2";
  public static final SimpleChannel CH =
      NetworkRegistry.newSimpleChannel(
          new ResourceLocation(PBCity.MODID, "main"),
          () -> VERSION,
          VERSION::equals,
          VERSION::equals);
  private static boolean done;

  private Net() {}

  public static synchronized void init() {
    if (done) return;
    done = true;
    int i = 0;
    CH.registerMessage(
        i++,
        ActionPacket.class,
        ActionPacket::encode,
        ActionPacket::decode,
        ActionPacket::handle,
        java.util.Optional.of(net.minecraftforge.network.NetworkDirection.PLAY_TO_SERVER));
    CH.registerMessage(
        i++,
        StatePacket.class,
        StatePacket::encode,
        StatePacket::decode,
        StatePacket::handle,
        java.util.Optional.of(net.minecraftforge.network.NetworkDirection.PLAY_TO_CLIENT));
    CH.registerMessage(
        i++,
        DistrictRequest.class,
        DistrictRequest::encode,
        DistrictRequest::decode,
        DistrictRequest::handle,
        java.util.Optional.of(net.minecraftforge.network.NetworkDirection.PLAY_TO_SERVER));
    CH.registerMessage(
        i++,
        DistrictState.class,
        DistrictState::encode,
        DistrictState::decode,
        DistrictState::handle,
        java.util.Optional.of(net.minecraftforge.network.NetworkDirection.PLAY_TO_CLIENT));
  }
}
