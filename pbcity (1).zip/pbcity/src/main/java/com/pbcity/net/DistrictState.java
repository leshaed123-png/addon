package com.pbcity.net;

import com.pbcity.client.kontur.Inbox;
import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Bounded server-built public view. Never forwards the player's persistent tag (or Ledger PINs).
 */
public record DistrictState(CompoundTag data, String app, String note) {
  public static void encode(DistrictState p, FriendlyByteBuf b) {
    b.writeNbt(p.data);
    b.writeUtf(p.app, 48);
    b.writeUtf(p.note, 240);
  }

  public static DistrictState decode(FriendlyByteBuf b) {
    var t = b.readNbt();
    return new DistrictState(t == null ? new CompoundTag() : t, b.readUtf(48), b.readUtf(240));
  }

  public static void handle(DistrictState p, Supplier<NetworkEvent.Context> s) {
    var c = s.get();
    c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> Inbox.receive(p)));
    c.setPacketHandled(true);
  }
}
