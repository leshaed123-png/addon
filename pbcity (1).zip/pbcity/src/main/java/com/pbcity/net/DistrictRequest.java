package com.pbcity.net;

import com.pbcity.district.District;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/**
 * A verb, a short selection token and an optional integer. Never accepts balances or world
 * positions.
 */
public record DistrictRequest(String op, String text, long value) {
  public static void encode(DistrictRequest p, FriendlyByteBuf b) {
    b.writeUtf(p.op, 24);
    b.writeUtf(p.text, 120);
    b.writeLong(p.value);
  }

  public static DistrictRequest decode(FriendlyByteBuf b) {
    return new DistrictRequest(b.readUtf(24), b.readUtf(120), b.readLong());
  }

  public static void handle(DistrictRequest p, Supplier<NetworkEvent.Context> s) {
    var c = s.get();
    c.enqueueWork(
        () -> {
          var player = c.getSender();
          if (player != null) District.handle(player, p);
        });
    c.setPacketHandled(true);
  }
}
