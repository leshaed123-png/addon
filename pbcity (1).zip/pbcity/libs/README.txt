Point Blank jar is NOT needed to compile (the mixin targets it by name) and must not be committed.
Put pointblank-forge-1_20_1-2_2_0.jar into the mods/ folder of your Minecraft instance next to the built pbcity jar.
