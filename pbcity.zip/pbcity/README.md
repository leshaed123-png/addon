# PB City (Forge 1.20.1, addon for Point Blank 2.2.0)

Slice 1: simulated bullet path (gravity, drag, wind) for Point Blank hitscan, rangefinder, wind meter.
Slice 2: phone (Up arrow), bank, wallet, casino, hidden mode (tap Build number x5 in Settings), orders board.
Slice 3: city residents (spawn egg, /pbcity spawn <civilian|dealer|buyer>, /pbcity populate <n>),
         AI dialogue in normal chat (look at a resident, type; or right-click for the panel; /npc inspect|haggle|accept|refuse; config npc.llmKey, scripted fallback), meetings with envelope/package, haggling,
         job with a marked target and bonus.

Build: push to GitHub -> Actions -> `build` -> artifact `pbcity-jar`.
Install: pbcity jar + Point Blank 2.2.0 in `mods/`. Config: `config/pbcity-common.toml`.

Slice 4: Net app (memory-code hack -> 10 min DarkNet), Black shop (Point Blank guns/ammo), Orders need DarkNet,
         Bit (simulated crypto), Market (sell hand item to bots, haggle), Cash (odd jobs), ATM block,
         street auto-spawn of residents near players (config npc.autoMinNearPlayer).
Map: Pervomaysk is a 1.20.1 world save (~1600x1500 blocks). Put the folder into saves/ and play in it with the mods installed.

Models: rangefinder, wind meter, envelope, package and ATM are real 3D box models built in Blender (collection PBCity_Models) and exported as Minecraft JSON on one shared 16-colour palette texture.

Slice 5: rangefinder and wind meter now match real devices (DIST-50 style laser meter, Kestrel style wind meter) and open a
         device screen on right-click with working buttons. Trade goods: cocaine, mephedrone, crystals, weed (bag items used
         only as in-game trade goods). Casino slots, three job types. Palette texture is now 64x64.

Slice 6 (this build):
- Bullet physics FIXED: Point Blank only searches for entities near the shooter, so every ray segment after the first
  never found NPCs/players. The mixin now scans entities per segment itself.
- NPCs talk ONLY in the normal chat, in Russian: write their name (from any distance), call them from the phone, or look at them.
  They react to attacks/deaths, text you first (SMS), and the dialogue window is gone.
- Phone opens on a Face ID lock screen with the Light / Dark switch; new Contacts app (calls); Russian UI.
- Rangefinder / wind meter have NO GUI: the readout is drawn on the 3D model's LCD, the impeller spins with the wind,
  the rangefinder fires a green laser beam. Right-click = measure / next page, Shift + right-click = mode / unit.
- Goods can be used (right-click): short game effects, 3 uses in 2 minutes = overdose.
- DarkNet shop has 40 entries (guns, ammo, gear).

Ledger: cold wallet item with a PIN and an LCD on the 3D model. /ledger setpin|unlock|lock|deposit|withdraw. Dying costs 30% cash and 20% phone BIT; Ledger coins are safe. Sold in the DarkNet shop (41 entries).

Slice 8: phone redesign (wallpaper home screen with balance widget and dock, soft shadows, gradient buttons with hover,
fade-in pages), new apps Weather / Maps (compass + distance to your properties) / Calculator, casino dice, six odd jobs,
rounder Kestrel-style wind meter (checked in Blender).

Slice 9:
- Admin (op level 2): `/pbcity admin money|cash <player> <euros>`, `/pbcity admin unlimited <player> true|false`,
  `/pbcity admin setjail`, `/pbcity admin pardon <player>`, `/pbcity admin status <player>`.
- Dirty money: envelope cash, contract bonuses and robbery loot are "dirty". Launder it: Bybit -> "Отмыть" (cash -> crypto, 3% fee),
  then sell the coins to your bank. Depositing dirty cash straight into the bank is traced. Sleeping with dirty/traced money = police raid at dawn.
- Police (event based): murder / armed robbery with witnesses = wanted; get 150+ blocks away within 60 s or be arrested.
  Rob a resident: Shift + right click with a Point Blank gun. Arrest = dirty cash confiscated, 10% bank fine, jail (/pbcity admin setjail).
- Groceries app "Еда" (legal marketplace with item pictures, 14 products incl. instant noodles).
- 24 generated resident skins (no Steve), Bybit naming.
- Voice (needs Simple Voice Chat on the server): your microphone -> `voice.sttUrl` (POST audio/wav, JSON {"text"}) -> NPC dialogue;
  NPC lines -> `voice.ttsUrl` (POST JSON {"text","voice","lang"} -> wav) played positionally; each NPC has a fixed voice id and pitch.
  Both services are external (e.g. a local Whisper / Piper / Silero server); empty URL = feature off.

Auto-spawn is OFF by default (npc.autoMinNearPlayer = 0). Place residents yourself: spawn egg "Яйцо призыва: житель города", `/pbcity spawn civilian|dealer|buyer` (at your feet), `/pbcity populate <n>` (n random residents within 60 blocks).
