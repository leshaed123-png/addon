# PB City (Forge 1.20.1, addon for Point Blank 2.2.0)

Slice 1: simulated bullet path (gravity, drag, wind) for Point Blank hitscan, rangefinder, wind meter.
Slice 2: phone (Up arrow), bank, wallet, casino, hidden mode (tap Build number x5 in Settings), orders board.
Slice 3: city residents (spawn egg, /pbcity spawn <civilian|dealer|buyer>, /pbcity populate <n>),
         AI dialogue in normal chat (look at a resident, type; or right-click for the panel; /npc inspect|haggle|accept|refuse; config npc.llmKey, scripted fallback), meetings with envelope/package, haggling,
         job with a marked target and bonus.

Build: push to GitHub -> Actions -> `build` -> artifact `pbcity-jar`.
Install: pbcity jar + Point Blank 2.2.0 in `mods/`. Config: `config/pbcity-common.toml`.

Slice 4: Net app (memory-code hack -> 10 min DarkNet), Black shop (Point Blank guns/ammo), Orders need DarkNet,
         Bit (simulated crypto), Market (sell hand item to bots, haggle), Cash (odd jobs), ATM block,
         street auto-spawn of residents near players (config npc.autoMinNearPlayer).
Map: Pervomaysk is a 1.20.1 world save (~1600x1500 blocks). Put the folder into saves/ and play in it with the mods installed.

Models: rangefinder, wind meter, envelope, package and ATM are real 3D box models built in Blender (collection PBCity_Models) and exported as Minecraft JSON on one shared 16-colour palette texture.

Slice 5: rangefinder and wind meter now match real devices (DIST-50 style laser meter, Kestrel style wind meter) and open a
         device screen on right-click with working buttons. Trade goods: cocaine, mephedrone, crystals, weed (bag items used
         only as in-game trade goods). Casino slots, three job types. Palette texture is now 64x64.
