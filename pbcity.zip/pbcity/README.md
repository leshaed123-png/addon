# PB City: Ballistics (Forge 1.20.1, addon for Point Blank 2.2.0)

Slice 1: simulated bullet path (gravity, drag, wind) for Point Blank hitscan, laser rangefinder, wind meter.

Build: push to GitHub -> Actions -> `build` -> artifact `pbcity-jar`.
Install: `pbcity-0.1.0.jar` + Point Blank 2.2.0 in `mods/`.
Config: `config/pbcity-common.toml` (muzzle velocity, drag, wind).
