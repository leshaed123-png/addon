package com.pbcity.client;

import com.pbcity.net.Net;
import com.pbcity.net.NpcReplyPacket;
import com.pbcity.net.NpcSayPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/** Dialogue panel at the bottom of the screen: log, free-text input, and deal buttons when an offer is open. */
public class NpcDialogueScreen extends Screen {
    private record Hit(int x, int y, int w, int h, Runnable r) {}

    public final int npcId;
    private final String name;
    private final List<String[]> log = new ArrayList<>(); // {who, text}
    private String info = "";
    private int dealState;
    private boolean waiting;
    private EditBox box;
    private final List<Hit> hits = new ArrayList<>();

    public NpcDialogueScreen(int npcId, String name) {
        super(Component.literal(name));
        this.npcId = npcId;
        this.name = name;
    }

    public void onReply(NpcReplyPacket m) {
        log.add(new String[]{name, m.line()});
        info = m.info();
        dealState = m.dealState();
        waiting = false;
    }

    @Override public boolean isPauseScreen() { return false; }

    private int pw() { return Math.min(380, width - 20); }
    private int px() { return (width - pw()) / 2; }
    private int ph() { return 150; }
    private int py() { return height - ph() - 10; }

    @Override
    protected void init() {
        box = new EditBox(font, px() + 12, py() + ph() - 20, pw() - 24, 12, Component.literal(""));
        box.setMaxLength(120);
        box.setBordered(false);
        addRenderableWidget(box);
        setInitialFocus(box);
    }

    private void act(String kind, String text) {
        Net.CH.sendToServer(new NpcSayPacket(npcId, kind, text));
    }

    private void say() {
        String t = box.getValue().trim();
        if (t.isEmpty() || waiting) return;
        log.add(new String[]{"You", t});
        box.setValue("");
        waiting = true;
        act("SAY", t);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 257 || key == 335) { say(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Hit h : hits) {
            if (mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h) { h.r.run(); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    private void btn(GuiGraphics g, int x, int y, int w, String label, int fill, Runnable r) {
        Gfx.rr(g, x, y, w, 14, 6, fill);
        Gfx.text(g, font, label, x + w / 2, y + 3, 0xFFFFFFFF, 0.9f, true);
        hits.add(new Hit(x, y, w, 14, r));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        hits.clear();
        int x = px(), y = py(), w = pw(), h = ph();
        Gfx.rr(g, x - 1, y - 1, w + 2, h + 2, 10, 0xFF2C3138);
        Gfx.rr(g, x, y, w, h, 10, 0xEE101216);
        g.fill(x + 8, y + 6, x + 10, y + 18, 0xFFFFB84D);
        Gfx.text(g, font, name, x + 14, y + 8, 0xFFE8EAED, 1.1f, false);
        Gfx.text(g, font, "[Esc] close", x + w - 8 - font.width("[Esc] close") * 0.7f > 0 ? x + w - 60 : x + w - 60,
                y + 9, 0xFF8A93A0, 0.7f, false);

        int top = y + 24, bottom = y + h - 54;
        List<FormattedCharSequence> lines = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        for (String[] e : log) {
            int col = e[0].equals("You") ? 0xFF7BD88F : 0xFFE8EAED;
            for (FormattedCharSequence l : font.split(Component.literal(e[0] + ": " + e[1]), w - 24)) {
                lines.add(l);
                colors.add(col);
            }
        }
        if (waiting) { lines.add(Component.literal("...").getVisualOrderText()); colors.add(0xFF8A93A0); }
        int maxLines = (bottom - top) / 10;
        int from = Math.max(0, lines.size() - maxLines);
        for (int i = from; i < lines.size(); i++)
            g.drawString(font, lines.get(i), x + 12, top + (i - from) * 10, colors.get(i), false);

        if (dealState == 1) {
            Gfx.text(g, font, info, x + 12, y + h - 48, 0xFFFFB84D, 0.85f, false);
            int bx = x + 12, by = y + h - 36;
            btn(g, bx, by, 56, "Inspect", 0xFF3A3F47, () -> act("INSPECT", ""));
            btn(g, bx + 60, by, 50, "Haggle", 0xFF3A3F47, () -> act("HAGGLE", ""));
            btn(g, bx + 114, by, 50, "Accept", 0xFF1F7A3F, () -> act("ACCEPT", ""));
            btn(g, bx + 168, by, 50, "Refuse", 0xFF8B0000, () -> act("REFUSE", ""));
        }
        g.fill(x + 8, y + h - 24, x + w - 8, y + h - 8, 0xFF1A1D22);
        if (box.getValue().isEmpty())
            Gfx.text(g, font, "Say something and press Enter...", x + 12, y + h - 20, 0xFF5A616B, 0.85f, false);
        super.render(g, mx, my, pt);
    }
}
