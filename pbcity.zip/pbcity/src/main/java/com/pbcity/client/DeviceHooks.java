package com.pbcity.client;

import net.minecraft.client.Minecraft;

/** Entry points called from items on the client side only. */
public final class DeviceHooks {
    private DeviceHooks() {}

    public static void openRangefinder() { Minecraft.getInstance().setScreen(new RangefinderScreen()); }

    public static void openWindMeter() { Minecraft.getInstance().setScreen(new WindMeterScreen()); }
}
