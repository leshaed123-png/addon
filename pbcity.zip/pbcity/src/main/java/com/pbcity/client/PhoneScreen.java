package com.pbcity.client;

import com.mojang.math.Axis;
import com.pbcity.ballistics.WindManager;
import com.pbcity.econ.BitMarket;
import com.pbcity.econ.PlayerFunds;
import com.pbcity.econ.Shop;
import com.pbcity.net.ActionPacket;
import com.pbcity.net.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Phone UI drawn in local coordinates 0..150 x 0..290, scaled to fit, sliding up from the bottom-right corner.
 * Opens on a Face ID lock screen with the Light / Dark switch. Home screen: wallpaper, balance widget, app grid and a
 * dock. Light mode = everyday apps; Dark mode = DarkNet apps (hack a network in "Сеть" to open the DarkNet).
 */
public class PhoneScreen extends Screen {
    private enum Page { LOCK, HOME, BANK, WALLET, CASINO, SETTINGS, CONTRACTS, NET, BLACK, BIT, MARKET, JOBS, ESTATE,
        CONTACTS, WEATHER, MAPS, CALC }
    private record Hit(int x, int y, int w, int h, Runnable r) {}
    private record App(String name, String glyph, int color, Page page) {}

    private static final int W = 150, H = 290;
    private static final int BURGUNDY = 0xFF6B1230, RIM = 0xFF8C2A4A, ACCENT = 0xFF9B1B3C,
            GREEN = 0xFF30D158, BLUE = 0xFF0A84FF, GREY = 0xFF8E8E93, ORANGE = 0xFFFF9F0A;
    private static final long[] CHIPS = {5_000, 10_000, 50_000, 100_000};
    private static final String[] NETS = {"HomeNet_4F2A", "CafeGuest", "CityHall-Staff"};
    private static final String[] DAYS = {"понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"};
    private static final String[] MONTHS = {"января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа",
            "сентября", "октября", "ноября", "декабря"};
    private static final int PER_PAGE = 5;
    private static final long SCAN_START = 500, SCAN_END = 1700, UNLOCK_AT = 2150, FADE_MS = 200;

    private static boolean lastDark;

    private Page page = Page.LOCK;
    private boolean hidden = lastDark;
    private int chip = 1, tab, pollTick, shopPage;
    private long hackSeen, hackShownAt;
    private final StringBuilder entered = new StringBuilder();
    private final long openedAt = System.currentTimeMillis();
    private long lockAt = openedAt, pageSince = openedAt;
    private final List<Hit> hits = new ArrayList<>();
    private float scale = 1f;
    private int ox, oy;
    private double mlx = -1, mly = -1;

    // calculator
    private String calcDisplay = "0";
    private double calcAcc;
    private char calcOp;
    private boolean calcFresh = true;

    public PhoneScreen() { super(Component.literal("Phone")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() { send("SYNC", 0, 0); }

    private void send(String a, long amt, int arg) { Net.CH.sendToServer(new ActionPacket(a, amt, arg)); }

    private void setDark(boolean dark) {
        hidden = dark;
        lastDark = dark;
    }

    @Override
    public void tick() {
        if (page == Page.CASINO && tab == 1 && ClientState.crashStatus == 1 && ++pollTick % 4 == 0)
            send("CRASH_POLL", 0, 0);
        if (page == Page.JOBS && ClientState.job.startsWith("work") && ++pollTick % 20 == 0) send("SYNC", 0, 0);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (PhoneKeys.OPEN.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        double lx = (mx - ox) / scale, ly = (my - oy) / scale;
        for (Hit h : hits) {
            if (lx >= h.x && lx < h.x + h.w && ly >= h.y && ly < h.y + h.h) { h.r.run(); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        hits.clear();
        double t = Math.min(1.0, (System.currentTimeMillis() - openedAt) / 260.0);
        double e = 1 - Math.pow(1 - t, 3);
        scale = Math.min(1f, (height - 10) / (float) H);
        ox = width - (int) (W * scale) - 10;
        int baseY = height - (int) (H * scale) - 5;
        oy = baseY + (int) ((1 - e) * (H * scale + 10));
        mlx = (mx - ox) / scale;
        mly = (my - oy) / scale;
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(scale, scale, 1f);
        draw(g);
        g.pose().popPose();
    }

    // ---- colours -------------------------------------------------------------------------------
    private int bg() { return hidden ? 0xFF0A0A0E : 0xFFF2F2F7; }
    private int card() { return hidden ? 0xFF1C1C21 : 0xFFFFFFFF; }
    private int ink() { return hidden ? 0xFFF2F2F7 : 0xFF111114; }
    private int sub() { return hidden ? 0xFF8E8E93 : 0xFF6E6E73; }
    private int line() { return hidden ? 0xFF2C2C31 : 0xFFD8D8DE; }

    private void wallpaper(GuiGraphics g, int top, int bottom) {
        Gfx.rr(g, 5, 5, 140, 40, 18, top);
        for (int y = 24; y < 252; y += 2) g.fill(5, y, 145, y + 2, Gfx.lerp(top, bottom, (y - 24) / 228f));
        Gfx.rr(g, 5, 250, 140, 35, 18, bottom);
    }

    private void draw(GuiGraphics g) {
        boolean lock = page == Page.LOCK, home = page == Page.HOME;
        Gfx.rr(g, -1, -1, W + 2, H + 2, 24, RIM);
        Gfx.gradRr(g, 0, 0, W, H, 23, 0xFF86203F, BURGUNDY);
        if (lock) lock(g);
        else if (home) wallpaper(g, hidden ? 0xFF1B070E : 0xFFF3DDEB, hidden ? 0xFF050507 : 0xFFD3B3E6);
        else Gfx.rr(g, 5, 5, W - 10, H - 10, 18, bg());
        Gfx.rr(g, 55, 10, 40, 11, 5, 0xFF000000);
        LocalDateTime now = LocalDateTime.now();
        int statusInk = lock || (home && hidden) ? 0xFFFFFFFF : ink();
        Gfx.text(g, font, String.format("%02d:%02d", now.getHour(), now.getMinute()), 16, 12, statusInk, 0.9f, false);
        for (int i = 0; i < 4; i++) g.fill(104 + i * 3, 18 - i * 2, 106 + i * 3, 19, statusInk);
        g.fill(119, 14, 131, 19, statusInk);
        g.fill(131, 15, 132, 18, statusInk);
        switch (page) {
            case LOCK -> { }
            case HOME -> home(g);
            case BANK -> bank(g);
            case WALLET -> wallet(g);
            case CASINO -> casino(g);
            case SETTINGS -> settings(g);
            case CONTRACTS -> contracts(g);
            case NET -> net(g);
            case BLACK -> black(g);
            case BIT -> bit(g);
            case MARKET -> market(g);
            case JOBS -> jobs(g);
            case ESTATE -> estate(g);
            case CONTACTS -> contacts(g);
            case WEATHER -> weather(g);
            case MAPS -> maps(g);
            case CALC -> calc(g);
        }
        Gfx.rr(g, 55, 276, 40, 3, 1, statusInk);
        hits.add(new Hit(40, 270, 70, 14, () -> { if (page != Page.LOCK) go(Page.HOME); }));

        long since = System.currentTimeMillis() - pageSince;
        if (!lock && since < FADE_MS) {                       // soft fade-in when a page opens
            int a = (int) (200 * (1 - since / (float) FADE_MS));
            Gfx.rr(g, 5, 24, 140, 238, 8, (a << 24) | (home ? (hidden ? 0x14070C : 0xE3C5EA) : (bg() & 0xFFFFFF)));
        }
        long age = System.currentTimeMillis() - ClientState.toastAt;
        if (!ClientState.toast.isEmpty() && age < 3500 && !lock) {
            int w = Math.min(138, font.width(ClientState.toast) * 4 / 5 + 24);
            Gfx.card(g, (W - w) / 2, 250, w, 17, 8, 0xF0101014);
            Gfx.rr(g, (W - w) / 2 + 6, 256, 5, 5, 2, ACCENT);
            Gfx.text(g, font, ClientState.toast, W / 2 + 4, 255, 0xFFFFFFFF, 0.78f, true);
        }
    }

    private void go(Page p) {
        page = p;
        pageSince = System.currentTimeMillis();
        send("SYNC", 0, 0);
    }

    private void header(GuiGraphics g, String title) {
        Gfx.text(g, font, "‹", 13, 26, ACCENT, 1.7f, false);
        Gfx.text(g, font, "Домой", 22, 31, ACCENT, 0.85f, false);
        hits.add(new Hit(10, 24, 52, 17, () -> go(Page.HOME)));
        Gfx.text(g, font, title, W / 2 + 18, 30, ink(), 1.05f, true);
        g.fill(12, 42, 138, 43, line());
    }

    private boolean hover(int x, int y, int w, int h) { return mlx >= x && mlx < x + w && mly >= y && mly < y + h; }

    private void btn(GuiGraphics g, int x, int y, int w, int h, String label, int fill, Runnable r) {
        int rad = Math.min(7, h / 2);
        Gfx.gradRr(g, x, y, w, h, rad, Gfx.lerp(fill, 0xFFFFFFFF, 0.16f), fill);
        if (hover(x, y, w, h)) Gfx.rr(g, x, y, w, h, rad, 0x2AFFFFFF);
        Gfx.text(g, font, label, x + w / 2, y + (h - 7) / 2, 0xFFFFFFFF, 0.9f, true);
        hits.add(new Hit(x, y, w, h, r));
    }

    private void chips(GuiGraphics g, int y) {
        for (int i = 0; i < CHIPS.length; i++) {
            int x = 12 + i * 32, idx = i;
            boolean sel = i == chip;
            if (sel) Gfx.gradRr(g, x, y, 29, 16, 8, 0xFFB5254D, ACCENT);
            else Gfx.card(g, x, y, 29, 16, 8, card());
            Gfx.text(g, font, "€" + CHIPS[i] / 100, x + 14, y + 4, sel ? 0xFFFFFFFF : ink(), 0.8f, true);
            hits.add(new Hit(x, y, 29, 16, () -> chip = idx));
        }
    }

    private void locked(GuiGraphics g, String title) {
        header(g, title);
        Gfx.card(g, 55, 100, 40, 40, 12, card());
        Gfx.text(g, font, "x", W / 2, 114, GREY, 1.6f, true);
        Gfx.text(g, font, "Нет сигнала DarkNet", W / 2, 150, sub(), 0.9f, true);
        Gfx.text(g, font, "Взломай сеть в приложении Сеть", W / 2, 162, sub(), 0.7f, true);
    }

    // ---- lock screen with Face ID and the Light / Dark switch ----------------------------------
    private void lock(GuiGraphics g) {
        long age = System.currentTimeMillis() - lockAt;
        int top = hidden ? 0xFF1B070E : 0xFF8A1A3C, bottom = hidden ? 0xFF050507 : 0xFF2A0714;
        wallpaper(g, top, bottom);
        LocalDateTime now = LocalDateTime.now();
        String date = DAYS[now.getDayOfWeek().getValue() - 1] + ", " + now.getDayOfMonth() + " " + MONTHS[now.getMonthValue() - 1];
        Gfx.text(g, font, date, W / 2, 40, 0xCCFFFFFF, 0.9f, true);
        Gfx.text(g, font, String.format("%02d:%02d", now.getHour(), now.getMinute()), W / 2, 52, 0xFFFFFFFF, 3.2f, true);

        boolean done = age >= SCAN_END;
        int cx = 75, cy = 150, frame = done ? GREEN : 0xFFFFFFFF;
        int fill = Gfx.lerp(top, bottom, (cy - 24) / 228f);
        Gfx.rr(g, cx - 19, cy - 19, 38, 38, 11, frame);
        Gfx.rr(g, cx - 17, cy - 17, 34, 34, 9, fill);
        if (!done) {
            g.fill(cx - 9, cy - 6, cx - 7, cy - 1, 0xFFFFFFFF);
            g.fill(cx + 7, cy - 6, cx + 9, cy - 1, 0xFFFFFFFF);
            g.fill(cx, cy - 4, cx + 1, cy + 3, 0xFFFFFFFF);
            g.fill(cx - 7, cy + 8, cx + 7, cy + 9, 0xFFFFFFFF);
            if (age > SCAN_START) {
                int ly = cy - 15 + (int) (30 * (0.5 + 0.5 * Math.sin((age - SCAN_START) / 110.0)));
                g.fill(cx - 15, ly, cx + 15, ly + 1, 0xFF30D158);
            }
            Gfx.text(g, font, age > SCAN_START ? "Face ID" : "Поднеси к лицу", cx, cy + 26, 0xFFFFFFFF, 0.9f, true);
        } else {
            Gfx.text(g, font, "OK", cx, cy - 5, GREEN, 1.8f, true);
            Gfx.text(g, font, "Разблокировано", cx, cy + 26, GREEN, 0.9f, true);
        }
        Gfx.text(g, font, "Режим телефона", cx, 208, 0xAAFFFFFF, 0.8f, true);
        Gfx.rr(g, 25, 220, 100, 22, 11, 0x66000000);
        Gfx.gradRr(g, hidden ? 76 : 27, 222, 47, 18, 9, hidden ? 0xFFB5254D : 0xFFFFFFFF, hidden ? ACCENT : 0xFFE6E6EB);
        Gfx.text(g, font, "Светлый", 50, 227, hidden ? 0xCCFFFFFF : 0xFF111114, 0.85f, true);
        Gfx.text(g, font, "Тёмный", 99, 227, hidden ? 0xFFFFFFFF : 0xCCFFFFFF, 0.85f, true);
        hits.add(new Hit(25, 220, 50, 22, () -> setDark(false)));
        hits.add(new Hit(75, 220, 50, 22, () -> setDark(true)));
        if (age >= UNLOCK_AT) go(Page.HOME);
    }

    // ---- home ----------------------------------------------------------------------------------
    private void icon(GuiGraphics g, int x, int y, int size, int color, String glyph) {
        Gfx.rr(g, x, y + 1, size, size, 8, 0x40000000);
        Gfx.gradRr(g, x, y, size, size, 8, Gfx.lerp(color, 0xFFFFFFFF, 0.28f), color);
        Gfx.rr(g, x + 2, y + 1, size - 4, size / 2 - 1, 6, 0x1CFFFFFF);
        Gfx.text(g, font, glyph, x + size / 2, y + (int) (size * 0.33f), 0xFFFFFFFF, size > 26 ? 1.4f : 1.2f, true);
    }

    private void home(GuiGraphics g) {
        int labelInk = hidden ? 0xFFEDEDF0 : 0xFF2A1830;
        // balance widget
        Gfx.rr(g, 10, 44, 130, 46, 13, hidden ? 0x99202026 : 0xBBFFFFFF);
        Gfx.text(g, font, hidden ? "Наличные" : "Баланс", 20, 51, hidden ? 0xFFA8A8B0 : 0xFF6E6E73, 0.75f, false);
        Gfx.text(g, font, PlayerFunds.fmt(hidden ? ClientState.cash : ClientState.bank), 20, 61, labelInk, 1.5f, false);
        Gfx.text(g, font, String.format(Locale.ROOT, "BIT %.4f", ClientState.bit), 20, 78, hidden ? 0xFF8E8E93 : 0xFF6E6E73, 0.75f, false);
        hits.add(new Hit(10, 44, 130, 46, () -> go(hidden ? Page.WALLET : Page.BANK)));

        App[] grid, dock;
        if (hidden) {
            grid = new App[]{new App("Кошелёк", "W", 0xFF1C1C1E, Page.WALLET), new App("Bit", "B", 0xFFF7931A, Page.BIT),
                    new App("Работа", "E", 0xFF5A4B00, Page.JOBS), new App("Настройки", "S", 0xFF48484A, Page.SETTINGS)};
            dock = new App[]{new App("Сеть", "N", 0xFF1F6F3F, Page.NET), new App("Заказы", "O", 0xFF8B0000, Page.CONTRACTS),
                    new App("Чёрный", "X", 0xFF333333, Page.BLACK), new App("Контакты", "K", 0xFF2C6B8A, Page.CONTACTS)};
        } else {
            grid = new App[]{new App("Кошелёк", "W", 0xFF1C1C1E, Page.WALLET), new App("Bit", "B", 0xFFF7931A, Page.BIT),
                    new App("Недвиж.", "H", 0xFF5E5CE6, Page.ESTATE), new App("Погода", "P", 0xFF3A8DDE, Page.WEATHER),
                    new App("Карты", "M", 0xFF34A853, Page.MAPS), new App("Калькул.", "=", 0xFF636366, Page.CALC),
                    new App("Настройки", "S", GREY, Page.SETTINGS)};
            dock = new App[]{new App("Банк", "$", 0xFF2E7D5B, Page.BANK), new App("Маркет", "M", BLUE, Page.MARKET),
                    new App("Казино", "C", 0xFFB3122E, Page.CASINO), new App("Контакты", "K", 0xFF2C6B8A, Page.CONTACTS)};
        }
        for (int i = 0; i < grid.length; i++) {
            App a = grid[i];
            int x = 13 + (i % 4) * 33, y = 100 + (i / 4) * 46;
            icon(g, x, y, 29, a.color, a.glyph);
            Gfx.text(g, font, a.name, x + 15, y + 33, labelInk, 0.62f, true);
            hits.add(new Hit(x, y, 29, 38, () -> go(a.page)));
        }
        Gfx.rr(g, 10, 228, 130, 38, 15, hidden ? 0x88202026 : 0x99FFFFFF);
        for (int i = 0; i < dock.length; i++) {
            App a = dock[i];
            int x = 15 + i * 32, y = 234;
            icon(g, x, y, 26, a.color, a.glyph);
            hits.add(new Hit(x, y, 26, 26, () -> go(a.page)));
        }
    }

    // ---- bank / wallet -------------------------------------------------------------------------
    private void bank(GuiGraphics g) {
        header(g, "Банк");
        Gfx.gradRr(g, 12, 50, 126, 66, 13, 0xFF8C2A4A, 0xFF4A0E22);
        Gfx.text(g, font, "Баланс", 22, 60, 0xFFE9B6C4, 0.8f, false);
        Gfx.text(g, font, PlayerFunds.fmt(ClientState.bank), 22, 72, 0xFFFFFFFF, 1.7f, false);
        Gfx.text(g, font, "Наличные " + PlayerFunds.fmt(ClientState.cash), 22, 100, 0xFFE9B6C4, 0.85f, false);
        chips(g, 126);
        btn(g, 12, 152, 126, 20, "Положить наличные", GREEN, () -> send("DEPOSIT", CHIPS[chip], 0));
        btn(g, 12, 178, 126, 20, "Снять", BLUE, () -> send("WITHDRAW", CHIPS[chip], 0));
        Gfx.text(g, font, "Банкомат: клик +€100, Shift-клик - внести всё", W / 2, 208, sub(), 0.6f, true);
    }

    private void wallet(GuiGraphics g) {
        header(g, "Кошелёк");
        Gfx.card(g, 12, 50, 126, 46, 11, card());
        Gfx.text(g, font, "Наличные", 22, 58, sub(), 0.8f, false);
        Gfx.text(g, font, PlayerFunds.fmt(ClientState.cash), 22, 70, ink(), 1.4f, false);
        Gfx.card(g, 12, 102, 126, 46, 11, card());
        Gfx.text(g, font, "Счёт", 22, 110, sub(), 0.8f, false);
        Gfx.text(g, font, PlayerFunds.fmt(ClientState.bank), 22, 122, ink(), 1.4f, false);
        Gfx.card(g, 12, 154, 126, 46, 11, card());
        Gfx.text(g, font, "BIT", 22, 162, sub(), 0.8f, false);
        Gfx.text(g, font, String.format(Locale.ROOT, "%.5f", ClientState.bit), 22, 174, ink(), 1.2f, false);
        Gfx.text(g, font, "≈ " + PlayerFunds.fmt(Math.round(ClientState.bit * bitPrice() * 100)), 22, 189, sub(), 0.75f, false);
    }

    private long gameTime() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? 0 : mc.level.getGameTime();
    }

    private double bitPrice() { return BitMarket.price(gameTime()); }

    // ---- BIT -----------------------------------------------------------------------------------
    private void bit(GuiGraphics g) {
        header(g, "Bit");
        long t = gameTime();
        double price = BitMarket.price(t);
        Gfx.text(g, font, String.format("€%,.0f", price), 14, 48, 0xFFF7931A, 1.6f, false);
        double lo = Double.MAX_VALUE, hi = 0;
        double[] hist = new double[30];
        for (int i = 0; i < 30; i++) {
            hist[i] = BitMarket.price(t - (29 - i) * 600L);
            lo = Math.min(lo, hist[i]);
            hi = Math.max(hi, hist[i]);
        }
        Gfx.card(g, 12, 68, 126, 40, 9, card());
        for (int i = 0; i < 30; i++) {
            int hh = 3 + (int) (30 * (hist[i] - lo) / Math.max(1, hi - lo));
            g.fill(16 + i * 4, 104 - hh, 19 + i * 4, 104, i == 29 ? 0xFFF7931A : 0xFF8E8E93);
        }
        Gfx.text(g, font, String.format(Locale.ROOT, "У тебя %.5f BIT", ClientState.bit), 14, 114, sub(), 0.8f, false);
        chips(g, 128);
        btn(g, 12, 152, 126, 20, "Купить (со счёта)", GREEN, () -> send("BIT_BUY", CHIPS[chip], 0));
        btn(g, 12, 178, 126, 20, "Продать (на счёт)", BLUE, () -> send("BIT_SELL", CHIPS[chip], 0));
        Gfx.text(g, font, "Комиссия 1%. Курс меняется со временем.", W / 2, 208, sub(), 0.7f, true);
    }

    // ---- market --------------------------------------------------------------------------------
    private void market(GuiGraphics g) {
        header(g, "Маркет");
        Gfx.text(g, font, "Продай предмет из руки", 14, 49, sub(), 0.8f, false);
        btn(g, 12, 60, 126, 20, "Найти покупателя", BLUE, () -> send("MARKET_OFFER", 0, 0));
        if (!ClientState.market.isEmpty()) {
            Gfx.card(g, 12, 90, 126, 52, 11, card());
            String[] f = ClientState.market.split("\\|");
            Gfx.text(g, font, f[0].trim(), 20, 98, ink(), 0.9f, false);
            if (f.length > 1) Gfx.text(g, font, f[1].trim().replace("offer", "цена"), 20, 112, 0xFFFFB84D, 1f, false);
            if (f.length > 2) Gfx.text(g, font, "последняя цена", 20, 126, sub(), 0.75f, false);
            btn(g, 12, 150, 60, 20, "Принять", GREEN, () -> send("MARKET_ACCEPT", 0, 0));
            btn(g, 78, 150, 60, 20, "Торг", ACCENT, () -> send("MARKET_COUNTER", 0, 0));
        } else {
            Gfx.text(g, font, "Покупатели дают до ~60% от", W / 2, 102, sub(), 0.75f, true);
            Gfx.text(g, font, "цены чёрного рынка.", W / 2, 112, sub(), 0.75f, true);
        }
    }

    // ---- casino (roulette, crash, slots, dice) -------------------------------------------------
    private void casino(GuiGraphics g) {
        header(g, "Казино");
        String[] tabs = {"Рулетка", "Краш", "Слоты", "Кости"};
        for (int i = 0; i < 4; i++) {
            int x = 12 + i * 32, idx = i;
            if (i == tab) Gfx.gradRr(g, x, 48, 30, 15, 7, 0xFFB5254D, ACCENT);
            else Gfx.card(g, x, 48, 30, 15, 7, card());
            Gfx.text(g, font, tabs[i], x + 15, 52, i == tab ? 0xFFFFFFFF : ink(), 0.62f, true);
            hits.add(new Hit(x, 48, 30, 15, () -> tab = idx));
        }
        Gfx.text(g, font, "Наличные " + PlayerFunds.fmt(ClientState.cash), 14, 70, sub(), 0.8f, false);
        chips(g, 82);
        if (tab == 0) {
            btn(g, 12, 110, 60, 22, "Красное x2", 0xFFB3122E, () -> send("ROULETTE", CHIPS[chip], 100));
            btn(g, 78, 110, 60, 22, "Чёрное x2", 0xFF2C2C2E, () -> send("ROULETTE", CHIPS[chip], 101));
            btn(g, 12, 138, 126, 18, "Зеро x36", 0xFF1F7A3F, () -> send("ROULETTE", CHIPS[chip], 102));
            Gfx.text(g, font, "Европейская рулетка, 37 ячеек", W / 2, 166, sub(), 0.75f, true);
        } else if (tab == 2) {
            btn(g, 12, 114, 126, 26, "Крутить", ACCENT, () -> send("SLOTS", CHIPS[chip], 0));
            Gfx.text(g, font, "Три одинаковых - x20", W / 2, 150, sub(), 0.8f, true);
            Gfx.text(g, font, "Две одинаковых - вернётся 90%", W / 2, 162, sub(), 0.8f, true);
        } else if (tab == 3) {
            btn(g, 12, 110, 126, 20, "Меньше 7   x2.28", BLUE, () -> send("DICE", CHIPS[chip], 0));
            btn(g, 12, 136, 126, 20, "Ровно 7   x5.7", ACCENT, () -> send("DICE", CHIPS[chip], 1));
            btn(g, 12, 162, 126, 20, "Больше 7   x2.28", BLUE, () -> send("DICE", CHIPS[chip], 2));
            Gfx.text(g, font, "Бросаются два кубика", W / 2, 192, sub(), 0.75f, true);
        } else {
            int st = ClientState.crashStatus;
            double m = ClientState.mult;
            if (st == 1) m = ClientState.mult * Math.exp(0.09 * (System.currentTimeMillis() - ClientState.stamp) / 1000.0);
            int col = st == 2 ? 0xFFFF453A : st == 3 ? GREEN : ink();
            Gfx.text(g, font, String.format(Locale.ROOT, "x%.2f", Math.max(1.0, m)), W / 2, 114, col, 2.2f, true);
            int bar = (int) (126 * Math.min(1.0, Math.log(Math.max(1.0, m)) / Math.log(10)));
            Gfx.rr(g, 12, 142, 126, 6, 3, line());
            if (bar > 2) Gfx.rr(g, 12, 142, bar, 6, 3, col == ink() ? ACCENT : col);
            if (st == 1) btn(g, 12, 158, 126, 22, "Забрать", GREEN, () -> send("CRASH_CASH", 0, 0));
            else btn(g, 12, 158, 126, 22, "Начать раунд", ACCENT, () -> send("CRASH_START", CHIPS[chip], 0));
            Gfx.text(g, font, "Забери выигрыш до краха", W / 2, 190, sub(), 0.75f, true);
        }
    }

    // ---- settings ------------------------------------------------------------------------------
    private void settings(GuiGraphics g) {
        header(g, "Настройки");
        Gfx.card(g, 12, 50, 126, 50, 11, card());
        Gfx.text(g, font, "Оформление", 22, 58, sub(), 0.8f, false);
        Gfx.rr(g, 20, 72, 110, 20, 10, hidden ? 0xFF2C2C31 : 0xFFE5E5EA);
        Gfx.gradRr(g, hidden ? 76 : 22, 74, 52, 16, 8, hidden ? 0xFFB5254D : 0xFFFFFFFF, hidden ? ACCENT : 0xFFE6E6EB);
        Gfx.text(g, font, "Светлый", 48, 78, hidden ? GREY : 0xFF111114, 0.85f, true);
        Gfx.text(g, font, "Тёмный", 102, 78, hidden ? 0xFFFFFFFF : GREY, 0.85f, true);
        hits.add(new Hit(20, 72, 55, 20, () -> setDark(false)));
        hits.add(new Hit(75, 72, 55, 20, () -> setDark(true)));
        Gfx.card(g, 12, 106, 126, 30, 11, card());
        Gfx.text(g, font, "Face ID", 22, 114, sub(), 0.8f, false);
        Gfx.text(g, font, "Включён", 22, 124, GREEN, 1f, false);
        btn(g, 12, 144, 126, 20, "Заблокировать", ACCENT, () -> { page = Page.LOCK; lockAt = System.currentTimeMillis(); });
        Gfx.text(g, font, "iOS 26.0.1 (23A5297m)", W / 2, 176, sub(), 0.7f, true);
    }

    // ---- weather (client side, from the same wind model the guns use) --------------------------
    private static String compass(double deg) {
        String[] n = {"С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ"};
        return n[(int) Math.floorMod(Math.round(deg / 45.0), 8L)];
    }

    private void weather(GuiGraphics g) {
        header(g, "Погода");
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        float base = mc.level.getBiome(mc.player.blockPosition()).value().getBaseTemperature();
        int temp = Math.round(base * 22f);
        boolean storm = mc.level.isThundering(), rain = mc.level.isRaining();
        String cond = storm ? "Гроза" : rain ? "Дождь" : "Ясно";
        Vec3 wind = WindManager.wind(mc.level);
        double from = (Math.toDegrees(Math.atan2(wind.x, -wind.z)) + 180 + 360) % 360;
        int top = storm ? 0xFF3A4254 : rain ? 0xFF5B6B85 : 0xFF3F86D0, bottom = storm ? 0xFF1F2430 : rain ? 0xFF3C4A60 : 0xFF8EC5F0;
        Gfx.gradRr(g, 12, 50, 126, 80, 14, top, bottom);
        Gfx.text(g, font, temp + "°", 75, 60, 0xFFFFFFFF, 3.2f, true);
        Gfx.text(g, font, cond, 75, 94, 0xFFFFFFFF, 1.1f, true);
        Gfx.text(g, font, String.format(Locale.ROOT, "Ветер %.1f м/с, %s", wind.horizontalDistance(), compass(from)), 75, 110, 0xDDFFFFFF, 0.8f, true);
        long dt = mc.level.getDayTime(), tt = dt % 24000L;
        int h = (int) ((tt / 1000 + 6) % 24), m = (int) ((tt % 1000) * 60 / 1000);
        int hum = storm ? 95 : rain ? 85 : 45;
        double pres = 1013 - (mc.player.getY() - 64) * 0.12 - (rain ? 8 : 0);
        String[][] cells = {{"Влажность", hum + " %"}, {"Давление", String.format("%.0f гПа", pres)},
                {"Время", String.format("%02d:%02d", h, m)}, {"День", Long.toString(dt / 24000L)}};
        for (int i = 0; i < 4; i++) {
            int x = 12 + (i % 2) * 65, y = 138 + (i / 2) * 46;
            Gfx.card(g, x, y, 61, 40, 10, card());
            Gfx.text(g, font, cells[i][0], x + 8, y + 7, sub(), 0.75f, false);
            Gfx.text(g, font, cells[i][1], x + 8, y + 20, ink(), 1.1f, false);
        }
    }

    // ---- maps: compass, coordinates, distance to your properties -------------------------------
    private void maps(GuiGraphics g) {
        header(g, "Карты");
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        double bearing = (mc.player.getYRot() + 180 + 360) % 360;   // MC yaw 0 = south
        Gfx.card(g, 37, 52, 76, 76, 38, card());
        g.pose().pushPose();
        g.pose().translate(75, 90, 0);
        g.pose().mulPose(Axis.ZP.rotation((float) Math.toRadians(-bearing)));
        Gfx.text(g, font, "С", 0, -34, 0xFFFF453A, 0.9f, true);
        Gfx.text(g, font, "Ю", 0, 26, sub(), 0.7f, true);
        Gfx.text(g, font, "В", 30, -3, sub(), 0.7f, true);
        Gfx.text(g, font, "З", -30, -3, sub(), 0.7f, true);
        if (!ClientState.estate.isEmpty()) {
            for (String row : ClientState.estate.split(";")) {
                String[] f = row.split("\\|");
                if (f.length < 2) continue;
                String[] c = f[1].split(",");
                try {
                    double dx = Double.parseDouble(c[0]) - mc.player.getX(), dz = Double.parseDouble(c[2]) - mc.player.getZ();
                    double b = Math.atan2(dx, -dz);
                    int px = (int) (Math.sin(b) * 20), py = (int) (-Math.cos(b) * 20);
                    Gfx.rr(g, px - 2, py - 2, 5, 5, 2, 0xFF5E5CE6);
                } catch (NumberFormatException ignored) { }
            }
        }
        g.pose().popPose();
        g.fill(74, 80, 76, 98, ACCENT);
        for (int i = 0; i < 4; i++) g.fill(75 - i, 76 + i, 76 + i, 77 + i, ACCENT);
        Gfx.text(g, font, String.format(Locale.ROOT, "X %.0f   Y %.0f   Z %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ()),
                W / 2, 138, ink(), 0.85f, true);
        String biome = mc.level.getBiome(mc.player.blockPosition()).unwrapKey().map(k -> k.location().getPath()).orElse("?");
        Gfx.text(g, font, "Биом: " + biome.replace('_', ' '), W / 2, 150, sub(), 0.8f, true);
        Gfx.card(g, 12, 164, 126, 52, 11, card());
        Gfx.text(g, font, "Твои объекты", 20, 171, sub(), 0.75f, false);
        if (ClientState.estate.isEmpty()) {
            Gfx.text(g, font, "Пока нет", 20, 186, ink(), 0.9f, false);
        } else {
            int shown = 0;
            for (String row : ClientState.estate.split(";")) {
                String[] f = row.split("\\|");
                if (f.length < 2 || shown >= 3) continue;
                String[] c = f[1].split(",");
                try {
                    double dx = Double.parseDouble(c[0]) - mc.player.getX(), dz = Double.parseDouble(c[2]) - mc.player.getZ();
                    Gfx.text(g, font, f[0] + " - " + Math.round(Math.sqrt(dx * dx + dz * dz)) + " м", 20, 183 + shown * 10, ink(), 0.8f, false);
                    shown++;
                } catch (NumberFormatException ignored) { }
            }
        }
    }

    // ---- calculator ----------------------------------------------------------------------------
    private double calcValue() {
        try { return Double.parseDouble(calcDisplay); } catch (NumberFormatException e) { return 0; }
    }

    private String calcFmt(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return "Ошибка";
        if (v == Math.rint(v) && Math.abs(v) < 1e12) return Long.toString((long) v);
        String s = String.format(Locale.ROOT, "%.8f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
        return s.length() > 12 ? s.substring(0, 12) : s;
    }

    private void calcApply() {
        double cur = calcValue();
        if (calcOp == 0) calcAcc = cur;
        else switch (calcOp) {
            case '+' -> calcAcc += cur;
            case '-' -> calcAcc -= cur;
            case '×' -> calcAcc *= cur;
            case '÷' -> calcAcc = cur == 0 ? Double.NaN : calcAcc / cur;
            default -> { }
        }
        calcDisplay = calcFmt(calcAcc);
    }

    private void calcKey(String k) {
        if (calcDisplay.equals("Ошибка") && !k.equals("C")) return;
        switch (k) {
            case "C" -> { calcDisplay = "0"; calcAcc = 0; calcOp = 0; calcFresh = true; }
            case "±" -> { if (!calcDisplay.equals("0")) calcDisplay = calcDisplay.startsWith("-") ? calcDisplay.substring(1) : "-" + calcDisplay; }
            case "<" -> { calcDisplay = calcFresh || calcDisplay.length() <= 1 ? "0" : calcDisplay.substring(0, calcDisplay.length() - 1); }
            case "+", "-", "×", "÷" -> { calcApply(); calcOp = k.charAt(0); calcFresh = true; }
            case "=" -> { calcApply(); calcOp = 0; calcFresh = true; }
            case "." -> {
                if (calcFresh) { calcDisplay = "0."; calcFresh = false; }
                else if (!calcDisplay.contains(".")) calcDisplay += ".";
            }
            default -> {
                if (calcFresh || calcDisplay.equals("0")) { calcDisplay = k; calcFresh = false; }
                else if (calcDisplay.length() < 11) calcDisplay += k;
            }
        }
    }

    private void calc(GuiGraphics g) {
        header(g, "Калькулятор");
        Gfx.card(g, 12, 48, 126, 38, 10, card());
        Gfx.textRight(g, font, calcDisplay, 132, 62, ink(), calcDisplay.length() > 8 ? 1.3f : 1.8f);
        String[][] keys = {{"C", "±", "<", "÷"}, {"7", "8", "9", "×"}, {"4", "5", "6", "-"}, {"1", "2", "3", "+"}, {"0", "0", ".", "="}};
        for (int r = 0; r < 5; r++) {
            for (int c = 0; c < 4; c++) {
                if (r == 4 && c == 1) continue;   // the wide zero covers two columns
                String k = keys[r][c];
                int w = (r == 4 && c == 0) ? 60 : 28;
                int x = 12 + c * 32, y = 94 + r * 28;
                boolean op = "÷×-+=".contains(k);
                int fill = op ? ORANGE : (r == 0 ? 0xFF8E8E93 : (hidden ? 0xFF2C2C31 : 0xFF48484A));
                btn(g, x, y, w, 24, k, fill, () -> calcKey(k));
            }
        }
    }

    // ---- contacts / calls ----------------------------------------------------------------------
    private void contacts(GuiGraphics g) {
        header(g, "Контакты");
        if (ClientState.contacts.isEmpty()) {
            Gfx.text(g, font, "Пока никого нет", W / 2, 100, sub(), 0.95f, true);
            Gfx.text(g, font, "Поговори с жителем города,", W / 2, 116, sub(), 0.75f, true);
            Gfx.text(g, font, "и он появится здесь", W / 2, 127, sub(), 0.75f, true);
            return;
        }
        String[] rows = ClientState.contacts.split(";");
        boolean calling = false;
        for (int i = 0; i < Math.min(rows.length, 6); i++) {
            String[] f = rows[i].split("\\|");
            if (f.length < 3) continue;
            boolean on = f[2].equals("1");
            calling |= on;
            int y = 48 + i * 33, idx = i;
            Gfx.card(g, 10, y, 130, 29, 9, card());
            Gfx.rr(g, 16, y + 6, 17, 17, 8, on ? GREEN : 0xFF2C6B8A);
            Gfx.text(g, font, f[0].substring(0, 1), 24, y + 11, 0xFFFFFFFF, 0.9f, true);
            Gfx.text(g, font, f[0], 38, y + 6, ink(), 0.8f, false);
            Gfx.text(g, font, f[1], 38, y + 16, sub(), 0.65f, false);
            if (on) btn(g, 98, y + 8, 38, 13, "Сброс", 0xFF8B0000, () -> send("HANGUP", 0, 0));
            else btn(g, 98, y + 8, 38, 13, "Звонок", 0xFF1F7A3F, () -> send("CALL", 0, idx));
        }
        if (calling) Gfx.text(g, font, "Идёт звонок - пиши в чат", W / 2, 248, GREEN, 0.75f, true);
    }

    // ---- estate --------------------------------------------------------------------------------
    private void estate(GuiGraphics g) {
        header(g, "Недвижимость");
        if (ClientState.estate.isEmpty()) {
            Gfx.text(g, font, "Пока нет объектов", W / 2, 100, sub(), 0.95f, true);
            Gfx.text(g, font, "Найди табличку «Продаётся»:", W / 2, 116, sub(), 0.75f, true);
            Gfx.text(g, font, "Shift + клик, чтобы купить", W / 2, 127, sub(), 0.75f, true);
            return;
        }
        String[] rows = ClientState.estate.split(";");
        for (int i = 0; i < Math.min(rows.length, 5); i++) {
            String[] f = rows[i].split("\\|");
            if (f.length < 4) continue;
            int y = 48 + i * 40, idx = i;
            Gfx.card(g, 10, y, 130, 36, 9, card());
            Gfx.text(g, font, f[0], 18, y + 6, ink(), 0.95f, false);
            Gfx.text(g, font, f[1], 18, y + 17, sub(), 0.7f, false);
            long inc = Long.parseLong(f[2]);
            Gfx.text(g, font, inc > 0 ? "+" + PlayerFunds.fmt(inc) + "/день" : "без дохода", 18, y + 26, inc > 0 ? GREEN : sub(), 0.7f, false);
            btn(g, 100, y + 21, 36, 12, "Продать", 0xFF8B0000, () -> send("ESTATE_SELL", 0, idx));
        }
        Gfx.text(g, font, "Продажа - 80% цены. Доход идёт на счёт.", W / 2, 250, sub(), 0.6f, true);
    }

    // ---- hidden: Net (hack minigame) -----------------------------------------------------------
    private void net(GuiGraphics g) {
        header(g, "Сеть");
        if (!ClientState.hackSeq.isEmpty()) {
            if (ClientState.hackStamp != hackSeen) {
                hackSeen = ClientState.hackStamp;
                hackShownAt = System.currentTimeMillis();
                entered.setLength(0);
            }
            if (System.currentTimeMillis() - hackShownAt < 3500) {
                Gfx.text(g, font, "Запомни код", W / 2, 72, sub(), 1f, true);
                Gfx.text(g, font, ClientState.hackSeq, W / 2, 98, 0xFF30D158, 2.4f, true);
                return;
            }
            Gfx.text(g, font, "Введи код", W / 2, 58, sub(), 1f, true);
            StringBuilder dots = new StringBuilder();
            for (int i = 0; i < ClientState.hackSeq.length(); i++) dots.append(i < entered.length() ? entered.charAt(i) : '_').append(' ');
            Gfx.text(g, font, dots.toString().trim(), W / 2, 76, ink(), 1.6f, true);
            for (int i = 0; i < 9; i++) {
                int x = 15 + (i % 3) * 42, y = 102 + (i / 3) * 30, d = i + 1;
                Gfx.card(g, x, y, 36, 24, 9, card());
                if (hover(x, y, 36, 24)) Gfx.rr(g, x, y, 36, 24, 9, 0x22FFFFFF);
                Gfx.text(g, font, Integer.toString(d), x + 18, y + 8, ink(), 1.2f, true);
                hits.add(new Hit(x, y, 36, 24, () -> {
                    entered.append(d);
                    if (entered.length() >= ClientState.hackSeq.length()) {
                        long v = Long.parseLong(entered.toString());
                        entered.setLength(0);
                        ClientState.hackSeq = "";
                        send("HACK_SUBMIT", v, 0);
                    }
                }));
            }
            return;
        }
        long left = ClientState.darkSecondsLeft();
        Gfx.card(g, 12, 48, 126, 22, 9, left > 0 ? 0xFF14361F : card());
        Gfx.text(g, font, left > 0 ? String.format("DarkNet открыт %d:%02d", left / 60, left % 60) : "DarkNet выключен",
                W / 2, 55, left > 0 ? GREEN : sub(), 0.95f, true);
        Gfx.text(g, font, "Сети поблизости", 14, 80, sub(), 0.8f, false);
        for (int i = 0; i < NETS.length; i++) {
            int y = 94 + i * 38, idx = i;
            Gfx.card(g, 12, y, 126, 32, 9, card());
            Gfx.text(g, font, NETS[i], 20, y + 7, ink(), 0.9f, false);
            Gfx.text(g, font, "Длина кода " + (4 + i), 20, y + 19, sub(), 0.75f, false);
            btn(g, 96, y + 10, 38, 14, "Взлом", 0xFF1F6F3F, () -> send("HACK_START", 0, idx));
        }
    }

    // ---- hidden: orders board ------------------------------------------------------------------
    private void contracts(GuiGraphics g) {
        if (ClientState.darkSecondsLeft() <= 0) { locked(g, "Заказы"); return; }
        header(g, "Заказы");
        int y = 48;
        for (String row : ClientState.contracts) {
            String[] f = row.split("\\|");
            if (f.length < 4) continue;
            int id = Integer.parseInt(f[0]);
            Gfx.card(g, 10, y, 130, 36, 9, card());
            Gfx.text(g, font, f[1], 18, y + 6, ink(), 0.9f, false);
            Gfx.text(g, font, f[2] + "  " + PlayerFunds.fmt(Long.parseLong(f[3])), 18, y + 18, sub(), 0.75f, false);
            btn(g, 100, y + 21, 36, 12, "Взять", 0xFF8B0000, () -> send("CONTRACT_ACCEPT", 0, id));
            y += 40;
        }
        if (!ClientState.active.isEmpty())
            Gfx.text(g, font, "Активно: " + ClientState.active, W / 2, 248, ORANGE, 0.65f, true);
    }

    // ---- hidden: black market shop (41 items) --------------------------------------------------
    private void black(GuiGraphics g) {
        if (ClientState.darkSecondsLeft() <= 0) { locked(g, "Чёрный рынок"); return; }
        header(g, "Чёрный рынок");
        int pages = (Shop.CATALOG.size() + PER_PAGE - 1) / PER_PAGE;
        shopPage = Math.max(0, Math.min(shopPage, pages - 1));
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = shopPage * PER_PAGE + i;
            if (idx >= Shop.CATALOG.size()) break;
            Shop.Entry e = Shop.CATALOG.get(idx);
            int y = 47 + i * 35;
            Gfx.card(g, 10, y, 130, 31, 9, card());
            Gfx.text(g, font, e.label(), 18, y + 7, ink(), 0.9f, false);
            Gfx.text(g, font, PlayerFunds.fmt(e.cents()), 18, y + 19, sub(), 0.75f, false);
            btn(g, 98, y + 9, 38, 13, "Купить", 0xFF8B0000, () -> send("SHOP_BUY", 0, idx));
        }
        btn(g, 12, 226, 40, 14, "<", hidden ? 0xFF2C2C31 : 0xFF8E8E93, () -> shopPage--);
        Gfx.text(g, font, (shopPage + 1) + "/" + pages, W / 2, 229, sub(), 0.85f, true);
        btn(g, 98, 226, 40, 14, ">", hidden ? 0xFF2C2C31 : 0xFF8E8E93, () -> shopPage++);
    }

    // ---- hidden: odd jobs (six shifts) ---------------------------------------------------------
    private void jobs(GuiGraphics g) {
        header(g, "Работа");
        String j = ClientState.job;
        Gfx.card(g, 12, 50, 126, 40, 11, card());
        Gfx.text(g, font, "Подработка за наличные", 20, 58, ink(), 0.85f, false);
        if (j.startsWith("work")) {
            Gfx.text(g, font, "В процессе: " + j.substring(5) + " с", 20, 72, ORANGE, 0.9f, false);
            btn(g, 12, 100, 126, 20, "Проверить", BLUE, () -> send("JOB_COLLECT", 0, 0));
        } else if (j.startsWith("ready")) {
            Gfx.text(g, font, "Готово. Оплата " + PlayerFunds.fmt(Long.parseLong(j.substring(6))), 20, 72, GREEN, 0.9f, false);
            btn(g, 12, 100, 126, 20, "Забрать деньги", GREEN, () -> send("JOB_COLLECT", 0, 0));
        } else {
            Gfx.text(g, font, "Выбери смену", 20, 72, sub(), 0.85f, false);
            String[] names = {"Склад 20 с  ~€70", "Такси 25 с  ~€100", "Курьер 30 с  ~€115", "Грузчик 45 с  ~€160",
                    "Охрана 60 с  ~€205", "Ночная 90 с  ~€325"};
            int[] kinds = {2, 5, 0, 3, 4, 1};
            for (int i = 0; i < names.length; i++) {
                int k = kinds[i];
                btn(g, 12, 98 + i * 24, 126, 20, names[i], ACCENT, () -> send("JOB_START", 0, k));
            }
        }
    }
}
