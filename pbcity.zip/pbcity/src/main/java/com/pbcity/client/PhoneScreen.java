package com.pbcity.client;

import com.pbcity.econ.BitMarket;
import com.pbcity.econ.PlayerFunds;
import com.pbcity.econ.Shop;
import com.pbcity.net.ActionPacket;
import com.pbcity.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Phone UI drawn in local coordinates 0..150 x 0..290 and scaled to fit; slides up from the bottom-right
 * corner. Light mode: Bank, Wallet, Bit, Market, Casino. Hidden mode (Settings -> tap Build number 5 times):
 * Net (hack a network for DarkNet access), Orders, Black (shop), Cash (odd jobs).
 */
public class PhoneScreen extends Screen {
    private enum Page { HOME, BANK, WALLET, CASINO, SETTINGS, CONTRACTS, NET, BLACK, BIT, MARKET, JOBS }
    private record Hit(int x, int y, int w, int h, Runnable r) {}
    private record App(String name, String glyph, int color, Page page) {}

    private static final int W = 150, H = 290;
    private static final int BURGUNDY = 0xFF6B1230, RIM = 0xFF8C2A4A, ACCENT = 0xFF9B1B3C,
            GREEN = 0xFF30D158, BLUE = 0xFF0A84FF, GREY = 0xFF8E8E93;
    private static final long[] CHIPS = {5_000, 10_000, 50_000, 100_000};
    private static final String[] NETS = {"HomeNet_4F2A", "CafeGuest", "CityHall-Staff"};
    private static final int PER_PAGE = 5;

    private Page page = Page.HOME;
    private boolean hidden;
    private int taps, chip = 1, tab, pollTick, shopPage;
    private long lastTap, hackSeen;
    private long hackShownAt;
    private final StringBuilder entered = new StringBuilder();
    private final long openedAt = System.currentTimeMillis();
    private final List<Hit> hits = new ArrayList<>();
    private float scale = 1f;
    private int ox, oy;

    public PhoneScreen() { super(Component.literal("Phone")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() { send("SYNC", 0, 0); }

    private void send(String a, long amt, int arg) { Net.CH.sendToServer(new ActionPacket(a, amt, arg)); }

    @Override
    public void tick() {
        if (page == Page.CASINO && tab == 1 && ClientState.crashStatus == 1 && ++pollTick % 4 == 0)
            send("CRASH_POLL", 0, 0);
        if (page == Page.JOBS && ClientState.job.startsWith("work") && ++pollTick % 20 == 0) send("SYNC", 0, 0);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (PhoneKeys.OPEN.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        double lx = (mx - ox) / scale, ly = (my - oy) / scale;
        for (Hit h : hits) {
            if (lx >= h.x && lx < h.x + h.w && ly >= h.y && ly < h.y + h.h) { h.r.run(); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        hits.clear();
        double t = Math.min(1.0, (System.currentTimeMillis() - openedAt) / 260.0);
        double e = 1 - Math.pow(1 - t, 3);
        scale = Math.min(1f, (height - 10) / (float) H);
        ox = width - (int) (W * scale) - 10;
        int baseY = height - (int) (H * scale) - 5;
        oy = baseY + (int) ((1 - e) * (H * scale + 10));
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(scale, scale, 1f);
        draw(g);
        g.pose().popPose();
    }

    // ---- colours -------------------------------------------------------------------------------
    private int bg() { return hidden ? 0xFF0A0A0E : 0xFFF2F2F7; }
    private int card() { return hidden ? 0xFF1C1C21 : 0xFFFFFFFF; }
    private int ink() { return hidden ? 0xFFF2F2F7 : 0xFF111114; }

    private void draw(GuiGraphics g) {
        Gfx.rr(g, -1, -1, W + 2, H + 2, 24, RIM);
        Gfx.rr(g, 0, 0, W, H, 23, BURGUNDY);
        Gfx.rr(g, 5, 5, W - 10, H - 10, 18, bg());
        Gfx.rr(g, 55, 10, 40, 11, 5, 0xFF000000);
        LocalTime now = LocalTime.now();
        Gfx.text(g, font, String.format("%02d:%02d", now.getHour(), now.getMinute()), 16, 12, ink(), 0.9f, false);
        g.fill(118, 14, 130, 19, ink());
        g.fill(130, 15, 131, 18, ink());
        switch (page) {
            case HOME -> home(g);
            case BANK -> bank(g);
            case WALLET -> wallet(g);
            case CASINO -> casino(g);
            case SETTINGS -> settings(g);
            case CONTRACTS -> contracts(g);
            case NET -> net(g);
            case BLACK -> black(g);
            case BIT -> bit(g);
            case MARKET -> market(g);
            case JOBS -> jobs(g);
        }
        Gfx.rr(g, 55, 276, 40, 3, 1, ink());
        hits.add(new Hit(40, 270, 70, 14, () -> page = Page.HOME));
        long age = System.currentTimeMillis() - ClientState.toastAt;
        if (!ClientState.toast.isEmpty() && age < 3500) {
            int w = Math.min(130, font.width(ClientState.toast) + 14);
            Gfx.rr(g, (W - w) / 2, 256, w, 15, 7, 0xEE000000);
            Gfx.text(g, font, ClientState.toast, W / 2, 260, 0xFFFFFFFF, 0.8f, true);
        }
    }

    private void go(Page p) {
        page = p;
        send("SYNC", 0, 0);
    }

    private void header(GuiGraphics g, String title) {
        Gfx.text(g, font, "‹ Home", 14, 30, ACCENT, 0.9f, false);
        hits.add(new Hit(10, 26, 40, 14, () -> page = Page.HOME));
        Gfx.text(g, font, title, W / 2, 30, ink(), 1.1f, true);
    }

    private void btn(GuiGraphics g, int x, int y, int w, int h, String label, int fill, Runnable r) {
        Gfx.rr(g, x, y, w, h, 6, fill);
        Gfx.text(g, font, label, x + w / 2, y + (h - 7) / 2, 0xFFFFFFFF, 0.9f, true);
        hits.add(new Hit(x, y, w, h, r));
    }

    private void chips(GuiGraphics g, int y) {
        for (int i = 0; i < CHIPS.length; i++) {
            int x = 12 + i * 32, idx = i;
            boolean sel = i == chip;
            Gfx.rr(g, x, y, 29, 16, 8, sel ? ACCENT : card());
            Gfx.text(g, font, "€" + CHIPS[i] / 100, x + 14, y + 4, sel ? 0xFFFFFFFF : ink(), 0.8f, true);
            hits.add(new Hit(x, y, 29, 16, () -> chip = idx));
        }
    }

    private void locked(GuiGraphics g, String title) {
        header(g, title);
        Gfx.rr(g, 55, 100, 40, 40, 12, card());
        Gfx.text(g, font, "x", W / 2, 114, GREY, 1.6f, true);
        Gfx.text(g, font, "No DarkNet signal", W / 2, 150, GREY, 0.9f, true);
        Gfx.text(g, font, "Hack a network in Net", W / 2, 162, GREY, 0.75f, true);
    }

    // ---- home ----------------------------------------------------------------------------------
    private void home(GuiGraphics g) {
        App[] apps = hidden
                ? new App[]{new App("Net", "N", 0xFF1F6F3F, Page.NET), new App("Orders", "O", 0xFF8B0000, Page.CONTRACTS),
                        new App("Black", "X", 0xFF333333, Page.BLACK), new App("Cash", "E", 0xFF5A4B00, Page.JOBS),
                        new App("Settings", "S", 0xFF48484A, Page.SETTINGS)}
                : new App[]{new App("Bank", "$", 0xFF2E7D5B, Page.BANK), new App("Wallet", "W", 0xFF1C1C1E, Page.WALLET),
                        new App("Bit", "B", 0xFFF7931A, Page.BIT), new App("Market", "M", BLUE, Page.MARKET),
                        new App("Casino", "C", 0xFFB3122E, Page.CASINO), new App("Settings", "S", GREY, Page.SETTINGS)};
        for (int i = 0; i < apps.length; i++) {
            App a = apps[i];
            int x = 13 + (i % 4) * 33, y = 46 + (i / 4) * 46;
            Gfx.rr(g, x, y, 29, 29, 8, a.color);
            Gfx.text(g, font, a.glyph, x + 15, y + 10, 0xFFFFFFFF, 1.4f, true);
            Gfx.text(g, font, a.name, x + 15, y + 33, ink(), 0.65f, true);
            hits.add(new Hit(x, y, 29, 38, () -> go(a.page)));
        }
    }

    // ---- bank / wallet -------------------------------------------------------------------------
    private void bank(GuiGraphics g) {
        header(g, "Bank");
        Gfx.rr(g, 12, 48, 126, 66, 12, BURGUNDY);
        Gfx.text(g, font, "Balance", 22, 58, 0xFFE9B6C4, 0.8f, false);
        Gfx.text(g, font, PlayerFunds.fmt(ClientState.bank), 22, 70, 0xFFFFFFFF, 1.7f, false);
        Gfx.text(g, font, "Cash " + PlayerFunds.fmt(ClientState.cash), 22, 98, 0xFFE9B6C4, 0.85f, false);
        chips(g, 124);
        btn(g, 12, 150, 126, 20, "Deposit cash", GREEN, () -> send("DEPOSIT", CHIPS[chip], 0));
        btn(g, 12, 176, 126, 20, "Withdraw", BLUE, () -> send("WITHDRAW", CHIPS[chip], 0));
        Gfx.text(g, font, "ATM blocks: click = +€100, sneak-click = deposit all", W / 2, 206, GREY, 0.6f, true);
    }

    private void wallet(GuiGraphics g) {
        header(g, "Wallet");
        Gfx.rr(g, 12, 48, 126, 46, 10, card());
        Gfx.text(g, font, "Cash", 22, 56, GREY, 0.8f, false);
        Gfx.text(g, font, PlayerFunds.fmt(ClientState.cash), 22, 68, ink(), 1.4f, false);
        Gfx.rr(g, 12, 100, 126, 46, 10, card());
        Gfx.text(g, font, "Bank", 22, 108, GREY, 0.8f, false);
        Gfx.text(g, font, PlayerFunds.fmt(ClientState.bank), 22, 120, ink(), 1.4f, false);
        Gfx.rr(g, 12, 152, 126, 46, 10, card());
        Gfx.text(g, font, "BIT", 22, 160, GREY, 0.8f, false);
        double price = currentBitPrice();
        Gfx.text(g, font, String.format("%.5f", ClientState.bit), 22, 172, ink(), 1.2f, false);
        Gfx.text(g, font, "≈ " + PlayerFunds.fmt(Math.round(ClientState.bit * price * 100)), 22, 187, GREY, 0.75f, false);
    }

    // ---- BIT -----------------------------------------------------------------------------------
    private double currentBitPrice() {
        long t = net.minecraft.client.Minecraft.getInstance().level == null ? 0
                : net.minecraft.client.Minecraft.getInstance().level.getGameTime();
        return BitMarket.price(t);
    }

    private void bit(GuiGraphics g) {
        header(g, "Bit");
        long t = net.minecraft.client.Minecraft.getInstance().level == null ? 0
                : net.minecraft.client.Minecraft.getInstance().level.getGameTime();
        double price = BitMarket.price(t);
        Gfx.text(g, font, String.format("€%,.0f", price), 14, 46, 0xFFF7931A, 1.6f, false);
        double lo = Double.MAX_VALUE, hi = 0;
        double[] hist = new double[30];
        for (int i = 0; i < 30; i++) {
            hist[i] = BitMarket.price(t - (29 - i) * 600L);
            lo = Math.min(lo, hist[i]);
            hi = Math.max(hi, hist[i]);
        }
        Gfx.rr(g, 12, 66, 126, 40, 8, card());
        for (int i = 0; i < 30; i++) {
            int hh = 3 + (int) (30 * (hist[i] - lo) / Math.max(1, hi - lo));
            g.fill(16 + i * 4, 102 - hh, 19 + i * 4, 102, i == 29 ? 0xFFF7931A : 0xFF8E8E93);
        }
        Gfx.text(g, font, String.format("You hold %.5f BIT", ClientState.bit), 14, 112, GREY, 0.8f, false);
        chips(g, 126);
        btn(g, 12, 150, 126, 20, "Buy (from bank)", GREEN, () -> send("BIT_BUY", CHIPS[chip], 0));
        btn(g, 12, 176, 126, 20, "Sell (to bank)", BLUE, () -> send("BIT_SELL", CHIPS[chip], 0));
        Gfx.text(g, font, "Fee 1%. Price moves with game time.", W / 2, 206, GREY, 0.7f, true);
    }

    // ---- market --------------------------------------------------------------------------------
    private void market(GuiGraphics g) {
        header(g, "Market");
        Gfx.text(g, font, "Sell the item in your hand", 14, 46, GREY, 0.8f, false);
        btn(g, 12, 58, 126, 20, "Find a buyer", BLUE, () -> send("MARKET_OFFER", 0, 0));
        if (!ClientState.market.isEmpty()) {
            Gfx.rr(g, 12, 88, 126, 52, 10, card());
            String[] f = ClientState.market.split("\\|");
            Gfx.text(g, font, f[0].trim(), 20, 96, ink(), 0.9f, false);
            if (f.length > 1) Gfx.text(g, font, f[1].trim(), 20, 110, 0xFFFFB84D, 1f, false);
            if (f.length > 2) Gfx.text(g, font, f[2].trim(), 20, 124, GREY, 0.75f, false);
            btn(g, 12, 148, 60, 20, "Accept", GREEN, () -> send("MARKET_ACCEPT", 0, 0));
            btn(g, 78, 148, 60, 20, "Haggle", ACCENT, () -> send("MARKET_COUNTER", 0, 0));
        } else {
            Gfx.text(g, font, "Buyers pay up to ~60% of", W / 2, 100, GREY, 0.75f, true);
            Gfx.text(g, font, "the black-market price.", W / 2, 110, GREY, 0.75f, true);
        }
    }

    // ---- casino --------------------------------------------------------------------------------
    private void casino(GuiGraphics g) {
        header(g, "Casino");
        String[] tabs = {"Roulette", "Crash", "Slots"};
        for (int i = 0; i < 3; i++) {
            int x = 12 + i * 43, idx = i;
            Gfx.rr(g, x, 46, 40, 15, 7, i == tab ? ACCENT : card());
            Gfx.text(g, font, tabs[i], x + 20, 50, i == tab ? 0xFFFFFFFF : ink(), 0.8f, true);
            hits.add(new Hit(x, 46, 40, 15, () -> tab = idx));
        }
        Gfx.text(g, font, "Cash " + PlayerFunds.fmt(ClientState.cash), 14, 68, GREY, 0.8f, false);
        chips(g, 80);
        if (tab == 0) {
            btn(g, 12, 108, 60, 22, "Red x2", 0xFFB3122E, () -> send("ROULETTE", CHIPS[chip], 100));
            btn(g, 78, 108, 60, 22, "Black x2", 0xFF2C2C2E, () -> send("ROULETTE", CHIPS[chip], 101));
            btn(g, 12, 136, 126, 18, "Zero x36", 0xFF1F7A3F, () -> send("ROULETTE", CHIPS[chip], 102));
            Gfx.text(g, font, "European wheel, 37 pockets", W / 2, 164, GREY, 0.75f, true);
        } else if (tab == 2) {
            btn(g, 12, 112, 126, 26, "Spin", ACCENT, () -> send("SLOTS", CHIPS[chip], 0));
            Gfx.text(g, font, "3 of a kind pays x20", W / 2, 148, GREY, 0.8f, true);
            Gfx.text(g, font, "2 of a kind returns 90%", W / 2, 160, GREY, 0.8f, true);
        } else {
            int st = ClientState.crashStatus;
            double m = ClientState.mult;
            if (st == 1) m = ClientState.mult * Math.exp(0.09 * (System.currentTimeMillis() - ClientState.stamp) / 1000.0);
            int col = st == 2 ? 0xFFFF453A : st == 3 ? GREEN : ink();
            Gfx.text(g, font, String.format("x%.2f", Math.max(1.0, m)), W / 2, 112, col, 2.2f, true);
            int bar = (int) (126 * Math.min(1.0, Math.log(Math.max(1.0, m)) / Math.log(10)));
            Gfx.rr(g, 12, 140, 126, 6, 3, card());
            if (bar > 2) Gfx.rr(g, 12, 140, bar, 6, 3, col == ink() ? ACCENT : col);
            if (st == 1) btn(g, 12, 156, 126, 22, "Cash out", GREEN, () -> send("CRASH_CASH", 0, 0));
            else btn(g, 12, 156, 126, 22, "Start round", ACCENT, () -> send("CRASH_START", CHIPS[chip], 0));
            Gfx.text(g, font, "Cash out before it crashes", W / 2, 188, GREY, 0.75f, true);
        }
    }

    // ---- settings / hidden mode ----------------------------------------------------------------
    private void settings(GuiGraphics g) {
        header(g, "Settings");
        Gfx.rr(g, 12, 48, 126, 30, 10, card());
        Gfx.text(g, font, "iOS version", 22, 56, GREY, 0.8f, false);
        Gfx.text(g, font, "26.0.1", 22, 66, ink(), 1f, false);
        Gfx.rr(g, 12, 84, 126, 30, 10, card());
        Gfx.text(g, font, "Build number", 22, 92, GREY, 0.8f, false);
        Gfx.text(g, font, "23A5297m", 22, 102, ink(), 1f, false);
        hits.add(new Hit(12, 84, 126, 30, () -> {
            long now = System.currentTimeMillis();
            taps = now - lastTap < 1200 ? taps + 1 : 1;
            lastTap = now;
            if (taps >= 5) {
                taps = 0;
                hidden = !hidden;
                ClientState.toast = hidden ? "Hidden mode on" : "Hidden mode off";
                ClientState.toastAt = now;
            }
        }));
    }

    // ---- hidden: Net (hack minigame) -----------------------------------------------------------
    private void net(GuiGraphics g) {
        header(g, "Net");
        if (!ClientState.hackSeq.isEmpty()) {
            if (ClientState.hackStamp != hackSeen) {
                hackSeen = ClientState.hackStamp;
                hackShownAt = System.currentTimeMillis();
                entered.setLength(0);
            }
            if (System.currentTimeMillis() - hackShownAt < 3500) {
                Gfx.text(g, font, "Memorize", W / 2, 70, GREY, 1f, true);
                Gfx.text(g, font, ClientState.hackSeq, W / 2, 96, 0xFF30D158, 2.4f, true);
                return;
            }
            Gfx.text(g, font, "Enter the code", W / 2, 56, GREY, 1f, true);
            StringBuilder dots = new StringBuilder();
            for (int i = 0; i < ClientState.hackSeq.length(); i++) dots.append(i < entered.length() ? entered.charAt(i) : '_').append(' ');
            Gfx.text(g, font, dots.toString().trim(), W / 2, 74, ink(), 1.6f, true);
            for (int i = 0; i < 9; i++) {
                int x = 15 + (i % 3) * 42, y = 100 + (i / 3) * 30, d = i + 1;
                Gfx.rr(g, x, y, 36, 24, 8, card());
                Gfx.text(g, font, Integer.toString(d), x + 18, y + 8, ink(), 1.2f, true);
                hits.add(new Hit(x, y, 36, 24, () -> {
                    entered.append(d);
                    if (entered.length() >= ClientState.hackSeq.length()) {
                        long v = Long.parseLong(entered.toString());
                        entered.setLength(0);
                        ClientState.hackSeq = "";
                        send("HACK_SUBMIT", v, 0);
                    }
                }));
            }
            return;
        }
        long left = ClientState.darkSecondsLeft();
        Gfx.rr(g, 12, 46, 126, 22, 8, left > 0 ? 0xFF14361F : card());
        Gfx.text(g, font, left > 0 ? String.format("DarkNet open %d:%02d", left / 60, left % 60) : "DarkNet offline",
                W / 2, 53, left > 0 ? GREEN : GREY, 0.95f, true);
        Gfx.text(g, font, "Nearby networks", 14, 78, GREY, 0.8f, false);
        for (int i = 0; i < NETS.length; i++) {
            int y = 92 + i * 38, idx = i;
            Gfx.rr(g, 12, y, 126, 32, 8, card());
            Gfx.text(g, font, NETS[i], 20, y + 6, ink(), 0.9f, false);
            Gfx.text(g, font, "Code length " + (4 + i), 20, y + 18, GREY, 0.75f, false);
            btn(g, 100, y + 10, 34, 14, "Hack", 0xFF1F6F3F, () -> send("HACK_START", 0, idx));
        }
    }

    // ---- hidden: orders board ------------------------------------------------------------------
    private void contracts(GuiGraphics g) {
        if (ClientState.darkSecondsLeft() <= 0) { locked(g, "Orders"); return; }
        header(g, "Orders");
        int y = 46;
        for (String row : ClientState.contracts) {
            String[] f = row.split("\\|");
            if (f.length < 4) continue;
            int id = Integer.parseInt(f[0]);
            Gfx.rr(g, 10, y, 130, 36, 8, card());
            Gfx.text(g, font, f[1], 18, y + 5, ink(), 0.9f, false);
            Gfx.text(g, font, f[2] + "  " + PlayerFunds.fmt(Long.parseLong(f[3])), 18, y + 17, GREY, 0.75f, false);
            btn(g, 104, y + 20, 32, 12, "Take", 0xFF8B0000, () -> send("CONTRACT_ACCEPT", 0, id));
            y += 40;
        }
        if (!ClientState.active.isEmpty())
            Gfx.text(g, font, "Active: " + ClientState.active, W / 2, 246, 0xFFFF9F0A, 0.7f, true);
    }

    // ---- hidden: black market shop -------------------------------------------------------------
    private void black(GuiGraphics g) {
        if (ClientState.darkSecondsLeft() <= 0) { locked(g, "Black"); return; }
        header(g, "Black");
        int pages = (Shop.CATALOG.size() + PER_PAGE - 1) / PER_PAGE;
        shopPage = Math.max(0, Math.min(shopPage, pages - 1));
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = shopPage * PER_PAGE + i;
            if (idx >= Shop.CATALOG.size()) break;
            Shop.Entry e = Shop.CATALOG.get(idx);
            int y = 44 + i * 35;
            Gfx.rr(g, 10, y, 130, 31, 8, card());
            Gfx.text(g, font, e.label(), 18, y + 6, ink(), 0.9f, false);
            Gfx.text(g, font, PlayerFunds.fmt(e.cents()), 18, y + 18, GREY, 0.75f, false);
            btn(g, 102, y + 9, 34, 13, "Buy", 0xFF8B0000, () -> send("SHOP_BUY", 0, idx));
        }
        btn(g, 12, 224, 40, 14, "<", card(), () -> shopPage--);
        Gfx.text(g, font, (shopPage + 1) + "/" + pages, W / 2, 227, GREY, 0.85f, true);
        btn(g, 98, 224, 40, 14, ">", card(), () -> shopPage++);
    }

    // ---- hidden: odd jobs ----------------------------------------------------------------------
    private void jobs(GuiGraphics g) {
        header(g, "Cash");
        String j = ClientState.job;
        Gfx.rr(g, 12, 48, 126, 50, 10, card());
        Gfx.text(g, font, "Odd job: courier shift", 20, 56, ink(), 0.9f, false);
        if (j.startsWith("work")) {
            Gfx.text(g, font, "In progress: " + j.substring(5) + " s", 20, 72, 0xFFFF9F0A, 0.9f, false);
            btn(g, 12, 108, 126, 20, "Check", BLUE, () -> send("JOB_COLLECT", 0, 0));
        } else if (j.startsWith("ready")) {
            Gfx.text(g, font, "Done. Pay " + PlayerFunds.fmt(Long.parseLong(j.substring(6))), 20, 72, GREEN, 0.9f, false);
            btn(g, 12, 108, 126, 20, "Collect cash", GREEN, () -> send("JOB_COLLECT", 0, 0));
        } else {
            Gfx.text(g, font, "Pick a shift, paid in cash", 20, 72, GREY, 0.85f, false);
            btn(g, 12, 108, 126, 20, "Warehouse 20 s  ~€70", ACCENT, () -> send("JOB_START", 0, 2));
            btn(g, 12, 134, 126, 20, "Courier 30 s  ~€115", ACCENT, () -> send("JOB_START", 0, 0));
            btn(g, 12, 160, 126, 20, "Night shift 90 s  ~€325", ACCENT, () -> send("JOB_START", 0, 1));
        }
    }
}
