package com.pbcity.client;

import com.pbcity.PBCity;
import com.pbcity.npc.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.CITY_NPC.get(), CityNpcRenderer::new);
    }

    /** Models that no item references directly: the device renderer draws them itself. */
    @SubscribeEvent
    public static void models(ModelEvent.RegisterAdditional e) {
        e.register(DeviceRenderer.RF_BODY);
        e.register(DeviceRenderer.RF_RING);
        e.register(DeviceRenderer.WM_BODY);
        e.register(DeviceRenderer.WM_BLADES);
        e.register(DeviceRenderer.LG_BODY);
    }
}
