package com.pbcity.client;

import com.mojang.math.Axis;
import com.pbcity.ballistics.Ballistics;
import com.pbcity.ballistics.WindManager;
import com.pbcity.config.PBConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Handheld weather / ballistics meter in the style of a Kestrel Elite: spinning impeller on top, LCD,
 * three small keys and a D-pad. Up/Down switch pages, Left/Right change range on the ballistic page,
 * the left key cycles units, the red key holds the reading, the right key toggles the backlight.
 */
final class WindMeterScreen extends DeviceScreen {
    private static final int KEY = 0xFF3A3A40, RED = 0xFFD72323, ORANGE = 0xFFE65014, INK = 0xFF1E1C16;
    private static final String[] PAGES = {"WIND", "BALLISTIC", "ENV", "TIME"};
    private static final String[] UNITS = {"m/s", "km/h", "mph", "kt"};
    private static final double[] UF = {1.0, 3.6, 2.23694, 1.94384};

    private boolean on = true, light, hold, link;
    private int page, unit, range = 300, logs;
    private String[] frozen;

    WindMeterScreen() { super("Wind meter"); }

    @Override int dw() { return 100; }
    @Override int dh() { return 232; }

    private static String compass(double deg) {
        String[] n = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        return n[(int) Math.floorMod(Math.round(deg / 45.0), 8L)];
    }

    private String[] lines() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return new String[]{"", "", "", ""};
        Vec3 wind = WindManager.wind(mc.level);
        Vec3 look = mc.player.getLookAngle();
        Vec3 lh = new Vec3(look.x, 0, look.z).normalize();
        Vec3 right = new Vec3(-lh.z, 0, lh.x);
        double spd = wind.horizontalDistance() * UF[unit];
        switch (page) {
            case 0 -> {
                double toward = Math.toDegrees(Math.atan2(wind.x, -wind.z));
                double from = (toward + 180 + 360) % 360;
                return new String[]{String.format("WIND %.1f %s", spd, UNITS[unit]),
                        String.format("FROM %s %03.0f", compass(from), from),
                        String.format("XWIND %+.1f", wind.dot(right) * UF[unit]),
                        String.format("HWIND %+.1f", wind.dot(lh) * UF[unit])};
            }
            case 1 -> {
                List<Vec3> pts = Ballistics.trajectory(Vec3.ZERO, lh, range, wind,
                        PBConfig.MUZZLE_VELOCITY.get(), PBConfig.DRAG_K.get());
                Vec3 p = pts.get(pts.size() - 1);
                double drift = p.dot(right);
                return new String[]{"RNG " + range + " m", String.format("DROP %.2f m", -p.y),
                        String.format("DRIFT %s%.2f m", drift >= 0 ? "R" : "L", Math.abs(drift)),
                        String.format("TOF %.2f s", (pts.size() - 1) * Ballistics.DT)};
            }
            case 2 -> {
                float base = mc.level.getBiome(mc.player.blockPosition()).value().getBaseTemperature();
                double y = mc.player.getY();
                int hum = mc.level.isThundering() ? 95 : mc.level.isRaining() ? 85 : 45;
                double pres = 1013 - (y - 64) * 0.12 - (mc.level.isRaining() ? 8 : 0);
                return new String[]{String.format("TEMP %.0f C", base * 22.0), "HUM " + hum + " %",
                        String.format("PRES %.0f hPa", pres), String.format("ALT %.0f m", y)};
            }
            default -> {
                long dt = mc.level.getDayTime();
                long t = dt % 24000L;
                int h = (int) ((t / 1000 + 6) % 24), m = (int) ((t % 1000) * 60 / 1000);
                String w = mc.level.isThundering() ? "STORM" : mc.level.isRaining() ? "RAIN" : "CLEAR";
                return new String[]{String.format("TIME %02d:%02d", h, m), "DAY " + (dt / 24000L), w, "LOG " + logs};
            }
        }
    }

    @Override
    void drawDevice(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        double wspd = mc.level == null ? 0 : WindManager.wind(mc.level).horizontalDistance();
        Gfx.rr(g, -3, 27, 106, 206, 20, 0xFF2A2A2E);
        Gfx.rr(g, 0, 30, 100, 200, 17, 0xFF141416);
        Gfx.rr(g, 8, 0, 84, 62, 31, 0xFF141416);
        Gfx.rr(g, 14, 5, 72, 52, 26, 0xFF0B0B0D);
        // spinning impeller: faster in stronger wind
        g.pose().pushPose();
        g.pose().translate(50, 31, 0);
        g.pose().mulPose(Axis.ZP.rotation((float) (System.currentTimeMillis() / 1000.0 * wspd * 1.5)));
        for (int i = 0; i < 5; i++) {
            g.pose().mulPose(Axis.ZP.rotation((float) (Math.PI * 2 / 5)));
            g.fill(1, -22, 8, 0, 0xFFC8C8CE);
        }
        g.pose().popPose();
        g.fill(46, 27, 55, 36, 0xFF8A8A92);

        Gfx.rr(g, 10, 68, 80, 78, 6, 0xFF26262B);
        int glass = !on ? 0xFF0D1014 : light ? 0xFFE9DDA6 : 0xFFCEC096;
        Gfx.rr(g, 14, 72, 72, 70, 3, glass);
        if (on) {
            String[] l = hold && frozen != null ? frozen : lines();
            for (int i = 0; i < 4; i++) Gfx.text(g, font, l[i], 18, 78 + i * 14, INK, 0.95f, false);
            Gfx.text(g, font, PAGES[page] + (hold ? "  HOLD" : "") + (link ? "  LINK" : ""), 18, 133, INK, 0.65f, false);
            if (page == 1) Gfx.text(g, font, "< > range", 62, 133, INK, 0.6f, false);
        }
        key(g, 12, 152, 24, 13, "UNIT", KEY, 0xFFFFFFFF, 0.6f, () -> unit = (unit + 1) % UNITS.length);
        key(g, 38, 152, 24, 13, hold ? "FREE" : "HOLD", RED, 0xFFFFFFFF, 0.6f, () -> {
            hold = !hold;
            frozen = hold ? lines() : null;
        });
        key(g, 64, 152, 24, 13, "LIGHT", KEY, 0xFFFFFFFF, 0.6f, () -> light = !light);
        key(g, 38, 169, 24, 14, "^", KEY, 0xFFFFFFFF, 1.0f, () -> { page = (page + PAGES.length - 1) % PAGES.length; hold = false; });
        key(g, 38, 203, 24, 14, "v", KEY, 0xFFFFFFFF, 1.0f, () -> { page = (page + 1) % PAGES.length; hold = false; });
        key(g, 12, 184, 24, 18, "<", KEY, 0xFFFFFFFF, 1.0f, () -> { if (page == 1) range = Math.max(50, range - 50); });
        key(g, 64, 184, 24, 18, ">", KEY, 0xFFFFFFFF, 1.0f, () -> { if (page == 1) range = Math.min(1500, range + 50); });
        key(g, 38, 184, 24, 18, "OK", 0xFF6A6A72, 0xFFFFFFFF, 0.8f, () -> logs++);
        key(g, 10, 218, 20, 12, on ? "PWR" : "ON", KEY, 0xFFFFFFFF, 0.6f, () -> { on = !on; if (!on) hold = false; });
        key(g, 66, 218, 24, 12, "LINK", ORANGE, 0xFFFFFFFF, 0.6f, () -> link = !link);
    }
}
