package com.pbcity.client;

import com.pbcity.npc.CityNpc;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CityNpcRenderer extends HumanoidMobRenderer<CityNpc, HumanoidModel<CityNpc>> {
    private static final ResourceLocation[] SKINS = {
            new ResourceLocation("textures/entity/player/wide/steve.png"),
            new ResourceLocation("textures/entity/player/wide/kai.png"),
            new ResourceLocation("textures/entity/player/wide/noor.png"),
            new ResourceLocation("textures/entity/player/wide/sunny.png"),
            new ResourceLocation("textures/entity/player/wide/zuri.png")};

    public CityNpcRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(CityNpc e) {
        return SKINS[Math.floorMod(e.getUUID().hashCode(), SKINS.length)];
    }
}
