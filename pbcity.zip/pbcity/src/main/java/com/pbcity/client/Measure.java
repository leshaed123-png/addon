package com.pbcity.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Client-side laser measurement along the crosshair, plus target speed tracking. */
final class Measure {
    record Result(double dist, Entity target, double pitch) {}

    private static int lastId = -1;
    private static Vec3 lastPos = Vec3.ZERO;
    private static long lastTick = -1;
    private static double ema = 0;

    private Measure() {}

    static Result take(Minecraft mc, double maxR) {
        Entity cam = mc.getCameraEntity();
        if (cam == null || mc.level == null) return new Result(-1, null, 0);
        Vec3 eye = cam.getEyePosition(1f);
        Vec3 look = cam.getViewVector(1f);
        Vec3 end = eye.add(look.scale(maxR));
        BlockHitResult b = mc.level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, cam));
        double d = b.getType() == HitResult.Type.MISS ? -1 : b.getLocation().distanceTo(eye);
        double lim = d < 0 ? maxR : d;
        AABB box = cam.getBoundingBox().expandTowards(look.scale(lim)).inflate(1.0);
        EntityHitResult e = ProjectileUtil.getEntityHitResult(cam, eye, end, box,
                en -> !en.isSpectator() && en.isPickable(), lim * lim);
        Entity t = null;
        if (e != null) { d = e.getLocation().distanceTo(eye); t = e.getEntity(); }
        return new Result(d, t, -cam.getXRot());
    }

    /** Smoothed speed (m/s) of the tracked target; call every frame with the current target. */
    static double speed(Minecraft mc, Entity target) {
        if (mc.level == null) return 0;
        long now = mc.level.getGameTime();
        if (target == null) { lastId = -1; ema *= 0.8; return ema < 0.05 ? 0 : ema; }
        if (target.getId() != lastId) {
            lastId = target.getId(); lastPos = target.position(); lastTick = now; ema = 0;
            return 0;
        }
        if (now > lastTick) {
            double inst = target.position().subtract(lastPos).length() / ((now - lastTick) * 0.05);
            ema = ema * 0.7 + inst * 0.3;
            lastPos = target.position(); lastTick = now;
        }
        return ema;
    }
}
