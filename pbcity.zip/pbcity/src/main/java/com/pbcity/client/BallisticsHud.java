package com.pbcity.client;

import com.mojang.math.Axis;
import com.pbcity.ballistics.Ballistics;
import com.pbcity.ballistics.WindManager;
import com.pbcity.config.PBConfig;
import com.pbcity.item.RangefinderItem;
import com.pbcity.item.WindMeterItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** On-screen readouts: range / target speed / drop / flight time (rangefinder), wind speed, direction, crosswind. */
public final class BallisticsHud {
    private static final int BG = 0xCC0B0D10, EDGE = 0xFF2C3138, LABEL = 0xFF8A93A0,
            VALUE = 0xFFE8EAED, ACCENT = 0xFFFFB84D, GOOD = 0xFF7BD88F;

    private static int lastId = -1;
    private static Vec3 lastPos = Vec3.ZERO;
    private static long lastTick = -1;
    private static double speedEma = 0;

    private BallisticsHud() {}

    private static Item held(Player p) {
        Item[] hands = {p.getMainHandItem().getItem(), p.getOffhandItem().getItem()};
        for (Item i : hands)
            if (i instanceof RangefinderItem || i instanceof WindMeterItem) return i;
        return null;
    }

    public static void render(Minecraft mc, GuiGraphics g, float pt, int w, int h) {
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        Item dev = held(mc.player);
        if (dev == null) return;
        Font f = mc.font;
        Entity cam = mc.getCameraEntity();
        if (cam == null) return;

        Vec3 look = cam.getViewVector(pt);
        Vec3 wind = WindManager.wind(mc.level);
        double wspd = wind.horizontalDistance();
        Vec3 lh = new Vec3(look.x, 0, look.z).normalize();
        Vec3 right = new Vec3(-lh.z, 0, lh.x);
        double cross = wind.dot(right);   // + = blowing toward the shooter's right
        double head = wind.dot(lh);       // + = tailwind
        double rel = Math.atan2(wind.z, wind.x) - Math.atan2(lh.z, lh.x);

        boolean range = dev instanceof RangefinderItem;
        int pw = 132, ph = range ? 74 : 40;
        int x = w / 2 + 28, y = h / 2 - ph / 2;
        panel(g, x, y, pw, ph);

        if (range) {
            reticle(g, w / 2, h / 2);
            double maxR = PBConfig.MAX_RANGE.get();
            Vec3 eye = cam.getEyePosition(pt);
            Vec3 end = eye.add(look.scale(maxR));
            BlockHitResult bhr = mc.level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, cam));
            double d = bhr.getType() == HitResult.Type.MISS ? -1 : bhr.getLocation().distanceTo(eye);
            double lim = d < 0 ? maxR : d;
            AABB box = cam.getBoundingBox().expandTowards(look.scale(lim)).inflate(1.0);
            EntityHitResult ehr = ProjectileUtil.getEntityHitResult(cam, eye, end, box,
                    en -> !en.isSpectator() && en.isPickable(), lim * lim);
            Entity target = null;
            if (ehr != null) { d = ehr.getLocation().distanceTo(eye); target = ehr.getEntity(); }

            double tgtSpeed = trackSpeed(mc, target);
            double v0 = PBConfig.MUZZLE_VELOCITY.get(), k = PBConfig.DRAG_K.get();

            label(g, f, "RNG", x + 6, y + 6);
            if (d < 0) value(g, f, "----", x + 6, y + 16, LABEL, 1.6f);
            else value(g, f, String.format("%.1f m", d), x + 6, y + 16, ACCENT, 1.6f);

            if (d > 0) {
                double drop = Ballistics.dropAt(d, v0, k);
                double tof = Ballistics.flightTime(d, v0, k);
                double mil = Math.toDegrees(Math.atan2(drop, d)) * 17.4533;
                label(g, f, "DROP", x + 6, y + 36);
                value(g, f, String.format("%.2f m  %.1f mil", drop, mil), x + 36, y + 36, VALUE, 1f);
                label(g, f, "TOF", x + 6, y + 47);
                value(g, f, String.format("%.2f s", tof), x + 36, y + 47, VALUE, 1f);
            }
            label(g, f, "TGT", x + 6, y + 58);
            value(g, f, String.format("%.1f m/s", tgtSpeed), x + 36, y + 58, target == null ? LABEL : GOOD, 1f);
            windBlock(g, f, x + pw - 38, y + 8, wspd, cross, head, rel, true);
        } else {
            windBlock(g, f, x + 6, y + 6, wspd, cross, head, rel, false);
        }
    }

    private static void windBlock(GuiGraphics g, Font f, int x, int y, double spd, double cross, double head,
                                  double rel, boolean compact) {
        g.pose().pushPose();
        g.pose().translate(x + 14, y + (compact ? 12 : 14), 0);
        g.pose().mulPose(Axis.ZP.rotation((float) rel));
        arrow(g);
        g.pose().popPose();
        if (compact) {
            value(g, f, String.format("%.1f", spd), x + 4, y + 26, VALUE, 1f);
            return;
        }
        label(g, f, "WIND", x + 34, y);
        value(g, f, String.format("%.1f m/s", spd), x + 34, y + 10, ACCENT, 1.3f);
        label(g, f, "X", x + 34, y + 24);
        value(g, f, String.format("%+.1f", cross), x + 44, y + 24, VALUE, 1f);
        label(g, f, "H", x + 74, y + 24);
        value(g, f, String.format("%+.1f", head), x + 84, y + 24, VALUE, 1f);
    }

    private static double trackSpeed(Minecraft mc, Entity target) {
        long now = mc.level.getGameTime();
        if (target == null) { lastId = -1; speedEma *= 0.8; return speedEma < 0.05 ? 0 : speedEma; }
        if (target.getId() != lastId) {
            lastId = target.getId(); lastPos = target.position(); lastTick = now; speedEma = 0;
            return 0;
        }
        if (now > lastTick) {
            double inst = target.position().subtract(lastPos).length() / ((now - lastTick) * 0.05);
            speedEma = speedEma * 0.7 + inst * 0.3;
            lastPos = target.position(); lastTick = now;
        }
        return speedEma;
    }

    private static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, EDGE);
        g.fill(x, y, x + w, y + h, BG);
        g.fill(x, y, x + 2, y + h, ACCENT);
    }

    private static void reticle(GuiGraphics g, int cx, int cy) {
        int c = 0xCCFFFFFF;
        g.fill(cx - 14, cy, cx - 4, cy + 1, c);
        g.fill(cx + 4, cy, cx + 14, cy + 1, c);
        g.fill(cx, cy - 14, cx + 1, cy - 4, c);
        g.fill(cx, cy + 4, cx + 1, cy + 14, c);
        g.fill(cx, cy, cx + 1, cy + 1, 0xFFFF3B3B);
    }

    private static void arrow(GuiGraphics g) {
        g.fill(-1, -4, 1, 9, ACCENT);
        for (int i = 0; i < 6; i++) g.fill(-i, -10 + i, i + 1, -9 + i, ACCENT);
    }

    private static void label(GuiGraphics g, Font f, String s, int x, int y) {
        g.drawString(f, s, x, y, LABEL, false);
    }

    private static void value(GuiGraphics g, Font f, String s, int x, int y, int color, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.drawString(f, s, 0, 0, color, false);
        g.pose().popPose();
    }
}
