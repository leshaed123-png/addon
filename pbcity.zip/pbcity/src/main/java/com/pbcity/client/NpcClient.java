package com.pbcity.client;

import com.pbcity.net.NpcReplyPacket;
import net.minecraft.client.Minecraft;

public final class NpcClient {
    private NpcClient() {}

    public static void apply(NpcReplyPacket m) {
        Minecraft mc = Minecraft.getInstance();
        NpcDialogueScreen s;
        if (mc.screen instanceof NpcDialogueScreen d && d.npcId == m.npcId()) {
            s = d;
        } else {
            s = new NpcDialogueScreen(m.npcId(), m.name());
            mc.setScreen(s);
        }
        s.onReply(m);
    }
}
