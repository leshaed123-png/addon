package com.pbcity.client;

import com.pbcity.config.PBConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * Laser distance meter, modelled on a handheld DIST-50 style unit: LCD on top, orange band, keypad below.
 * READ measures along the crosshair. Modes: DIST, AREA (two lengths), SPD (target speed), ANG (pitch).
 */
final class RangefinderScreen extends DeviceScreen {
    private static final int ORANGE = 0xFFE65014, INK = 0xFF1C2A55, LCD = 0xFFA9CBE3, KEY = 0xFF3A3A40, RED = 0xFFD72323;
    private static final String[] MODES = {"DIST", "AREA", "SPD", "ANG"};

    private boolean on = true, yards, beep = true;
    private int mode, saved;
    private double mem, pitch;
    private final List<Double> hist = new ArrayList<>();

    RangefinderScreen() { super("Rangefinder"); }

    @Override int dw() { return 110; }
    @Override int dh() { return 192; }

    private void read() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        on = true;
        Measure.Result r = Measure.take(mc, PBConfig.MAX_RANGE.get());
        pitch = r.pitch();
        double v = switch (mode) {
            case 0, 1 -> Math.max(0, r.dist());
            case 2 -> Measure.speed(mc, r.target());
            default -> r.pitch();
        };
        hist.add(v);
        while (hist.size() > 3) hist.remove(0);
    }

    private double big() {
        if (hist.isEmpty()) return 0;
        double last = hist.get(hist.size() - 1);
        if (mode == 1) return hist.size() >= 2 ? last * hist.get(hist.size() - 2) : 0;
        return last;
    }

    private String fmt(double v) {
        double f = (mode <= 1 && yards) ? (mode == 1 ? 1.19599 : 1.09361) : 1.0;
        return String.format("%.2f", v * f);
    }

    private String unit() {
        return switch (mode) {
            case 0 -> yards ? "yd" : "m";
            case 1 -> yards ? "yd2" : "m2";
            case 2 -> "m/s";
            default -> "deg";
        };
    }

    @Override
    void drawDevice(GuiGraphics g) {
        Gfx.rr(g, -3, -3, 116, 198, 17, 0xFF2A2A2E);
        Gfx.rr(g, 0, 0, 110, 192, 14, 0xFF141416);
        Gfx.rr(g, 2, 104, 106, 12, 4, ORANGE);
        Gfx.rr(g, 11, 9, 88, 90, 6, 0xFF26262B);
        Gfx.rr(g, 15, 13, 80, 82, 3, on ? LCD : 0xFF0D1014);
        if (on) {
            Gfx.text(g, font, MODES[mode], 19, 17, INK, 0.8f, false);
            textR(g, String.format("%.1f°", pitch), 91, 17, INK, 0.8f);
            if (mem != 0) Gfx.text(g, font, "M", 19, 27, INK, 0.7f, false);
            if (beep) Gfx.text(g, font, "))", 33, 27, INK, 0.7f, false);
            if (saved > 0) Gfx.text(g, font, "S" + saved, 47, 27, INK, 0.7f, false);
            g.fill(72, 28, 91, 31, INK);
            int n = hist.size();
            int first = mode == 1 ? 2 : 3;
            for (int i = 0; i < first - 1; i++) {
                int idx = n - first + i;
                if (idx >= 0 && idx < n) {
                    textR(g, fmt(hist.get(idx)), 80, 36 + i * 14, INK, 1.0f);
                    textR(g, unit(), 91, 38 + i * 14, INK, 0.6f);
                }
            }
            textR(g, hist.isEmpty() ? "----" : fmt(big()), 82, 70, INK, 1.7f);
            textR(g, unit(), 91, 82, INK, 0.7f);
            if (mem != 0) textR(g, "M " + fmt(mem), 91, 88, INK, 0.6f);
        }
        key(g, 14, 126, 22, 20, "+", KEY, 0xFFFFFFFF, 1.2f, () -> { if (on) mem += big(); });
        key(g, 42, 121, 26, 26, "READ", RED, 0xFFFFFFFF, 0.7f, this::read);
        key(g, 74, 126, 22, 20, beep ? "VOL" : "MUTE", KEY, 0xFFFFFFFF, 0.6f, () -> beep = !beep);
        key(g, 14, 151, 38, 16, "AREA", KEY, 0xFFFFFFFF, 0.8f, () -> { mode = (mode + 1) % MODES.length; hist.clear(); });
        key(g, 58, 151, 38, 16, "SAVE", KEY, 0xFFFFFFFF, 0.8f, () -> { if (on && !hist.isEmpty()) saved++; });
        key(g, 14, 171, 38, 16, "U", KEY, 0xFFFFFFFF, 0.8f, () -> yards = !yards);
        key(g, 58, 171, 38, 16, "CLR", KEY, 0xFFFFFFFF, 0.8f, () -> {
            if (!hist.isEmpty() || mem != 0) { hist.clear(); mem = 0; } else on = !on;
        });
        key(g, 40, 108, 30, 8, "M-", 0xFF8A2A0A, 0xFFFFFFFF, 0.6f, () -> { if (on) mem -= big(); });
    }
}
