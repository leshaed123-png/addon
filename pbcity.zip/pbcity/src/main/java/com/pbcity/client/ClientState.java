package com.pbcity.client;

import com.pbcity.net.StatePacket;

import java.util.List;

/** Latest server state for the phone UI (client side only). */
public final class ClientState {
    public static long cash, bank;
    public static String toast = "";
    public static long toastAt;
    public static List<String> contracts = List.of();
    public static String active = "";
    public static int crashStatus;
    public static double mult = 1.0;
    public static long stamp;

    private ClientState() {}

    public static void apply(StatePacket m) {
        cash = m.cash();
        bank = m.bank();
        if (!m.toast().isEmpty()) { toast = m.toast(); toastAt = System.currentTimeMillis(); }
        contracts = m.contracts();
        active = m.active();
        crashStatus = m.crashStatus();
        mult = m.mult();
        stamp = System.currentTimeMillis();
    }
}
