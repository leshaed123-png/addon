package com.pbcity.client;

import com.pbcity.net.StatePacket;

import java.util.List;

/** Latest server state for the phone UI (client side only). */
public final class ClientState {
    public static long cash, bank, darkLeft;
    public static String toast = "", active = "", hackSeq = "", market = "", job = "idle";
    public static long toastAt, stamp, hackStamp;
    public static List<String> contracts = List.of();
    public static int crashStatus;
    public static double mult = 1.0, bit;

    private ClientState() {}

    public static void apply(StatePacket m) {
        cash = m.cash();
        bank = m.bank();
        if (!m.toast().isEmpty()) { toast = m.toast(); toastAt = System.currentTimeMillis(); }
        contracts = m.contracts();
        active = m.active();
        crashStatus = m.crashStatus();
        mult = m.mult();
        darkLeft = m.darkLeft();
        bit = m.bit();
        market = m.market();
        job = m.job();
        if (!m.hack().isEmpty()) { hackSeq = m.hack(); hackStamp = System.currentTimeMillis(); }
        stamp = System.currentTimeMillis();
    }

    /** Remaining darknet seconds, counted down locally between server updates. */
    public static long darkSecondsLeft() {
        return Math.max(0, darkLeft - (System.currentTimeMillis() - stamp) / 1000);
    }
}
