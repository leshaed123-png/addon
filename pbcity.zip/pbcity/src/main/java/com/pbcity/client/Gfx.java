package com.pbcity.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Small drawing helpers: rounded rectangles and scaled / centred text. */
final class Gfx {
    private Gfx() {}

    static void rr(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int dy = 0; dy < h; dy++) {
            int d = dy < r ? r - dy : (dy >= h - r ? dy - (h - r) + 1 : 0);
            int inset = 0;
            if (d > 0) {
                double yy = d - 0.5;
                inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - yy * yy)));
            }
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, c);
        }
    }

    static void text(GuiGraphics g, Font f, String s, int x, int y, int color, float scale, boolean center) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1f);
        int w = f.width(s);
        g.drawString(f, s, center ? -w / 2 : 0, 0, color, false);
        g.pose().popPose();
    }
}
