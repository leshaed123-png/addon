package com.pbcity.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/** Base for handheld device screens: drawn in local coordinates, scaled to fit, buttons are hit-tested. */
abstract class DeviceScreen extends Screen {
    protected record Hit(int x, int y, int w, int h, Runnable r) {}

    protected final List<Hit> hits = new ArrayList<>();
    protected float scale = 1f;
    protected int ox, oy;

    protected DeviceScreen(String title) { super(Component.literal(title)); }

    abstract int dw();
    abstract int dh();
    abstract void drawDevice(GuiGraphics g);

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        hits.clear();
        scale = Math.min(1.7f, (height - 24) / (float) dh());
        ox = width - (int) (dw() * scale) - 24;
        oy = (height - (int) (dh() * scale)) / 2;
        int cx = width / 2, cy = height / 2, c = 0xAAFFFFFF;
        g.fill(cx - 12, cy, cx - 4, cy + 1, c);
        g.fill(cx + 4, cy, cx + 12, cy + 1, c);
        g.fill(cx, cy - 12, cx + 1, cy - 4, c);
        g.fill(cx, cy + 4, cx + 1, cy + 12, c);
        g.fill(cx, cy, cx + 1, cy + 1, 0xFFFF3B3B);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(scale, scale, 1f);
        drawDevice(g);
        g.pose().popPose();
        Gfx.text(g, font, "Esc - close", 8, height - 14, 0xFF8A93A0, 0.9f, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        double lx = (mx - ox) / scale, ly = (my - oy) / scale;
        for (Hit h : hits) {
            if (lx >= h.x && lx < h.x + h.w && ly >= h.y && ly < h.y + h.h) { h.r.run(); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    protected void clickSound() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    protected void key(GuiGraphics g, int x, int y, int w, int h, String label, int fill, int txt, float ts, Runnable r) {
        Gfx.rr(g, x, y, w, h, Math.min(6, h / 2), fill);
        Gfx.text(g, font, label, x + w / 2, y + (int) ((h - 8 * ts) / 2) + 1, txt, ts, true);
        hits.add(new Hit(x, y, w, h, () -> { clickSound(); r.run(); }));
    }

    protected void textR(GuiGraphics g, String s, int xr, int y, int color, float sc) {
        Gfx.text(g, font, s, xr - (int) (font.width(s) * sc), y, color, sc, false);
    }
}
