package com.pbcity;

import com.pbcity.block.ModBlocks;
import com.pbcity.config.PBConfig;
import com.pbcity.item.ModItems;
import com.pbcity.net.Net;
import com.pbcity.npc.CityNpc;
import com.pbcity.npc.ModEntities;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(PBCity.MODID)
public class PBCity {
    public static final String MODID = "pbcity";

    public PBCity() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        bus.addListener(PBCity::addCreative);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::init));
        bus.addListener((EntityAttributeCreationEvent e) -> e.put(ModEntities.CITY_NPC.get(), CityNpc.attrs().build()));
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, PBConfig.SPEC);
    }

    private static void addCreative(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            e.accept(ModItems.RANGEFINDER);
            e.accept(ModItems.WIND_METER);
            e.accept(ModItems.ENVELOPE);
            e.accept(ModItems.PACKAGE);
            e.accept(ModItems.COCAINE);
            e.accept(ModItems.MEPHEDRONE);
            e.accept(ModItems.CRYSTALS);
            e.accept(ModItems.WEED);
            e.accept(ModBlocks.ATM_ITEM);
        }
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(ModItems.NPC_EGG);
    }
}
