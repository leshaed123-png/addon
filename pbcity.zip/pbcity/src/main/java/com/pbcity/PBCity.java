package com.pbcity;

import com.pbcity.config.PBConfig;
import com.pbcity.item.ModItems;
import com.pbcity.net.Net;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(PBCity.MODID)
public class PBCity {
    public static final String MODID = "pbcity";

    public PBCity() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        bus.addListener(PBCity::addCreative);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::init));
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, PBConfig.SPEC);
    }

    private static void addCreative(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            e.accept(ModItems.RANGEFINDER);
            e.accept(ModItems.WIND_METER);
        }
    }
}
