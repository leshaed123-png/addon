package com.pbcity.voice;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Minimal WAV (PCM 16-bit) reader: downmix to mono and resample to 48 kHz; pitch > 1 = higher voice. */
final class Wav {
    private Wav() {}

    static short[] to48kMono(byte[] wav, double pitch) {
        ByteBuffer b = ByteBuffer.wrap(wav).order(ByteOrder.LITTLE_ENDIAN);
        if (wav.length < 44 || b.getInt(0) != 0x46464952) return new short[0]; // "RIFF"
        int pos = 12, channels = 1, rate = 24000, bits = 16, dataOff = -1, dataLen = 0;
        while (pos + 8 <= wav.length) {
            int id = b.getInt(pos), len = b.getInt(pos + 4);
            if (id == 0x20746d66) { // "fmt "
                channels = b.getShort(pos + 10);
                rate = b.getInt(pos + 12);
                bits = b.getShort(pos + 22);
            } else if (id == 0x61746164) { // "data"
                dataOff = pos + 8;
                dataLen = len < 0 || dataOff + len > wav.length ? wav.length - dataOff : len;
                break;
            }
            pos += 8 + len + (len & 1);
        }
        if (dataOff < 0 || bits != 16 || channels < 1) return new short[0];
        int frames = dataLen / (2 * channels);
        double[] mono = new double[frames];
        for (int i = 0; i < frames; i++) {
            double s = 0;
            for (int c = 0; c < channels; c++) s += b.getShort(dataOff + (i * channels + c) * 2);
            mono[i] = s / channels;
        }
        double step = rate * pitch / 48000.0; // source samples per output sample
        int outLen = (int) (frames / step);
        short[] out = new short[outLen];
        for (int i = 0; i < outLen; i++) {
            double p = i * step;
            int i0 = (int) p;
            double f = p - i0;
            double a = mono[i0], c = i0 + 1 < frames ? mono[i0 + 1] : a;
            out[i] = (short) Math.max(-32768, Math.min(32767, a + (c - a) * f));
        }
        return out;
    }

    static byte[] wav16(byte[] pcm, int rate) {
        ByteBuffer o = ByteBuffer.allocate(44 + pcm.length).order(ByteOrder.LITTLE_ENDIAN);
        o.putInt(0x46464952).putInt(36 + pcm.length).putInt(0x45564157).putInt(0x20746d66).putInt(16)
                .putShort((short) 1).putShort((short) 1).putInt(rate).putInt(rate * 2).putShort((short) 2).putShort((short) 16)
                .putInt(0x61746164).putInt(pcm.length).put(pcm);
        return o.array();
    }
}
