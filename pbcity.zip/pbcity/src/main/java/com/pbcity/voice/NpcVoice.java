package com.pbcity.voice;

import com.pbcity.config.PBConfig;
import com.pbcity.npc.CityNpc;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.fml.ModList;

/** Safe facade: NPC speech does nothing unless Simple Voice Chat is installed and voice.ttsUrl is set. */
public final class NpcVoice {
    private NpcVoice() {}

    public static boolean available() {
        return ModList.get().isLoaded("voicechat") && !PBConfig.TTS_URL.get().isEmpty();
    }

    public static void speak(ServerLevel level, CityNpc npc, String text) {
        if (!available() || text == null || text.isBlank()) return;
        try {
            SvcBridge.speak(level, npc, text);
        } catch (Throwable t) {
            // voice chat API missing or incompatible: stay silent, chat text still works
        }
    }
}
