package com.pbcity.voice;

import com.google.gson.JsonParser;
import com.pbcity.PBCity;
import com.pbcity.config.PBConfig;
import com.pbcity.npc.NpcService;
import de.maxhenkel.voicechat.api.ForgeVoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import de.maxhenkel.voicechat.api.events.VoicechatServerStartedEvent;
import de.maxhenkel.voicechat.api.opus.OpusDecoder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Voice input: your microphone (Simple Voice Chat) -> speech-to-text service (voice.sttUrl) -> the same NPC dialogue
 * as typed chat. The phrase is collected until ~0.7 s of silence. Needs a resident in front of you, called by name,
 * or an active phone call.
 */
@ForgeVoicechatPlugin
public class CityVoicePlugin implements VoicechatPlugin {
    private static final class Buf { final ByteArrayOutputStream pcm = new ByteArrayOutputStream(); long last; OpusDecoder dec; ServerPlayer player; }
    private final Map<UUID, Buf> bufs = new ConcurrentHashMap<>();
    private final ScheduledExecutorService sched = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "pbcity-stt"); t.setDaemon(true); return t; });
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();
    private volatile de.maxhenkel.voicechat.api.VoicechatServerApi api;

    @Override public String getPluginId() { return PBCity.MODID; }
    @Override public void initialize(VoicechatApi a) { }

    @Override
    public void registerEvents(EventRegistration reg) {
        reg.registerEvent(VoicechatServerStartedEvent.class, e -> { api = e.getVoicechat(); SvcBridge.api = e.getVoicechat(); });
        reg.registerEvent(MicrophonePacketEvent.class, this::onMic);
        sched.scheduleAtFixedRate(this::flush, 400, 150, TimeUnit.MILLISECONDS);
    }

    private void onMic(MicrophonePacketEvent e) {
        if (api == null || e.getSenderConnection() == null || PBConfig.STT_URL.get().isEmpty()) return;
        Object o = e.getSenderConnection().getPlayer().getPlayer();
        if (!(o instanceof ServerPlayer sp)) return;
        byte[] opus = e.getPacket().getOpusEncodedData();
        if (opus == null || opus.length == 0) return;
        Buf b = bufs.computeIfAbsent(sp.getUUID(), k -> { Buf nb = new Buf(); nb.dec = api.createDecoder(); nb.player = sp; return nb; });
        short[] pcm = b.dec.decode(opus);
        synchronized (b) {
            for (short s : pcm) { b.pcm.write(s & 0xFF); b.pcm.write((s >> 8) & 0xFF); }
            b.last = System.currentTimeMillis();
        }
    }

    private void flush() {
        long now = System.currentTimeMillis();
        for (Buf b : bufs.values()) {
            byte[] data;
            synchronized (b) {
                if (b.pcm.size() == 0 || now - b.last < 700) continue;
                data = b.pcm.toByteArray(); b.pcm.reset();
            }
            if (data.length < 48000 * 2 / 2) continue; // < 0.5 s: noise
            stt(b.player, Wav.wav16(data, 48000));
        }
    }

    private void stt(ServerPlayer p, byte[] wav) {
        try {
            HttpRequest.Builder rb = HttpRequest.newBuilder(URI.create(PBConfig.STT_URL.get())).timeout(Duration.ofSeconds(20))
                    .header("Content-Type", "audio/wav");
            if (!PBConfig.TTS_KEY.get().isEmpty()) rb.header("Authorization", "Bearer " + PBConfig.TTS_KEY.get());
            HttpResponse<String> r = http.send(rb.POST(HttpRequest.BodyPublishers.ofByteArray(wav)).build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() / 100 != 2) return;
            String text = JsonParser.parseString(r.body()).getAsJsonObject().get("text").getAsString().trim();
            if (text.length() < 2) return;
            p.getServer().execute(() -> {
                p.sendSystemMessage(Component.literal("<" + p.getGameProfile().getName() + "> " + text));
                NpcService.onChat(p, text);
            });
        } catch (Exception ignored) { }
    }
}
