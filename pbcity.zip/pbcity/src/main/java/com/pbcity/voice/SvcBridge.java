package com.pbcity.voice;

import com.pbcity.config.PBConfig;
import com.pbcity.npc.CityNpc;
import com.google.gson.JsonObject;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.audiochannel.AudioPlayer;
import de.maxhenkel.voicechat.api.audiochannel.LocationalAudioChannel;
import net.minecraft.server.level.ServerLevel;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Speaks an NPC line through Simple Voice Chat as a positional sound at the NPC.
 * Each NPC gets a fixed voice id (UUID hash) sent to the TTS service, plus a small pitch offset so even a
 * single-voice TTS gives every resident a different timbre.
 */
final class SvcBridge {
    static volatile VoicechatServerApi api;
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "pbcity-tts"); t.setDaemon(true); return t; });

    private SvcBridge() {}

    static void speak(ServerLevel level, CityNpc npc, String text) {
        VoicechatServerApi a = api;
        if (a == null) return;
        int voice = Math.floorMod(npc.getUUID().hashCode(), PBConfig.VOICE_COUNT.get());
        double pitch = 0.90 + Math.floorMod(npc.getUUID().getLeastSignificantBits(), 25L) / 100.0; // 0.90 .. 1.14
        double x = npc.getX(), y = npc.getEyeY(), z = npc.getZ();
        String clean = text.replaceAll("[\\r\\n]+", " ").replaceAll("\\(.*?\\)", "").trim();
        if (clean.isEmpty()) return;
        POOL.execute(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("text", clean);
                body.addProperty("voice", voice);
                body.addProperty("lang", "ru");
                HttpRequest.Builder rb = HttpRequest.newBuilder(URI.create(PBConfig.TTS_URL.get()))
                        .timeout(Duration.ofSeconds(30)).header("Content-Type", "application/json");
                if (!PBConfig.TTS_KEY.get().isEmpty()) rb.header("Authorization", "Bearer " + PBConfig.TTS_KEY.get());
                HttpResponse<byte[]> r = HTTP.send(rb.POST(HttpRequest.BodyPublishers.ofString(body.toString())).build(),
                        HttpResponse.BodyHandlers.ofByteArray());
                if (r.statusCode() / 100 != 2) return;
                short[] pcm = Wav.to48kMono(r.body(), pitch);
                if (pcm.length == 0) return;
                LocationalAudioChannel ch = a.createLocationalAudioChannel(UUID.randomUUID(), a.fromServerLevel(level), a.createPosition(x, y, z));
                if (ch == null) return;
                ch.setDistance(24f);
                final int[] pos = {0};
                AudioPlayer pl = a.createAudioPlayer(ch, a.createEncoder(), () -> {
                    if (pos[0] >= pcm.length) return null;
                    short[] frame = new short[960];
                    int n = Math.min(960, pcm.length - pos[0]);
                    System.arraycopy(pcm, pos[0], frame, 0, n);
                    pos[0] += 960;
                    return frame;
                });
                pl.startPlaying();
            } catch (Exception ignored) { }
        });
    }
}
