package com.pbcity.npc;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;

/** Minimal OpenAI-compatible chat call. Returns null on any problem so the caller can fall back. */
public final class LlmClient {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    private LlmClient() {}

    public static String chat(String url, String key, String model, String system, List<String[]> history) {
        if (url == null || url.isBlank() || key == null || key.isBlank()) return null;
        try {
            JsonObject root = new JsonObject();
            root.addProperty("model", model);
            root.addProperty("max_tokens", 120);
            JsonArray msgs = new JsonArray();
            JsonObject sys = new JsonObject();
            sys.addProperty("role", "system");
            sys.addProperty("content", system);
            msgs.add(sys);
            for (String[] h : history) {
                JsonObject m = new JsonObject();
                m.addProperty("role", h[0]);
                m.addProperty("content", h[1]);
                msgs.add(m);
            }
            root.add("messages", msgs);
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(12))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + key)
                    .POST(HttpRequest.BodyPublishers.ofString(root.toString()))
                    .build();
            HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() != 200) return null;
            JsonObject j = JsonParser.parseString(res.body()).getAsJsonObject();
            String out = j.getAsJsonArray("choices").get(0).getAsJsonObject()
                    .getAsJsonObject("message").get("content").getAsString().trim();
            return out.isEmpty() ? null : out;
        } catch (Exception e) {
            return null;
        }
    }
}
