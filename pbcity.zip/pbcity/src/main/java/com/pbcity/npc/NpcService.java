package com.pbcity.npc;

import com.pbcity.config.PBConfig;
import com.pbcity.econ.PlayerFunds;
import com.pbcity.item.EnvelopeItem;
import com.pbcity.item.GoodsItem;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * NPC conversations happen in the normal Minecraft chat, in Russian by default. An NPC answers when it is
 * addressed by name (from any distance), when a phone call to it is active, or when it is in front of the player.
 * Deals use /npc inspect | haggle | accept | refuse on the resident in front of you.
 */
public final class NpcService {
    private static final Map<String, List<String[]>> HIST = new HashMap<>();
    private static final Map<UUID, Long> LAST_CHAT = new HashMap<>();
    private static final Set<UUID> PENDING = new HashSet<>();
    private static final Random RNG = new Random();
    public static final double FRONT_RANGE = 8.0;

    private NpcService() {}

    // ---- output: everything an NPC says goes to the chat of nearby players and of the addressed player ----
    public static void say(ServerLevel sl, CityNpc n, ServerPlayer target, String text) {
        Component msg = Component.literal("<" + n.npcName() + "> ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE));
        for (ServerPlayer o : sl.players())
            if (o == target || o.distanceToSqr(n) < 48 * 48) o.sendSystemMessage(msg);
        com.pbcity.voice.NpcVoice.speak(sl, n, text);
    }

    private static void say(ServerPlayer p, CityNpc n, String text) { say((ServerLevel) p.level(), n, p, text); }

    // ---- who is the player talking to ------------------------------------------------------------
    public static CityNpc nearestInFront(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        CityNpc best = null;
        double bestD = Double.MAX_VALUE;
        for (CityNpc n : p.level().getEntitiesOfClass(CityNpc.class, p.getBoundingBox().inflate(range))) {
            Vec3 to = n.getEyePosition().subtract(eye);
            double d = to.length();
            if (d > range || d < 1e-3) continue;
            if (to.normalize().dot(look) < 0.6) continue;
            if (d < bestD) { best = n; bestD = d; }
        }
        return best;
    }

    private static String stem(String first) {
        String f = first.toLowerCase(Locale.ROOT);
        return f.length() >= 5 ? f.substring(0, f.length() - 1) : f;
    }

    private static CityNpc findByName(ServerLevel sl, String lowerMsg) {
        for (Entity e : sl.getAllEntities()) {
            if (!(e instanceof CityNpc c)) continue;
            String first = c.npcName().split(" ")[0];
            if (first.length() >= 3 && lowerMsg.contains(stem(first))) return c;
        }
        return null;
    }

    // ---- chat front-end --------------------------------------------------------------------------
    public static void onChat(ServerPlayer p, String raw) {
        ServerLevel sl = (ServerLevel) p.level();
        CityNpc n = null;
        String call = PlayerFunds.tag(p).getString("callNpc");
        if (!call.isEmpty()) {
            try { if (sl.getEntity(UUID.fromString(call)) instanceof CityNpc c) n = c; } catch (IllegalArgumentException ignored) { }
        }
        if (n == null) n = findByName(sl, raw.toLowerCase(Locale.ROOT));
        if (n == null) n = nearestInFront(p, FRONT_RANGE);
        if (n == null) return;
        long now = System.currentTimeMillis();
        if (now - LAST_CHAT.getOrDefault(p.getUUID(), 0L) < 1500 || PENDING.contains(p.getUUID())) return;
        LAST_CHAT.put(p.getUUID(), now);
        meet(p, n);
        if (n.distanceToSqr(p) < 100) { n.getNavigation().stop(); n.getLookControl().setLookAt(p); }
        ask(p, n, raw);
    }

    public static void greet(ServerPlayer p, CityNpc n) {
        meet(p, n);
        n.getNavigation().stop();
        n.getLookControl().setLookAt(p);
        String line;
        if (n.dealOpen() && n.getRole() == CityNpc.Role.DEALER)
            line = "Здорово. Есть " + n.goodsRu() + ", цена " + PlayerFunds.fmt(n.price())
                    + ". Глянуть: /npc inspect, торг: /npc haggle, беру: /npc accept.";
        else if (n.dealOpen() && n.wantsGoods())
            line = "Мне нужен " + n.goodsRu() + ", дам " + PlayerFunds.fmt(n.price())
                    + ". Принёс? Проверить деньги: /npc inspect, отдать: /npc accept.";
        else if (n.dealOpen())
            line = "Есть тёмная работёнка за " + PlayerFunds.fmt(n.price())
                    + ". Деньги глянуть: /npc inspect, согласен: /npc accept.";
        else {
            String[] hi = {"Чего тебе?", "Ну привет.", "Чё надо?", "Слушаю."};
            line = hi[RNG.nextInt(hi.length)];
        }
        say(p, n, line);
    }

    /** /npc inspect | haggle | accept | refuse */
    public static void chatAction(ServerPlayer p, String kind) {
        CityNpc n = nearestInFront(p, FRONT_RANGE);
        if (n == null) {
            p.sendSystemMessage(Component.literal("Перед тобой никого нет.").withStyle(ChatFormatting.RED));
            return;
        }
        meet(p, n);
        n.getNavigation().stop();
        switch (kind) {
            case "INSPECT" -> inspect(p, n);
            case "HAGGLE" -> haggle(p, n);
            case "ACCEPT" -> accept(p, n);
            case "REFUSE" -> say(p, n, n.dealOpen() ? "Твоё дело. Знаешь, где меня найти." : "Давай, не болей.");
            default -> { }
        }
    }

    // ---- contacts / phone calls / SMS ------------------------------------------------------------
    private static void meet(ServerPlayer p, CityNpc n) {
        CompoundTag t = PlayerFunds.tag(p);
        ListTag l = t.getList("contacts", 8);
        String id = n.getUUID().toString();
        for (int i = 0; i < l.size(); i++) if (l.getString(i).startsWith(id)) return;
        if (l.size() >= 12) l.remove(0);
        l.add(StringTag.valueOf(id + "|" + n.npcName() + "|" + roleRu(n)));
        t.put("contacts", l);
    }

    private static String roleRu(CityNpc n) {
        return switch (n.getRole()) { case DEALER -> "барыга"; case BUYER -> "заказчик"; default -> "знакомый"; };
    }

    public static String contactsString(ServerPlayer p) {
        CompoundTag t = PlayerFunds.tag(p);
        ListTag l = t.getList("contacts", 8);
        String call = t.getString("callNpc");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            String[] f = l.getString(i).split("\\|");
            if (f.length < 3) continue;
            if (sb.length() > 0) sb.append(';');
            sb.append(f[1]).append('|').append(f[2]).append('|').append(f[0].equals(call) ? 1 : 0);
        }
        return sb.toString();
    }

    public static String call(ServerPlayer p, int idx) {
        CompoundTag t = PlayerFunds.tag(p);
        ListTag l = t.getList("contacts", 8);
        if (idx < 0 || idx >= l.size()) return "Контакт не найден";
        String[] f = l.getString(idx).split("\\|");
        t.putString("callNpc", f[0]);
        ServerLevel sl = (ServerLevel) p.level();
        try {
            if (sl.getEntity(UUID.fromString(f[0])) instanceof CityNpc n) say(p, n, "Да? Слушаю тебя.");
        } catch (IllegalArgumentException ignored) { }
        return "Звонок: " + f[1] + ". Пиши в чат";
    }

    public static String hangup(ServerPlayer p) {
        PlayerFunds.tag(p).putString("callNpc", "");
        return "Звонок завершён";
    }

    /** Called every 10 s per player: now and then a contact writes first, like a text message. */
    public static void maybeSms(ServerLevel sl, ServerPlayer p) {
        if (RNG.nextInt(100) >= 4) return;
        ListTag l = PlayerFunds.tag(p).getList("contacts", 8);
        if (l.isEmpty()) return;
        String[] f = l.getString(RNG.nextInt(l.size())).split("\\|");
        try {
            if (!(sl.getEntity(UUID.fromString(f[0])) instanceof CityNpc n) || n.done()) return;
            String[] dealer = {"Есть свежий товар. Звони, если надо.", "Подвезли партию. Цена хорошая.", "Не тяни, разберут."};
            String[] buyer = {"Есть клиент, деньги готовы. Выходи на связь.", "Дело есть. Позвони.", "Ты пропал. Жду ответ."};
            String[] civ = {"Привет! Как жизнь?", "Давно не виделись. Заходи.", "Слышал, в городе неспокойно."};
            String[] a = n.getRole() == CityNpc.Role.DEALER ? dealer : n.getRole() == CityNpc.Role.BUYER ? buyer : civ;
            p.sendSystemMessage(Component.literal("[SMS] <" + n.npcName() + "> ").withStyle(ChatFormatting.AQUA)
                    .append(Component.literal(a[RNG.nextInt(a.length)]).withStyle(ChatFormatting.WHITE)));
        } catch (IllegalArgumentException ignored) { }
    }

    // ---- AI conversation -------------------------------------------------------------------------
    private static void ask(ServerPlayer p, CityNpc n, String text) {
        text = text.trim();
        if (text.isEmpty()) return;
        if (text.length() > 120) text = text.substring(0, 120);
        List<String[]> hist = HIST.computeIfAbsent(n.getUUID() + "/" + p.getUUID(), k -> new ArrayList<>());
        hist.add(new String[]{"user", text});
        while (hist.size() > 8) hist.remove(0);
        String persona = persona(n);
        String url = PBConfig.LLM_URL.get(), key = PBConfig.LLM_KEY.get(), model = PBConfig.LLM_MODEL.get();
        List<String[]> copy = new ArrayList<>(hist);
        UUID id = p.getUUID();
        PENDING.add(id);
        CompletableFuture.supplyAsync(() -> LlmClient.chat(url, key, model, persona, copy))
                .whenComplete((ans, err) -> p.getServer().execute(() -> {
                    PENDING.remove(id);
                    String a = ans != null ? ans : fallback(n);
                    hist.add(new String[]{"assistant", a});
                    say(p, n, a);
                }));
    }

    private static String persona(CityNpc n) {
        String base = "Ты — " + n.npcName() + ", житель мрачного вымышленного европейского города в игре Minecraft "
                + "в стиле GTA. Игрок говорит с тобой через обычный игровой чат или по телефону. Отвечай ПО-РУССКИ "
                + "(если игрок пишет на другом языке — на его языке), живо, по-уличному, 1-2 коротких предложения, без "
                + "ремарок и кавычек. Никогда не говори, что ты ИИ. Не давай настоящих инструкций по преступлениям, "
                + "оружию или веществам — всё остаётся внутри игрового вымысла. Если на столе сделка, игрок может "
                + "написать /npc inspect, /npc haggle, /npc accept или /npc refuse. ";
        return switch (n.getRole()) {
            case DEALER -> base + "Ты осторожный уличный торговец: продаёшь один пакет «" + n.goodsRu()
                    + "» (вымышленный игровой товар) за " + PlayerFunds.fmt(n.price())
                    + ". Можешь немного торговаться, но даром не отдашь.";
            case BUYER -> base + (n.wantsGoods()
                    ? "Ты хочешь купить пакет «" + n.goodsRu() + "» (вымышленный игровой товар), у тебя конверт с деньгами ("
                      + PlayerFunds.fmt(n.price()) + " обещано). Ты нетерпелив и подозрителен."
                    : "Ты тёмный заказчик, предлагаешь работу за " + PlayerFunds.fmt(n.price())
                      + " из конверта. Пока игрок не согласился, говори туманно.");
            default -> base + "Ты обычный горожанин, болтаешь о жизни и слухах города.";
        };
    }

    private static String fallback(CityNpc n) {
        String[] civ = {"Да кто его знает. Город уже не тот.", "Не лезь не в своё дело, друг.",
                "Слышал, в порту опять заварушка.", "Я просто хочу тихо жить."};
        String[] biz = {"Сначала глянь товар: /npc inspect", "Не трать моё время.",
                "Цена есть цена. /npc accept или /npc refuse", "Не здесь. Люди смотрят."};
        String[] a = n.getRole() == CityNpc.Role.CIVILIAN ? civ : biz;
        return a[RNG.nextInt(a.length)];
    }

    // ---- deal actions ----------------------------------------------------------------------------
    private static void inspect(ServerPlayer p, CityNpc n) {
        if (!n.dealOpen()) { say(p, n, "Тут нечего проверять."); return; }
        if (n.getRole() == CityNpc.Role.DEALER) {
            Random r = new Random(n.getUUID().getLeastSignificantBits());
            p.sendSystemMessage(Component.literal("Ты вскрываешь пакет (" + n.goodsRu() + "): " + (8 + r.nextInt(25))
                    + " ед., качество ~" + (50 + r.nextInt(50)) + "%.").withStyle(ChatFormatting.GRAY));
        } else {
            p.sendSystemMessage(Component.literal("Ты пересчитываешь купюры: " + PlayerFunds.fmt(n.actual())
                    + (n.actual() < n.price() ? " - меньше обещанных " + PlayerFunds.fmt(n.price()) + "." : ".")).withStyle(ChatFormatting.GRAY));
            if (n.actual() < n.price()) say(p, n, "Чего уставился? Пересчитай ещё раз.");
        }
    }

    private static void haggle(ServerPlayer p, CityNpc n) {
        if (!n.dealOpen()) return;
        if (n.haggled()) { say(p, n, "Это моё последнее слово. Берёшь или нет?"); return; }
        n.setHaggled(true);
        boolean ok = RNG.nextBoolean();
        boolean dealer = n.getRole() == CityNpc.Role.DEALER;
        n.scale(dealer ? (ok ? 0.85 : 1.05) : (ok ? 1.15 : 0.95));
        say(p, n, (ok ? "Ладно... Так лучше, но это край. " : "Борзеешь. Теперь хуже. ") + "(" + n.offerInfo() + ")");
    }

    private static void accept(ServerPlayer p, CityNpc n) {
        if (!n.dealOpen()) { say(p, n, "Нечего принимать."); return; }
        if (n.getRole() == CityNpc.Role.DEALER) {
            if (PlayerFunds.cash(p) < n.price()) { say(p, n, "У тебя не хватает налички."); return; }
            PlayerFunds.setCash(p, PlayerFunds.cash(p) - n.price());
            Random r = new Random(n.getUUID().getLeastSignificantBits());
            give(p, GoodsItem.of(n.goodsItem(), 8 + r.nextInt(25), 50 + r.nextInt(50)));
            n.setDone(true);
            say(p, n, "Приятно иметь дело. Моё лицо забудь.");
        } else if (n.wantsGoods()) {
            ItemStack pkg = findGoods(p, n.goodsItem());
            if (pkg == null) { say(p, n, "Где товар (" + n.goodsRu() + ")? Вернёшься с ним."); return; }
            pkg.shrink(1);
            give(p, EnvelopeItem.of(n.actual()));
            n.setDone(true);
            say(p, n, "Хорошо. Мы не встречались.");
        } else {
            CompoundTag t = PlayerFunds.tag(p);
            if (!t.getString("targetUuid").isEmpty()) { say(p, n, "У тебя уже есть открытое дело."); return; }
            ServerLevel sl = (ServerLevel) p.level();
            List<CityNpc> pool = sl.getEntitiesOfClass(CityNpc.class, p.getBoundingBox().inflate(300),
                    c -> c != n && c.getRole() == CityNpc.Role.CIVILIAN && !c.marked());
            if (pool.isEmpty()) { say(p, n, "Сейчас никто не подходит. Загляни позже."); return; }
            CityNpc target = pool.get(RNG.nextInt(pool.size()));
            target.markFor(p.getUUID().toString());
            int tx = (int) target.getX() / 50 * 50, tz = (int) target.getZ() / 50 * 50;
            t.putString("targetUuid", target.getUUID().toString());
            t.putString("active", target.npcName() + " - последний раз видели у " + tx + ", " + tz);
            t.putLong("bonus", n.price() / 2);
            give(p, EnvelopeItem.of(n.actual()));
            n.setDone(true);
            say(p, n, "Зовут " + target.npcName() + ", район около " + tx + ", " + tz + ". Бонус после дела.");
        }
    }

    private static ItemStack findGoods(ServerPlayer p, Item item) {
        for (ItemStack s : p.getInventory().items) if (s.is(item)) return s;
        return null;
    }

    private static void give(ServerPlayer p, ItemStack s) {
        if (!p.getInventory().add(s)) p.drop(s, false);
    }
}
