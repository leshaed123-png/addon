package com.pbcity.npc;

import com.pbcity.config.PBConfig;
import com.pbcity.econ.PlayerFunds;
import com.pbcity.item.EnvelopeItem;
import com.pbcity.item.ModItems;
import com.pbcity.item.GoodsItem;
import com.pbcity.net.Net;
import com.pbcity.net.NpcReplyPacket;
import com.pbcity.net.NpcSayPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Server authority for NPC meetings. Two front-ends share the same logic:
 * the dialogue screen (right-click) and plain Minecraft chat (look at a resident and type).
 */
public final class NpcService {
    private static final Map<String, List<String[]>> HIST = new HashMap<>();
    private static final Map<UUID, Long> LAST_CHAT = new HashMap<>();
    private static final Set<UUID> PENDING = new HashSet<>();
    private static final Random RNG = new Random();
    public static final double CHAT_RANGE = 6.0;

    private NpcService() {}

    // ---- finding who the player is talking to --------------------------------------------------
    public static CityNpc nearestInFront(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        CityNpc best = null;
        double bestD = Double.MAX_VALUE;
        for (CityNpc n : p.level().getEntitiesOfClass(CityNpc.class, p.getBoundingBox().inflate(range))) {
            Vec3 to = n.getEyePosition().subtract(eye);
            double d = to.length();
            if (d > range || d < 1e-3) continue;
            if (to.normalize().dot(look) < 0.6) continue;   // roughly in front of the player
            if (d < bestD) { best = n; bestD = d; }
        }
        return best;
    }

    // ---- chat front-end ------------------------------------------------------------------------
    private static Consumer<String> chatOut(ServerPlayer p, CityNpc n) {
        return line -> p.sendSystemMessage(Component.literal("<" + n.npcName() + "> ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(line).withStyle(ChatFormatting.WHITE)));
    }

    /** Called for every chat message; returns without effect if nobody is in front of the player. */
    public static void onChat(ServerPlayer p, String raw) {
        CityNpc n = nearestInFront(p, CHAT_RANGE);
        if (n == null) return;
        long now = System.currentTimeMillis();
        if (now - LAST_CHAT.getOrDefault(p.getUUID(), 0L) < 1500 || PENDING.contains(p.getUUID())) return;
        LAST_CHAT.put(p.getUUID(), now);
        n.getNavigation().stop();
        n.getLookControl().setLookAt(p);
        ask(p, n, raw, chatOut(p, n));
    }

    /** /npc inspect | haggle | accept | refuse */
    public static void chatAction(ServerPlayer p, String kind) {
        CityNpc n = nearestInFront(p, CHAT_RANGE);
        if (n == null) {
            p.sendSystemMessage(Component.literal("Nobody in front of you.").withStyle(ChatFormatting.RED));
            return;
        }
        n.getNavigation().stop();
        action(p, n, kind, chatOut(p, n));
    }

    // ---- dialogue-screen front-end -------------------------------------------------------------
    public static void open(ServerPlayer p, CityNpc n) {
        n.getNavigation().stop();
        send(p, n, greeting(n), true);
    }

    public static void handle(ServerPlayer p, NpcSayPacket m) {
        if (!(p.level().getEntity(m.npcId()) instanceof CityNpc n) || n.distanceToSqr(p) > 64) return;
        String text = m.text() == null ? "" : m.text().trim();
        Consumer<String> out = line -> send(p, n, line, false);
        if (m.kind().equals("SAY")) ask(p, n, text, out);
        else action(p, n, m.kind(), out);
    }

    // ---- shared logic --------------------------------------------------------------------------
    private static void ask(ServerPlayer p, CityNpc n, String text, Consumer<String> out) {
        text = text.trim();
        if (text.isEmpty()) return;
        if (text.length() > 120) text = text.substring(0, 120);
        List<String[]> hist = HIST.computeIfAbsent(n.getUUID() + "/" + p.getUUID(), k -> new ArrayList<>());
        hist.add(new String[]{"user", text});
        while (hist.size() > 8) hist.remove(0);
        String persona = persona(n);
        String url = PBConfig.LLM_URL.get(), key = PBConfig.LLM_KEY.get(), model = PBConfig.LLM_MODEL.get();
        List<String[]> copy = new ArrayList<>(hist);
        UUID id = p.getUUID();
        PENDING.add(id);
        CompletableFuture.supplyAsync(() -> LlmClient.chat(url, key, model, persona, copy))
                .whenComplete((ans, err) -> p.getServer().execute(() -> {
                    PENDING.remove(id);
                    String a = ans != null ? ans : fallback(n);
                    hist.add(new String[]{"assistant", a});
                    out.accept(a);
                }));
    }

    private static void action(ServerPlayer p, CityNpc n, String kind, Consumer<String> out) {
        switch (kind) {
            case "INSPECT" -> inspect(n, out);
            case "HAGGLE" -> haggle(n, out);
            case "ACCEPT" -> accept(p, n, out);
            case "REFUSE" -> out.accept(n.dealOpen() ? "Your loss. You know where to find me." : "Take care.");
            default -> { }
        }
    }

    private static String persona(CityNpc n) {
        String base = "You play " + n.npcName() + ", a resident of a gritty fictional European city in a GTA-style "
                + "Minecraft game. The player talks to you through the normal game chat. Stay in character, reply in "
                + "the SAME language as the player, 1-2 short sentences, no stage directions, never mention being an "
                + "AI, never give real-world instructions for crimes or weapons - keep everything inside the game "
                + "fiction. If a deal is on the table, the player can type /npc inspect, /npc haggle, /npc accept or "
                + "/npc refuse. ";
        return switch (n.getRole()) {
            case DEALER -> base + "You are a cautious street dealer selling one bag of " + n.goodsName() + " (a fictional in-game trade good) for "
                    + PlayerFunds.fmt(n.price()) + ". You may haggle a little but never give the package away.";
            case BUYER -> base + (n.wantsGoods()
                    ? "You want to buy a bag of " + n.goodsName() + " (fictional in-game trade good) and carry an envelope with cash (" + PlayerFunds.fmt(n.price())
                      + " promised). You are impatient and suspicious."
                    : "You are a shady client offering an under-the-table job for " + PlayerFunds.fmt(n.price())
                      + ", paid from an envelope. Be vague about details until the player accepts.");
            default -> base + "You are an ordinary citizen making small talk, mentioning gossip about the city.";
        };
    }

    private static String greeting(CityNpc n) {
        return switch (n.getRole()) {
            case DEALER -> n.done() ? "We're done here. Walk away." : "You the one who texted? Keep it quick.";
            case BUYER -> n.done() ? "Deal's done. Don't call me again." : "Finally. You have what I need?";
            default -> "Yeah? What do you want?";
        };
    }

    private static String fallback(CityNpc n) {
        String[] civ = {"Hard to say. The city isn't what it was.", "Mind your own business, friend.",
                "Heard there was trouble down by the harbour.", "I just want a quiet life."};
        String[] biz = {"Look at the goods, then decide. /npc inspect", "Don't waste my time.",
                "Price is the price. /npc accept or /npc refuse", "Not here. People are watching."};
        String[] a = n.getRole() == CityNpc.Role.CIVILIAN ? civ : biz;
        return a[RNG.nextInt(a.length)];
    }

    private static void inspect(CityNpc n, Consumer<String> out) {
        if (!n.dealOpen()) { out.accept("Nothing to check."); return; }
        if (n.getRole() == CityNpc.Role.DEALER) {
            Random r = new Random(n.getUUID().getLeastSignificantBits());
            out.accept("You open the " + n.goodsName() + " bag: " + (8 + r.nextInt(25)) + " units, quality ~" + (50 + r.nextInt(50)) + "%.");
        } else {
            out.accept("You count the bills: " + PlayerFunds.fmt(n.actual())
                    + (n.actual() < n.price() ? " - less than the " + PlayerFunds.fmt(n.price()) + " promised." : "."));
        }
    }

    private static void haggle(CityNpc n, Consumer<String> out) {
        if (!n.dealOpen()) return;
        if (n.haggled()) { out.accept("That's final. Take it or leave it."); return; }
        n.setHaggled(true);
        boolean ok = RNG.nextBoolean();
        boolean dealer = n.getRole() == CityNpc.Role.DEALER;
        n.scale(dealer ? (ok ? 0.85 : 1.05) : (ok ? 1.15 : 0.95));
        out.accept(ok ? "...Fine. Better offer, but that's it. (" + n.offerInfo() + ")"
                      : "Pushing your luck. Now it's worse. (" + n.offerInfo() + ")");
    }

    private static void accept(ServerPlayer p, CityNpc n, Consumer<String> out) {
        if (!n.dealOpen()) { out.accept("Nothing to accept."); return; }
        if (n.getRole() == CityNpc.Role.DEALER) {
            if (PlayerFunds.cash(p) < n.price()) { out.accept("You're short on cash."); return; }
            PlayerFunds.setCash(p, PlayerFunds.cash(p) - n.price());
            Random r = new Random(n.getUUID().getLeastSignificantBits());
            give(p, GoodsItem.of(n.goodsItem(), 8 + r.nextInt(25), 50 + r.nextInt(50)));
            n.setDone(true);
            out.accept("Pleasure. Forget my face.");
        } else if (n.wantsGoods()) {
            ItemStack pkg = findGoods(p, n.goodsItem());
            if (pkg == null) { out.accept("Where's the " + n.goodsName() + "? Come back with it."); return; }
            pkg.shrink(1);
            give(p, EnvelopeItem.of(n.actual()));
            n.setDone(true);
            out.accept("Good. We never met.");
        } else {
            CompoundTag t = PlayerFunds.tag(p);
            if (!t.getString("targetUuid").isEmpty()) { out.accept("You already have an open job."); return; }
            ServerLevel sl = (ServerLevel) p.level();
            List<CityNpc> pool = sl.getEntitiesOfClass(CityNpc.class, p.getBoundingBox().inflate(300),
                    c -> c != n && c.getRole() == CityNpc.Role.CIVILIAN && !c.marked());
            if (pool.isEmpty()) { out.accept("No one fits right now. Come back later."); return; }
            CityNpc target = pool.get(RNG.nextInt(pool.size()));
            target.markFor(p.getUUID().toString());
            t.putString("targetUuid", target.getUUID().toString());
            t.putString("active", target.npcName() + " - last seen near "
                    + ((int) target.getX() / 50 * 50) + ", " + ((int) target.getZ() / 50 * 50));
            t.putLong("bonus", n.price() / 2);
            give(p, EnvelopeItem.of(n.actual()));
            n.setDone(true);
            out.accept("The name is " + target.npcName() + ", around " + ((int) target.getX() / 50 * 50) + ", "
                    + ((int) target.getZ() / 50 * 50) + ". Bonus when it's done.");
        }
    }

    private static ItemStack findGoods(ServerPlayer p, Item item) {
        for (ItemStack s : p.getInventory().items) if (s.is(item)) return s;
        return null;
    }

    private static void give(ServerPlayer p, ItemStack s) {
        if (!p.getInventory().add(s)) p.drop(s, false);
    }

    private static void send(ServerPlayer p, CityNpc n, String line, boolean open) {
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new NpcReplyPacket(n.getId(), n.npcName(),
                n.getRole().ordinal(), line, n.offerInfo(), n.dealOpen() ? 1 : 0, open));
    }
}
