package com.pbcity.npc;

import com.pbcity.econ.PlayerFunds;
import com.pbcity.item.ModItems;
import net.minecraft.world.item.Item;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** A walking, talking city resident. Role decides what the meeting offers. */
public class CityNpc extends PathfinderMob {
    public enum Role { CIVILIAN, DEALER, BUYER }

    private static final String[] FIRST = {"Marek", "Viktor", "Andrei", "Lukas", "Dmitri", "Tomas", "Ivan", "Rafal",
            "Mikhail", "Jonas", "Anna", "Elena", "Marta", "Irina", "Katya", "Sofia", "Olga", "Daria"};
    private static final String[] LAST = {"Kowal", "Volkov", "Petrauskas", "Novak", "Sokolov", "Brandt", "Orlov",
            "Zielinski", "Marin", "Kaplan", "Moroz", "Lenart", "Kuznets", "Bondar"};

    private Role role = Role.CIVILIAN;
    private long price;      // dealer: asking price; buyer: promised sum (cents)
    private long actual;     // buyer: what is really in the envelope
    private static final String[] GOODS = {"Cocaine", "Mephedrone", "Crystals", "Weed"};
    private static final double[] GOODS_MULT = {1.5, 0.9, 1.2, 0.5};
    private int goods;
    private boolean wantsGoods, haggled, done;
    private String markedBy = "";

    public CityNpc(EntityType<CityNpc> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25).add(Attributes.FOLLOW_RANGE, 16.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    public void init(Role r, RandomSource rnd) {
        role = r;
        if (r != Role.CIVILIAN) setPersistenceRequired(); // plain civilians despawn when far away
        setCustomName(Component.literal(FIRST[rnd.nextInt(FIRST.length)] + " " + LAST[rnd.nextInt(LAST.length)]));
        goods = rnd.nextInt(GOODS.length);
        price = (3 + rnd.nextInt(18)) * 10_000L;          // EUR 300..2000
        price = Math.max(10_000L, Math.round(price * GOODS_MULT[goods] / 1000.0) * 1000L);
        wantsGoods = rnd.nextBoolean();
        actual = rnd.nextInt(4) == 0 ? price * (60 + rnd.nextInt(30)) / 100 : price; // 25%: envelope is short
    }

    public Role getRole() { return role; }
    public String goodsName() { return GOODS[goods]; }
    public Item goodsItem() {
        return switch (goods) {
            case 0 -> ModItems.COCAINE.get();
            case 1 -> ModItems.MEPHEDRONE.get();
            case 2 -> ModItems.CRYSTALS.get();
            default -> ModItems.WEED.get();
        };
    }
    public long price() { return price; }
    public long actual() { return actual; }
    public boolean wantsGoods() { return wantsGoods; }
    public boolean haggled() { return haggled; }
    public boolean done() { return done; }
    public void setDone(boolean d) { done = d; }
    public void setHaggled(boolean h) { haggled = h; }
    public boolean marked() { return !markedBy.isEmpty(); }
    public void markFor(String playerUuid) { markedBy = playerUuid; setPersistenceRequired(); }

    public void scale(double f) {
        price = Math.round(price * f);
        actual = Math.round(actual * f);
    }

    public String npcName() { return getCustomName() != null ? getCustomName().getString() : "Stranger"; }

    public boolean dealOpen() { return role != Role.CIVILIAN && !done; }

    public String offerInfo() {
        return switch (role) {
            case DEALER -> GOODS[goods] + " bag - " + PlayerFunds.fmt(price);
            case BUYER -> wantsGoods ? "Buys " + GOODS[goods] + " - offers " + PlayerFunds.fmt(price)
                                     : "Under-the-table job - " + PlayerFunds.fmt(price) + " promised";
            default -> "";
        };
    }

    @Override
    protected InteractionResult mobInteract(Player p, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && p instanceof ServerPlayer sp) NpcService.open(sp, this);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putString("role", role.name());
        t.putLong("price", price);
        t.putInt("goods", goods);
        t.putLong("actual", actual);
        t.putBoolean("wantsGoods", wantsGoods);
        t.putBoolean("haggled", haggled);
        t.putBoolean("done", done);
        t.putString("markedBy", markedBy);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        try { role = Role.valueOf(t.getString("role")); } catch (IllegalArgumentException e) { role = Role.CIVILIAN; }
        price = t.getLong("price");
        goods = Math.floorMod(t.getInt("goods"), GOODS.length);
        actual = t.getLong("actual");
        wantsGoods = t.getBoolean("wantsGoods");
        haggled = t.getBoolean("haggled");
        done = t.getBoolean("done");
        markedBy = t.getString("markedBy");
    }
}
