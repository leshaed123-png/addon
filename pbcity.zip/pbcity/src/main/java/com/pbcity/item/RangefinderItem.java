package com.pbcity.item;

import net.minecraft.world.item.Item;

/** Marker item: the HUD overlay reacts to it being held (main or off hand). */
public class RangefinderItem extends Item {
    public RangefinderItem(Properties p) { super(p); }
}
