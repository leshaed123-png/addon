package com.pbcity.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

/** A bagged trade good (NBT "units", "quality"). A pure trade item in this mod: it has no use effect. */
public class GoodsItem extends Item {
    public GoodsItem(Properties p) { super(p); }

    public static ItemStack of(Item item, int units, int quality) {
        ItemStack s = new ItemStack(item);
        s.getOrCreateTag().putInt("units", units);
        s.getTag().putInt("quality", quality);
        return s;
    }

    @Override
    public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
        if (s.hasTag()) tip.add(Component.literal(s.getTag().getInt("units") + " units, quality ~"
                + s.getTag().getInt("quality") + "%"));
    }
}
