package com.pbcity.item;

import com.pbcity.PBCity;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PBCity.MODID);
    public static final RegistryObject<Item> RANGEFINDER =
            ITEMS.register("rangefinder", () -> new RangefinderItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> WIND_METER =
            ITEMS.register("wind_meter", () -> new WindMeterItem(new Item.Properties().stacksTo(1)));
    private ModItems() {}
}
