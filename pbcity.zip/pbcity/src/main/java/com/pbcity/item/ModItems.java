package com.pbcity.item;

import com.pbcity.PBCity;
import com.pbcity.npc.ModEntities;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PBCity.MODID);
    public static final RegistryObject<Item> RANGEFINDER =
            ITEMS.register("rangefinder", () -> new RangefinderItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> WIND_METER =
            ITEMS.register("wind_meter", () -> new WindMeterItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ENVELOPE =
            ITEMS.register("envelope", () -> new EnvelopeItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> PACKAGE =
            ITEMS.register("package", () -> new PackageItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> COCAINE =
            ITEMS.register("cocaine", () -> new GoodsItem(new Item.Properties().stacksTo(16), 0));
    public static final RegistryObject<Item> MEPHEDRONE =
            ITEMS.register("mephedrone", () -> new GoodsItem(new Item.Properties().stacksTo(16), 1));
    public static final RegistryObject<Item> CRYSTALS =
            ITEMS.register("crystals", () -> new GoodsItem(new Item.Properties().stacksTo(16), 2));
    public static final RegistryObject<Item> WEED =
            ITEMS.register("weed", () -> new GoodsItem(new Item.Properties().stacksTo(16), 3));
    public static final RegistryObject<Item> LEDGER =
            ITEMS.register("ledger", () -> new LedgerItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> NPC_EGG =
            ITEMS.register("city_npc_spawn_egg",
                    () -> new ForgeSpawnEggItem(ModEntities.CITY_NPC, 0x6B1230, 0xFFB84D, new Item.Properties()));
    private ModItems() {}
}
