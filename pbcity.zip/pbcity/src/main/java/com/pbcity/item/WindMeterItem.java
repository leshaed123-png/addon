package com.pbcity.item;

import net.minecraft.world.item.Item;

public class WindMeterItem extends Item {
    public WindMeterItem(Properties p) { super(p); }
}
