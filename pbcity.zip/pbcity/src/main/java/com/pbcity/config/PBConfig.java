package com.pbcity.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class PBConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.DoubleValue MUZZLE_VELOCITY;
    public static final ForgeConfigSpec.DoubleValue DRAG_K;
    public static final ForgeConfigSpec.DoubleValue WIND_BASE;
    public static final ForgeConfigSpec.DoubleValue WIND_GUST;
    public static final ForgeConfigSpec.DoubleValue MAX_RANGE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("ballistics");
        ENABLED = b.comment("Replace Point Blank's straight-line hitscan ray with a simulated bullet path.")
                .define("enabled", true);
        MUZZLE_VELOCITY = b.comment("Default muzzle velocity, m/s (1 block = 1 m). TODO: per-gun table.")
                .defineInRange("muzzleVelocity", 850.0, 50.0, 2000.0);
        DRAG_K = b.comment("Quadratic drag constant k (1/m). a = -k*|v-wind|*(v-wind). 5.56mm ~ 0.0012")
                .defineInRange("dragK", 0.0012, 0.0, 0.05);
        b.pop();
        b.push("wind");
        WIND_BASE = b.comment("Average wind speed, m/s.").defineInRange("base", 4.0, 0.0, 30.0);
        WIND_GUST = b.comment("Gust amplitude, m/s. Rain and thunderstorms add extra wind automatically.")
                .defineInRange("gust", 2.5, 0.0, 15.0);
        b.pop();
        b.push("devices");
        MAX_RANGE = b.comment("Rangefinder max range, blocks.").defineInRange("rangefinderMax", 1500.0, 50.0, 5000.0);
        b.pop();
        SPEC = b.build();
    }

    private PBConfig() {}
}
