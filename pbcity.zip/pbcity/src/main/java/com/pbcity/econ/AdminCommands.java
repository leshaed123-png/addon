package com.pbcity.econ;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.pbcity.PBCity;
import com.pbcity.police.Police;
import com.pbcity.police.PoliceData;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Operator panel (permission level 2):
 *   /pbcity admin money <player> <euros>        add (or remove, negative) bank money
 *   /pbcity admin cash <player> <euros>         add cash
 *   /pbcity admin unlimited <player> <true|false>   unlimited balance
 *   /pbcity admin setjail                      jail = where you stand
 *   /pbcity admin pardon <player>              clear wanted / raid / jail / traced money
 *   /pbcity admin status <player>              balances, dirty money, wanted, jailed
 */
@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AdminCommands {
    private AdminCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("pbcity").requires(s -> s.hasPermission(2)).then(Commands.literal("admin")
                .then(Commands.literal("money").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("euros", DoubleArgumentType.doubleArg(-1e9, 1e9)).executes(c -> {
                            ServerPlayer p = EntityArgument.getPlayer(c, "player");
                            long cents = Math.round(DoubleArgumentType.getDouble(c, "euros") * 100);
                            PlayerFunds.setBank(p, PlayerFunds.bank(p) + cents);
                            c.getSource().sendSuccess(() -> Component.literal(p.getGameProfile().getName() + ": банк " + PlayerFunds.fmt(PlayerFunds.bank(p))), true);
                            return 1;
                        }))))
                .then(Commands.literal("cash").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("euros", DoubleArgumentType.doubleArg(-1e9, 1e9)).executes(c -> {
                            ServerPlayer p = EntityArgument.getPlayer(c, "player");
                            long cents = Math.round(DoubleArgumentType.getDouble(c, "euros") * 100);
                            PlayerFunds.setCash(p, PlayerFunds.cash(p) + cents);
                            c.getSource().sendSuccess(() -> Component.literal(p.getGameProfile().getName() + ": наличные " + PlayerFunds.fmt(PlayerFunds.cash(p))), true);
                            return 1;
                        }))))
                .then(Commands.literal("unlimited").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("on", BoolArgumentType.bool()).executes(c -> {
                            ServerPlayer p = EntityArgument.getPlayer(c, "player");
                            boolean on = BoolArgumentType.getBool(c, "on");
                            PlayerFunds.tag(p).putBoolean("inf", on);
                            if (on) { PlayerFunds.setCash(p, PlayerFunds.cash(p)); PlayerFunds.setBank(p, PlayerFunds.bank(p)); }
                            c.getSource().sendSuccess(() -> Component.literal(p.getGameProfile().getName() + ": безлимит " + (on ? "ВКЛ" : "выкл")), true);
                            return 1;
                        }))))
                .then(Commands.literal("setjail").executes(c -> {
                    var pos = net.minecraft.core.BlockPos.containing(c.getSource().getPosition());
                    PoliceData d = PoliceData.get(c.getSource().getServer());
                    d.jail = pos; d.setDirty();
                    c.getSource().sendSuccess(() -> Component.literal("Тюрьма: " + pos.toShortString()), true);
                    return 1;
                }))
                .then(Commands.literal("pardon").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                    ServerPlayer p = EntityArgument.getPlayer(c, "player");
                    Police.pardon(p);
                    c.getSource().sendSuccess(() -> Component.literal(p.getGameProfile().getName() + ": помилован"), true);
                    return 1;
                })))
                .then(Commands.literal("status").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                    ServerPlayer p = EntityArgument.getPlayer(c, "player");
                    c.getSource().sendSuccess(() -> Component.literal(p.getGameProfile().getName() + ": нал " + PlayerFunds.fmt(PlayerFunds.cash(p))
                            + ", банк " + PlayerFunds.fmt(PlayerFunds.bank(p)) + ", грязные " + PlayerFunds.fmt(PlayerFunds.dirty(p))
                            + ", через банк " + PlayerFunds.fmt(PlayerFunds.traced(p)) + ", розыск " + Police.wanted(p.getUUID())
                            + ", тюрьма " + Police.jailed(p.getUUID()) + ", безлимит " + PlayerFunds.unlimited(p)), false);
                    return 1;
                })))));
    }
}
