package com.pbcity.econ;

import com.pbcity.net.ActionPacket;
import com.pbcity.net.Net;
import com.pbcity.net.StatePacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Server-side authority for everything the phone does. The client only sends requests. */
public final class PhoneService {
    private static final long MAX_BET = 100_000L; // EUR 1,000
    private static final long DARK_TICKS = 12_000L; // 10 minutes of darknet access
    private static final Set<Integer> RED = Set.of(1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36);
    private static final String[] FIRST = {"Marek", "Viktor", "Andrei", "Lukas", "Dmitri", "Tomas", "Ivan", "Rafal", "Mikhail", "Jonas"};
    private static final String[] LAST = {"Kowal", "Volkov", "Petrauskas", "Novak", "Sokolov", "Brandt", "Orlov", "Zielinski", "Marin", "Kaplan"};
    private static final String[] DISTRICT = {"Centre", "Industrial zone", "Harbour", "Market", "Suburbs"};

    private record Crash(long bet, long startNanos, double point) {}
    private record Offer(ItemStack stack, long value, long cents, boolean countered) {}
    private static final Map<UUID, Crash> CRASH = new HashMap<>();
    private static final Map<UUID, String> HACK = new HashMap<>();
    private static final Map<UUID, Offer> OFFER = new HashMap<>();

    private PhoneService() {}

    public static double crashMult(double seconds) { return Math.exp(0.09 * seconds); }

    private static boolean dark(ServerPlayer p) {
        return PlayerFunds.tag(p).getLong("darkUntil") > p.level().getGameTime();
    }

    public static void handle(ServerPlayer p, ActionPacket m) {
        String toast = null, hackShow = "";
        int cs = 0;
        double mult = 1.0;
        UUID id = p.getUUID();
        switch (m.action()) {
            case "SYNC" -> { }
            case "DEPOSIT" -> toast = move(p, m.amount(), true);
            case "WITHDRAW" -> toast = move(p, m.amount(), false);
            case "ROULETTE" -> toast = roulette(p, m.amount(), m.arg());
            case "CRASH_START" -> toast = crashStart(p, m.amount());
            case "SLOTS" -> toast = slots(p, m.amount());
            case "CRASH_POLL", "CRASH_CASH" -> {
                Crash c = CRASH.get(id);
                if (c != null) {
                    double cur = crashMult((System.nanoTime() - c.startNanos) / 1e9);
                    if (cur >= c.point) {
                        CRASH.remove(id);
                        cs = 2; mult = c.point;
                        toast = String.format("Crash at x%.2f. Lost %s", c.point, PlayerFunds.fmt(c.bet));
                    } else if (m.action().equals("CRASH_CASH")) {
                        long payout = (long) (c.bet * cur);
                        PlayerFunds.setCash(p, PlayerFunds.cash(p) + payout);
                        CRASH.remove(id);
                        cs = 3; mult = cur;
                        toast = String.format("Cashed out at x%.2f: +%s", cur, PlayerFunds.fmt(payout - c.bet));
                    } else { cs = 1; mult = cur; }
                }
            }
            case "HACK_START" -> {
                int len = 4 + Math.max(0, Math.min(2, m.arg()));
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < len; i++) sb.append(1 + ThreadLocalRandom.current().nextInt(9));
                HACK.put(id, sb.toString());
                hackShow = sb.toString();
                toast = "Handshake captured. Memorize the code.";
            }
            case "HACK_SUBMIT" -> {
                String seq = HACK.remove(id);
                if (seq == null) toast = "No hack in progress";
                else if (Long.toString(m.amount()).equals(seq)) {
                    PlayerFunds.tag(p).putLong("darkUntil", p.level().getGameTime() + DARK_TICKS);
                    toast = "Access granted. DarkNet open for 10 min";
                } else toast = "Wrong code. Connection dropped";
            }
            case "CONTRACT_ACCEPT" -> toast = dark(p) ? acceptContract(p, m.arg()) : "No DarkNet signal";
            case "SHOP_BUY" -> toast = dark(p) ? shopBuy(p, m.arg()) : "No DarkNet signal";
            case "BIT_BUY" -> toast = bitTrade(p, m.amount(), true);
            case "BIT_SELL" -> toast = bitTrade(p, m.amount(), false);
            case "MARKET_OFFER" -> toast = marketOffer(p);
            case "MARKET_COUNTER" -> toast = marketCounter(p);
            case "MARKET_ACCEPT" -> toast = marketAccept(p);
            case "JOB_START" -> toast = jobStart(p, m.arg());
            case "JOB_COLLECT" -> toast = jobCollect(p);
            default -> { }
        }
        if (cs == 0 && CRASH.containsKey(id)) {
            Crash c = CRASH.get(id);
            cs = 1;
            mult = crashMult((System.nanoTime() - c.startNanos) / 1e9);
        }
        send(p, toast, cs, mult, hackShow);
    }

    // ---- bank / casino -------------------------------------------------------------------------
    private static String move(ServerPlayer p, long amt, boolean deposit) {
        if (amt <= 0) return "Invalid amount";
        long from = deposit ? PlayerFunds.cash(p) : PlayerFunds.bank(p);
        if (amt > from) return deposit ? "Not enough cash" : "Not enough funds";
        if (deposit) {
            PlayerFunds.setCash(p, PlayerFunds.cash(p) - amt);
            PlayerFunds.setBank(p, PlayerFunds.bank(p) + amt);
            return "Deposited " + PlayerFunds.fmt(amt);
        }
        PlayerFunds.setBank(p, PlayerFunds.bank(p) - amt);
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + amt);
        return "Withdrew " + PlayerFunds.fmt(amt);
    }

    private static String checkBet(ServerPlayer p, long bet) {
        if (bet <= 0 || bet > MAX_BET) return "Bet must be up to " + PlayerFunds.fmt(MAX_BET);
        if (bet > PlayerFunds.cash(p)) return "Not enough cash";
        return null;
    }

    private static String roulette(ServerPlayer p, long bet, int type) {
        String err = checkBet(p, bet);
        if (err != null) return err;
        PlayerFunds.setCash(p, PlayerFunds.cash(p) - bet);
        int r = ThreadLocalRandom.current().nextInt(37);
        String colour = r == 0 ? "green" : RED.contains(r) ? "red" : "black";
        boolean win = switch (type) {
            case 100 -> r != 0 && RED.contains(r);
            case 101 -> r != 0 && !RED.contains(r);
            case 102 -> r == 0;
            default -> false;
        };
        long payout = win ? (type == 102 ? bet * 36 : bet * 2) : 0;
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + payout);
        return win ? "Ball: " + r + " " + colour + ". +" + PlayerFunds.fmt(payout - bet)
                   : "Ball: " + r + " " + colour + ". -" + PlayerFunds.fmt(bet);
    }

    private static String slots(ServerPlayer p, long bet) {
        String err = checkBet(p, bet);
        if (err != null) return err;
        PlayerFunds.setCash(p, PlayerFunds.cash(p) - bet);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int a = r.nextInt(6), b = r.nextInt(6), c = r.nextInt(6);
        long payout = (a == b && b == c) ? bet * 20 : (a == b || b == c || a == c) ? bet * 9 / 10 : 0;
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + payout);
        String[] sym = {"7", "BAR", "CHERRY", "BELL", "STAR", "LEMON"};
        String res = payout > bet ? "+" + PlayerFunds.fmt(payout - bet) : "-" + PlayerFunds.fmt(bet - payout);
        return "Slots: " + sym[a] + " " + sym[b] + " " + sym[c] + "  " + res;
    }

    private static String crashStart(ServerPlayer p, long bet) {
        if (CRASH.containsKey(p.getUUID())) return "Round already running";
        String err = checkBet(p, bet);
        if (err != null) return err;
        PlayerFunds.setCash(p, PlayerFunds.cash(p) - bet);
        double u = ThreadLocalRandom.current().nextDouble();
        double point = Math.min(100.0, Math.max(1.0, 0.97 / (1.0 - u))); // ~3% house edge
        CRASH.put(p.getUUID(), new Crash(bet, System.nanoTime(), point));
        return "Round started";
    }

    // ---- orders / shop -------------------------------------------------------------------------
    private static List<String> contractsFor(ServerPlayer p) {
        long day = p.level().getDayTime() / 24000L;
        Random r = new Random(p.getUUID().hashCode() * 31L + day);
        List<String> out = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            String name = FIRST[r.nextInt(FIRST.length)] + " " + LAST[r.nextInt(LAST.length)];
            String dist = DISTRICT[r.nextInt(DISTRICT.length)];
            long pay = (500 + r.nextInt(46) * 100L) * 100L;
            out.add(i + "|" + name + "|" + dist + "|" + pay);
        }
        return out;
    }

    private static String acceptContract(ServerPlayer p, int id) {
        List<String> list = contractsFor(p);
        if (id < 0 || id >= list.size()) return "Order not found";
        CompoundTag t = PlayerFunds.tag(p);
        if (!t.getString("active").isEmpty()) return "You already have an active order";
        String[] f = list.get(id).split("\\|");
        t.putString("active", f[1] + " / " + f[2]);
        return "Order accepted: " + f[1];
    }

    private static String shopBuy(ServerPlayer p, int idx) {
        if (idx < 0 || idx >= Shop.CATALOG.size()) return "Out of stock";
        Shop.Entry e = Shop.CATALOG.get(idx);
        Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation("pointblank", e.id()));
        if (item == null || item == Items.AIR) return "Out of stock";
        if (PlayerFunds.cash(p) < e.cents()) return "Not enough cash";
        PlayerFunds.setCash(p, PlayerFunds.cash(p) - e.cents());
        ItemStack s = new ItemStack(item, e.count());
        if (!p.getInventory().add(s)) p.drop(s, false);
        return "Bought " + e.label();
    }

    // ---- BIT -----------------------------------------------------------------------------------
    private static String bitTrade(ServerPlayer p, long cents, boolean buy) {
        if (cents <= 0) return "Invalid amount";
        CompoundTag t = PlayerFunds.tag(p);
        double price = BitMarket.price(p.level().getGameTime());
        double have = t.getDouble("bit");
        if (buy) {
            if (cents > PlayerFunds.bank(p)) return "Not enough funds";
            PlayerFunds.setBank(p, PlayerFunds.bank(p) - cents);
            t.putDouble("bit", have + (cents * 0.99 / 100.0) / price);
            return "Bought " + PlayerFunds.fmt(cents) + " of BIT";
        }
        double units = cents / 100.0 / price;
        if (units > have + 1e-9) return "Not enough BIT";
        t.putDouble("bit", Math.max(0, have - units));
        PlayerFunds.setBank(p, PlayerFunds.bank(p) + Math.round(cents * 0.99));
        return "Sold " + PlayerFunds.fmt(cents) + " of BIT";
    }

    // ---- Market (bot buyers with haggling) -----------------------------------------------------
    private static String marketOffer(ServerPlayer p) {
        ItemStack hand = p.getMainHandItem();
        long value = Shop.resaleValue(hand);
        if (value <= 0) return "Hold something tradable in your hand";
        long cents = Math.round(value * (0.70 + ThreadLocalRandom.current().nextDouble() * 0.20));
        OFFER.put(p.getUUID(), new Offer(hand.copy(), value, cents, false));
        return "A buyer made an offer";
    }

    private static String marketCounter(ServerPlayer p) {
        Offer o = OFFER.get(p.getUUID());
        if (o == null) return "No offer";
        if (o.countered) return "Buyer won't negotiate more";
        boolean ok = ThreadLocalRandom.current().nextBoolean();
        long cents = Math.round(o.cents * (ok ? 1.10 : 0.90));
        OFFER.put(p.getUUID(), new Offer(o.stack, o.value, Math.min(cents, o.value), true));
        return ok ? "Buyer raised the offer" : "Buyer got annoyed and lowered it";
    }

    private static String marketAccept(ServerPlayer p) {
        Offer o = OFFER.remove(p.getUUID());
        if (o == null) return "No offer";
        ItemStack hand = p.getMainHandItem();
        if (!ItemStack.isSameItemSameTags(hand, o.stack) || hand.getCount() < o.stack.getCount())
            return "The item is no longer in your hand";
        hand.shrink(o.stack.getCount());
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + o.cents);
        return "Sold for " + PlayerFunds.fmt(o.cents);
    }

    // ---- odd jobs ------------------------------------------------------------------------------
    private static String jobStart(ServerPlayer p, int kind) {
        CompoundTag t = PlayerFunds.tag(p);
        if (t.getLong("jobEnd") != 0) return "You already have a shift";
        long[] ticks = {600, 1800, 400};
        long[] base = {8_000, 25_000, 5_000};
        int[] spread = {71, 151, 41};
        int k = Math.max(0, Math.min(2, kind));
        t.putLong("jobEnd", p.level().getGameTime() + ticks[k]);
        t.putLong("jobPay", base[k] + ThreadLocalRandom.current().nextInt(spread[k]) * 100L);
        return "Shift started. Back in " + ticks[k] / 20 + " s";
    }

    private static String jobCollect(ServerPlayer p) {
        CompoundTag t = PlayerFunds.tag(p);
        long end = t.getLong("jobEnd"), now = p.level().getGameTime();
        if (end == 0) return "No shift running";
        if (now < end) return "Still working: " + (end - now) / 20 + " s left";
        long pay = t.getLong("jobPay");
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + pay);
        t.putLong("jobEnd", 0);
        return "Paid in cash: " + PlayerFunds.fmt(pay);
    }

    private static String jobState(CompoundTag t, long now) {
        long end = t.getLong("jobEnd");
        if (end == 0) return "idle";
        return now < end ? "work:" + (end - now) / 20 : "ready:" + t.getLong("jobPay");
    }

    // ---- state out -----------------------------------------------------------------------------
    private static void send(ServerPlayer p, String toast, int cs, double mult, String hackShow) {
        CompoundTag t = PlayerFunds.tag(p);
        long now = p.level().getGameTime();
        Offer o = OFFER.get(p.getUUID());
        String market = o == null ? "" : o.stack.getHoverName().getString() + " x" + o.stack.getCount()
                + " | offer " + PlayerFunds.fmt(o.cents) + (o.countered ? " | final" : "");
        long darkLeft = Math.max(0, (t.getLong("darkUntil") - now) / 20);
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p),
                new StatePacket(t.getLong("cash"), t.getLong("bank"), toast == null ? "" : toast,
                        contractsFor(p), t.getString("active"), cs, mult, darkLeft, t.getDouble("bit"),
                        hackShow, market, jobState(t, now)));
    }
}
