package com.pbcity.econ;

import com.pbcity.net.ActionPacket;
import com.pbcity.net.Net;
import com.pbcity.net.StatePacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Server-side authority for everything the phone does. The client only sends requests. */
public final class PhoneService {
    private static final long MAX_BET = 100_000L; // EUR 1,000
    private static final Set<Integer> RED = Set.of(1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36);
    private static final String[] FIRST = {"Marek", "Viktor", "Andrei", "Lukas", "Dmitri", "Tomas", "Ivan", "Rafal", "Mikhail", "Jonas"};
    private static final String[] LAST = {"Kowal", "Volkov", "Petrauskas", "Novak", "Sokolov", "Brandt", "Orlov", "Zielinski", "Marin", "Kaplan"};
    private static final String[] DISTRICT = {"Centre", "Industrial zone", "Harbour", "Market", "Suburbs"};

    private record Crash(long bet, long startNanos, double point) {}
    private static final Map<UUID, Crash> CRASH = new HashMap<>();

    private PhoneService() {}

    public static double crashMult(double seconds) { return Math.exp(0.09 * seconds); }

    public static void handle(ServerPlayer p, ActionPacket m) {
        String toast = null;
        int cs = 0;
        double mult = 1.0;
        switch (m.action()) {
            case "SYNC" -> { }
            case "DEPOSIT" -> toast = move(p, m.amount(), true);
            case "WITHDRAW" -> toast = move(p, m.amount(), false);
            case "ROULETTE" -> toast = roulette(p, m.amount(), m.arg());
            case "CRASH_START" -> toast = crashStart(p, m.amount());
            case "CRASH_POLL", "CRASH_CASH" -> {
                Crash c = CRASH.get(p.getUUID());
                if (c != null) {
                    double cur = crashMult((System.nanoTime() - c.startNanos) / 1e9);
                    if (cur >= c.point) {
                        CRASH.remove(p.getUUID());
                        cs = 2; mult = c.point;
                        toast = String.format("Crash at x%.2f. Lost %s", c.point, PlayerFunds.fmt(c.bet));
                    } else if (m.action().equals("CRASH_CASH")) {
                        long payout = (long) (c.bet * cur);
                        PlayerFunds.setCash(p, PlayerFunds.cash(p) + payout);
                        CRASH.remove(p.getUUID());
                        cs = 3; mult = cur;
                        toast = String.format("Cashed out at x%.2f: +%s", cur, PlayerFunds.fmt(payout - c.bet));
                    } else {
                        cs = 1; mult = cur;
                    }
                }
            }
            case "CONTRACT_ACCEPT" -> toast = acceptContract(p, m.arg());
            default -> { }
        }
        if (cs == 0 && CRASH.containsKey(p.getUUID())) {
            Crash c = CRASH.get(p.getUUID());
            cs = 1;
            mult = crashMult((System.nanoTime() - c.startNanos) / 1e9);
        }
        send(p, toast, cs, mult);
    }

    private static String move(ServerPlayer p, long amt, boolean deposit) {
        if (amt <= 0) return "Invalid amount";
        long from = deposit ? PlayerFunds.cash(p) : PlayerFunds.bank(p);
        if (amt > from) return deposit ? "Not enough cash" : "Not enough funds";
        if (deposit) {
            PlayerFunds.setCash(p, PlayerFunds.cash(p) - amt);
            PlayerFunds.setBank(p, PlayerFunds.bank(p) + amt);
            return "Deposited " + PlayerFunds.fmt(amt);
        }
        PlayerFunds.setBank(p, PlayerFunds.bank(p) - amt);
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + amt);
        return "Withdrew " + PlayerFunds.fmt(amt);
    }

    private static String checkBet(ServerPlayer p, long bet) {
        if (bet <= 0 || bet > MAX_BET) return "Bet must be up to " + PlayerFunds.fmt(MAX_BET);
        if (bet > PlayerFunds.cash(p)) return "Not enough cash";
        return null;
    }

    private static String roulette(ServerPlayer p, long bet, int type) {
        String err = checkBet(p, bet);
        if (err != null) return err;
        PlayerFunds.setCash(p, PlayerFunds.cash(p) - bet);
        int r = ThreadLocalRandom.current().nextInt(37);
        String colour = r == 0 ? "green" : RED.contains(r) ? "red" : "black";
        boolean win = switch (type) {
            case 100 -> r != 0 && RED.contains(r);
            case 101 -> r != 0 && !RED.contains(r);
            case 102 -> r == 0;
            default -> false;
        };
        long payout = win ? (type == 102 ? bet * 36 : bet * 2) : 0;
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + payout);
        return win ? "Ball: " + r + " " + colour + ". +" + PlayerFunds.fmt(payout - bet)
                   : "Ball: " + r + " " + colour + ". -" + PlayerFunds.fmt(bet);
    }

    private static String crashStart(ServerPlayer p, long bet) {
        if (CRASH.containsKey(p.getUUID())) return "Round already running";
        String err = checkBet(p, bet);
        if (err != null) return err;
        PlayerFunds.setCash(p, PlayerFunds.cash(p) - bet);
        double u = ThreadLocalRandom.current().nextDouble();
        double point = Math.min(100.0, Math.max(1.0, 0.97 / (1.0 - u))); // ~3% house edge
        CRASH.put(p.getUUID(), new Crash(bet, System.nanoTime(), point));
        return "Round started";
    }

    private static List<String> contractsFor(ServerPlayer p) {
        long day = p.level().getDayTime() / 24000L;
        Random r = new Random(p.getUUID().hashCode() * 31L + day);
        List<String> out = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            String name = FIRST[r.nextInt(FIRST.length)] + " " + LAST[r.nextInt(LAST.length)];
            String dist = DISTRICT[r.nextInt(DISTRICT.length)];
            long pay = (500 + r.nextInt(46) * 100L) * 100L;
            out.add(i + "|" + name + "|" + dist + "|" + pay);
        }
        return out;
    }

    private static String acceptContract(ServerPlayer p, int id) {
        List<String> list = contractsFor(p);
        if (id < 0 || id >= list.size()) return "Order not found";
        CompoundTag t = PlayerFunds.tag(p);
        if (!t.getString("active").isEmpty()) return "You already have an active order";
        String[] f = list.get(id).split("\\|");
        t.putString("active", f[1] + " / " + f[2]);
        return "Order accepted: " + f[1];
    }

    private static void send(ServerPlayer p, String toast, int cs, double mult) {
        CompoundTag t = PlayerFunds.tag(p);
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p),
                new StatePacket(t.getLong("cash"), t.getLong("bank"), toast == null ? "" : toast,
                        contractsFor(p), t.getString("active"), cs, mult));
    }
}
