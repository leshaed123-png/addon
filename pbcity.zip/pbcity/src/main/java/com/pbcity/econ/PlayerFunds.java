package com.pbcity.econ;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

import java.util.Locale;

/** Cash and bank balance in euro cents, stored in the player's persisted NBT (survives death). */
public final class PlayerFunds {
    private PlayerFunds() {}

    public static CompoundTag tag(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(Player.PERSISTED_NBT_TAG)) root.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag pers = root.getCompound(Player.PERSISTED_NBT_TAG);
        if (!pers.contains("pbcity")) {
            CompoundTag t = new CompoundTag();
            t.putLong("cash", 50_000L);   // EUR 500.00 starting cash
            t.putLong("bank", 150_000L);  // EUR 1,500.00 starting bank balance
            pers.put("pbcity", t);
        }
        return pers.getCompound("pbcity");
    }

    public static long cash(Player p) { return tag(p).getLong("cash"); }
    public static long bank(Player p) { return tag(p).getLong("bank"); }
    public static void setCash(Player p, long v) { tag(p).putLong("cash", Math.max(0, v)); }
    public static void setBank(Player p, long v) { tag(p).putLong("bank", Math.max(0, v)); }

    public static String fmt(long cents) {
        return String.format(Locale.ROOT, "€%,.2f", cents / 100.0);
    }
}
