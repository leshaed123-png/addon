package com.pbcity.net;

import com.pbcity.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server -> client: balances, toast text, contract board, crash round state. Money is in euro cents. */
public record StatePacket(long cash, long bank, String toast, List<String> contracts, String active,
                          int crashStatus, double mult) {
    public static void encode(StatePacket m, FriendlyByteBuf b) {
        b.writeLong(m.cash);
        b.writeLong(m.bank);
        b.writeUtf(m.toast, 256);
        b.writeCollection(m.contracts, (buf, s) -> buf.writeUtf(s, 128));
        b.writeUtf(m.active, 128);
        b.writeVarInt(m.crashStatus);
        b.writeDouble(m.mult);
    }

    public static StatePacket decode(FriendlyByteBuf b) {
        long cash = b.readLong();
        long bank = b.readLong();
        String toast = b.readUtf(256);
        List<String> contracts = b.readCollection(ArrayList::new, buf -> buf.readUtf(128));
        String active = b.readUtf(128);
        int cs = b.readVarInt();
        double mult = b.readDouble();
        return new StatePacket(cash, bank, toast, contracts, active, cs, mult);
    }

    public static void handle(StatePacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.apply(m)));
        c.setPacketHandled(true);
    }
}
