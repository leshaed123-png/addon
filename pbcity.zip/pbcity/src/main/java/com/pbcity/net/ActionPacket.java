package com.pbcity.net;

import com.pbcity.econ.PhoneService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: a phone action (DEPOSIT, WITHDRAW, ROULETTE, CRASH_START, ...). */
public record ActionPacket(String action, long amount, int arg) {
    public static void encode(ActionPacket m, FriendlyByteBuf b) {
        b.writeUtf(m.action, 32);
        b.writeLong(m.amount);
        b.writeVarInt(m.arg);
    }

    public static ActionPacket decode(FriendlyByteBuf b) {
        return new ActionPacket(b.readUtf(32), b.readLong(), b.readVarInt());
    }

    public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) PhoneService.handle(p, m);
        });
        c.setPacketHandled(true);
    }
}
