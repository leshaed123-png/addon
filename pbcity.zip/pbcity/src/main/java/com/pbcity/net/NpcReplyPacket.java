package com.pbcity.net;

import com.pbcity.client.NpcClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: NPC line, current offer text, whether a deal is open; open=true opens the screen. */
public record NpcReplyPacket(int npcId, String name, int role, String line, String info, int dealState, boolean open) {
    public static void encode(NpcReplyPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.npcId);
        b.writeUtf(m.name, 64);
        b.writeVarInt(m.role);
        b.writeUtf(m.line, 600);
        b.writeUtf(m.info, 128);
        b.writeVarInt(m.dealState);
        b.writeBoolean(m.open);
    }

    public static NpcReplyPacket decode(FriendlyByteBuf b) {
        return new NpcReplyPacket(b.readVarInt(), b.readUtf(64), b.readVarInt(), b.readUtf(600),
                b.readUtf(128), b.readVarInt(), b.readBoolean());
    }

    public static void handle(NpcReplyPacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> NpcClient.apply(m)));
        c.setPacketHandled(true);
    }
}
