package com.pbcity.net;

import com.pbcity.npc.NpcService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server in a dialogue: SAY (free text), INSPECT, HAGGLE, ACCEPT, REFUSE. */
public record NpcSayPacket(int npcId, String kind, String text) {
    public static void encode(NpcSayPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.npcId);
        b.writeUtf(m.kind, 16);
        b.writeUtf(m.text, 200);
    }

    public static NpcSayPacket decode(FriendlyByteBuf b) {
        return new NpcSayPacket(b.readVarInt(), b.readUtf(16), b.readUtf(200));
    }

    public static void handle(NpcSayPacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) NpcService.handle(p, m);
        });
        c.setPacketHandled(true);
    }
}
