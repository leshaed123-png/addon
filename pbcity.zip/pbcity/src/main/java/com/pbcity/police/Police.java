package com.pbcity.police;

import com.pbcity.PBCity;
import com.pbcity.config.PBConfig;
import com.pbcity.econ.PlayerFunds;
import com.pbcity.npc.CityNpc;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Police system (event based, no police entities):
 * - A witnessed murder or armed robbery puts you on the wanted list; police arrive after N seconds and arrest you
 *   unless you got 150+ blocks away from the scene.
 * - Sleeping with unlaundered dirty cash (or dirty money that went through a bank deposit) means a raid at dawn.
 * - Arrest: dirty cash confiscated, 10% fine from the bank, jail for a few minutes at the jail point (/pbcity admin setjail).
 */
@Mod.EventBusSubscriber(modid = PBCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class Police {
    private record Wanted(long until, Vec3 scene, String what) {}
    private static final Map<UUID, Wanted> WANTED = new HashMap<>();
    private static final Map<UUID, Long> RAID = new HashMap<>();
    private static final Map<UUID, Long> JAIL = new HashMap<>();
    private static final Random RNG = new Random();

    private Police() {}

    public static boolean wanted(UUID id) { return WANTED.containsKey(id); }
    public static boolean jailed(UUID id) { return JAIL.containsKey(id); }
    public static void pardon(ServerPlayer p) { WANTED.remove(p.getUUID()); RAID.remove(p.getUUID()); JAIL.remove(p.getUUID()); PlayerFunds.clearTraced(p); }

    /** Called when a crime happens; witnesses decide whether police are called. */
    public static void crime(ServerPlayer p, CityNpc victim, String what) {
        if (!(p.level() instanceof ServerLevel sl) || WANTED.containsKey(p.getUUID())) return;
        int witnesses = 0;
        for (CityNpc c : sl.getEntitiesOfClass(CityNpc.class, victim.getBoundingBox().inflate(24), x -> x != victim && x.isAlive()))
            if (c.hasLineOfSight(p)) witnesses++;
        if (witnesses == 0 && RNG.nextInt(4) != 0) return;
        WANTED.put(p.getUUID(), new Wanted(sl.getGameTime() + PBConfig.WANTED_SECONDS.get() * 20L, p.position(), what));
        p.sendSystemMessage(Component.literal("[Розыск] Свидетель вызвал полицию (" + what + "). Скройся минимум на 150 блоков за "
                + PBConfig.WANTED_SECONDS.get() + " секунд!").withStyle(ChatFormatting.RED));
    }

    @SubscribeEvent
    public static void onKill(LivingDeathEvent e) {
        if (e.getEntity() instanceof CityNpc n && e.getSource().getEntity() instanceof ServerPlayer p) crime(p, n, "убийство");
    }

    /** Shift + right click on a civilian with a Point Blank gun in hand = robbery. */
    @SubscribeEvent
    public static void onRob(PlayerInteractEvent.EntityInteract e) {
        if (e.getLevel().isClientSide() || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getEntity() instanceof ServerPlayer p) || !(e.getTarget() instanceof CityNpc n) || !p.isShiftKeyDown()) return;
        ItemStack held = p.getMainHandItem();
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(held.getItem());
        if (key == null || !key.getNamespace().equals("pointblank") || n.getRole() != CityNpc.Role.CIVILIAN) return;
        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);
        if (n.getPersistentData().getBoolean("robbed")) {
            p.sendSystemMessage(Component.literal("<" + n.npcName() + "> У меня уже ничего нет, отстань!").withStyle(ChatFormatting.GOLD));
            return;
        }
        n.getPersistentData().putBoolean("robbed", true);
        long loot = (2_000 + RNG.nextInt(14_000)); // EUR 20..160
        PlayerFunds.setCash(p, PlayerFunds.cash(p) + loot);
        PlayerFunds.addDirty(p, loot);
        p.sendSystemMessage(Component.literal("<" + n.npcName() + "> Забирай всё, только не стреляй! (+" + PlayerFunds.fmt(loot) + ")").withStyle(ChatFormatting.GOLD));
        crime(p, n, "вооружённое ограбление");
    }

    @SubscribeEvent
    public static void onWake(PlayerWakeUpEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || e.wakeImmediately()) return;
        if (PlayerFunds.dirty(p) <= 0 && PlayerFunds.traced(p) <= 0) return;
        long now = p.level().getGameTime();
        RAID.put(p.getUUID(), now + 100);
        p.sendSystemMessage(Component.literal("Утро. В дверь громко стучат: «Полиция! Откройте!»").withStyle(ChatFormatting.RED));
    }

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 20 != 0) return;
        var server = e.getServer();
        long now = server.overworld().getGameTime();

        for (Iterator<Map.Entry<UUID, Wanted>> it = WANTED.entrySet().iterator(); it.hasNext(); ) {
            var en = it.next();
            if (now < en.getValue().until) continue;
            it.remove();
            ServerPlayer p = server.getPlayerList().getPlayer(en.getKey());
            if (p == null) continue;
            if (p.position().distanceToSqr(en.getValue().scene) < 150.0 * 150.0) arrest(p, "Задержан: " + en.getValue().what);
            else p.sendSystemMessage(Component.literal("[Розыск] Ты скрылся. Полиция потеряла след.").withStyle(ChatFormatting.GREEN));
        }
        for (Iterator<Map.Entry<UUID, Long>> it = RAID.entrySet().iterator(); it.hasNext(); ) {
            var en = it.next();
            if (now < en.getValue()) continue;
            it.remove();
            ServerPlayer p = server.getPlayerList().getPlayer(en.getKey());
            if (p == null) continue;
            if (PlayerFunds.dirty(p) > 0 || PlayerFunds.traced(p) > 0) arrest(p, "Обыск: найдены деньги из незаконных источников");
            else p.sendSystemMessage(Component.literal("Полиция ушла ни с чем: денег, к которым можно придраться, нет.").withStyle(ChatFormatting.GREEN));
        }
        for (Iterator<Map.Entry<UUID, Long>> it = JAIL.entrySet().iterator(); it.hasNext(); ) {
            var en = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(en.getKey());
            if (p == null) continue;
            if (now >= en.getValue()) {
                it.remove();
                p.sendSystemMessage(Component.literal("Тебя выпустили. Не попадайся больше.").withStyle(ChatFormatting.GREEN));
                continue;
            }
            BlockPos jp = PoliceData.get(server).jailOrSpawn(server);
            if (p.level() != server.overworld() || p.blockPosition().distSqr(jp) > 25) teleportJail(p, jp);
        }
    }

    private static void teleportJail(ServerPlayer p, BlockPos jp) {
        ServerLevel ow = p.getServer().overworld();
        p.teleportTo(ow, jp.getX() + 0.5, jp.getY(), jp.getZ() + 0.5, p.getYRot(), 0f);
    }

    public static void arrest(ServerPlayer p, String reason) {
        long taken = PlayerFunds.dirty(p);
        PlayerFunds.setCash(p, PlayerFunds.cash(p) - taken);
        PlayerFunds.cleanDirty(p, PlayerFunds.tag(p).getLong("dirty"));
        PlayerFunds.clearTraced(p);
        long fine = PlayerFunds.unlimited(p) ? 0 : PlayerFunds.bank(p) / 10;
        PlayerFunds.setBank(p, PlayerFunds.bank(p) - fine);
        WANTED.remove(p.getUUID());
        RAID.remove(p.getUUID());
        int secs = PBConfig.JAIL_SECONDS.get();
        JAIL.put(p.getUUID(), p.getServer().overworld().getGameTime() + secs * 20L);
        teleportJail(p, PoliceData.get(p.getServer()).jailOrSpawn(p.getServer()));
        p.sendSystemMessage(Component.literal(reason + ". Конфисковано " + PlayerFunds.fmt(taken) + ", штраф " + PlayerFunds.fmt(fine)
                + ". Срок: " + secs + " с.").withStyle(ChatFormatting.RED));
    }
}
