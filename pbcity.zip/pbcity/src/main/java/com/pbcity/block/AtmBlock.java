package com.pbcity.block;

import com.pbcity.econ.PlayerFunds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;

/** ATM: click = withdraw EUR 100 from the bank, sneak-click = deposit all cash. */
public class AtmBlock extends HorizontalDirectionalBlock {
    public AtmBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(FACING); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite());
    }

    @Override
    public InteractionResult use(BlockState s, Level level, BlockPos pos, Player p, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && hand == InteractionHand.MAIN_HAND) {
            String msg;
            if (p.isShiftKeyDown()) {
                long c = PlayerFunds.cash(p);
                if (c <= 0) msg = "ATM: no cash to deposit";
                else {
                    PlayerFunds.setCash(p, 0);
                    PlayerFunds.setBank(p, PlayerFunds.bank(p) + c);
                    msg = "ATM: deposited " + PlayerFunds.fmt(c);
                }
            } else if (PlayerFunds.bank(p) >= 10_000) {
                PlayerFunds.setBank(p, PlayerFunds.bank(p) - 10_000);
                PlayerFunds.setCash(p, PlayerFunds.cash(p) + 10_000);
                msg = "ATM: withdrew " + PlayerFunds.fmt(10_000) + " | balance " + PlayerFunds.fmt(PlayerFunds.bank(p));
            } else msg = "ATM: insufficient funds";
            p.displayClientMessage(Component.literal(msg), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
